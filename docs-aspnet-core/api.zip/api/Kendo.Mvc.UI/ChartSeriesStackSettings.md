---
title: ChartSeriesStackSettings
---

# Kendo.Mvc.UI.ChartSeriesStackSettings
Kendo UI ChartSeriesStackSettings class



## Properties


### Group

Indicates that the series should be stacked in a group with the specified name.

### Type

Specifies the preferred stack type.

### Enabled

A boolean value indicating if the series should be stacked. A string value is interpreted as series.stack.group.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






