---
title: GanttView
---

# Kendo.Mvc.UI.GanttView
Kendo UI GanttView class



## Properties


### Date

If set to some date and it is between the range start and range end of the selected view, the timeline of the currently selected view is scrolled to start from this date.Overrides the date option of the gantt.

### Range

Configures the view range settings.

### Selected

If set to true the view will be initially selected by the Gantt widget. The default selected view is "day".

### SlotSize

The size of the time slot headers. Values are treated as pixels.

### TimeHeaderTemplate

The template used to render the time slots in "day" view

### TimeHeaderTemplateId

The id of the script element used for TimeHeaderTemplate

### DayHeaderTemplate

The template used to render the day slots in "day" and "week" views.

### DayHeaderTemplateId

The id of the script element used for DayHeaderTemplate

### WeekHeaderTemplate

The template used to render the week slots in "week" and "month" views.

### WeekHeaderTemplateId

The id of the script element used for WeekHeaderTemplate

### MonthHeaderTemplate

The template used to render the month slots in "month" and "year" views.

### MonthHeaderTemplateId

The id of the script element used for MonthHeaderTemplate

### YearHeaderTemplate

The template used to render the year slots in "year" view.

### YearHeaderTemplateId

The id of the script element used for YearHeaderTemplate

### ResizeTooltipFormat

The format used to display the start and end dates in the resize tooltip.

### Type

The view type. Supported types are "day", "week", "month" and "year".




## Methods


### SerializeSettings
Serialize current instance to Dictionary






