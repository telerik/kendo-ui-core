---
title: IGanttTask
---

# Kendo.Mvc.UI.IGanttTask
Kendo UI IGanttTask interface



