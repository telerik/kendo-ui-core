---
title: ChartSeriesOverlaySettings
---

# Kendo.Mvc.UI.ChartSeriesOverlaySettings
Kendo UI ChartSeriesOverlaySettings class



## Properties


### Gradient

Specifies the series gradient.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






