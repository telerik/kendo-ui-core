---
title: MapBaseLayerSettings
---

# Kendo.Mvc.UI.MapBaseLayerSettings
Kendo UI MapLayerDefaultsMarkerSettings class



