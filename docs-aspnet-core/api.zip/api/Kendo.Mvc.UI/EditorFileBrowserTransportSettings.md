---
title: EditorFileBrowserTransportSettings
---

# Kendo.Mvc.UI.EditorFileBrowserTransportSettings
Kendo UI EditorFileBrowserTransportSettings class



## Properties


### Read

Options or URL for remote file retrieval.

### UploadUrl

The URL which will handle the upload of the new files. If not specified the Upload button will not be displayed.

### FileUrl

The URL responsible for serving the original file. A file name placeholder should be specified. By default the placeholder value is URL encoded. If this is not desired, use a function.

### Destroy

Options or URL which will handle the file and directory deletion. If not specified the delete button will not be present.

### Create

Options or URL which will handle the directory creation. If not specified that create new folder button will not be present.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






