---
title: GridExcelSettings
---

# Kendo.Mvc.UI.GridExcelSettings
Defines the fluent API for configuring GridExcelSettings



## Properties


### AllPages

If set to true the grid will export all pages of data. By default the grid exports only the current page.

### FileName

Specifies the file name of the exported Excel file.

### Filterable

Enables or disables column filtering in the Excel file. Not to be mistaken with the grid filtering feature.

### Collapsible

Enables or disables collapsible (grouped) rows, for grids with aggregates.

### ForceProxy

If set to true, the content will be forwarded to proxyURL even if the browser supports saving files locally.

### ProxyURL

The URL of the server side proxy which will stream the file to the end user.A proxy will be used when the browser isn't capable of saving files locally. Such browsers are IE version 9 and lower and Safari.The developer is responsible for implementing the server-side proxy.The proxy will receive a POST request with the following parameters in the request body: contentType: The MIME type of the file; base64: The base-64 encoded file content or fileName: The file name, as requested by the caller.. The proxy should return the decoded file with the "Content-Disposition" header set toattachment; filename="<fileName.xslx>".




## Methods


### SerializeSettings
Serialize current instance to Dictionary






