---
title: ChartSeriesDefaultsSettings
---

# Kendo.Mvc.UI.ChartSeriesDefaultsSettings
Defines the Chart series defaults settings



## Properties


### Area

The Area series default settings.

### Bar

The Bar series default settings.

### BoxPlot

The BoxPlot series default settings.

### Bubble

The Bubble series default settings.

### Bullet

The Bullet series default settings.

### Candlestick

The Candlestick series default settings.

### Column

The Column series default settings.

### Donut

The Donut series default settings.

### Funnel

The Funnel series default settings.

### HorizontalWaterfall

The HorizontalWaterfall series default settings.

### Line

The Line series default settings.

### OHLC

The OHLC series default settings.

### Pie

The Pie series default settings.

### PolarArea

The PolarArea series default settings.

### PolarLine

The PolarLine series default settings.

### PolarScatter

The PolarScatter series default settings.

### RadarArea

The RadarArea series default settings.

### RadarColumn

The RadarColumn series default settings.

### RadarLine

The RadarLine series default settings.

### RangeArea

The RangeArea series default settings.

### RangeBar

The RangeBar series default settings.

### RangeColumn

The RangeColumn series default settings.

### Scatter

The Scatter series default settings.

### ScatterLine

The ScatterLine series default settings.

### VerticalArea

The VerticalArea series default settings.

### VerticalBoxPlot

The VerticalBoxPlot series default settings.

### VerticalBullet

The VerticalBullet series default settings.

### VerticalLine

The VerticalLine series default settings.

### VerticalRangeArea

The VerticalRangeArea series default settings.

### Waterfall

The Waterfall series default settings.



