---
title: LinearGaugeScaleLabelsSettings
---

# Kendo.Mvc.UI.LinearGaugeScaleLabelsSettings
Kendo UI LinearGaugeScaleLabelsSettings class



## Properties


### Opacity

Gets or sets the label opacity.

### Background

The background color of the labels. Any valid CSS color string will work here, including hex and rgb

### Border

The border of the labels.

### Color

The text color of the labels. Any valid CSS color string will work here, including hex and rgb.

### Font

The font style of the labels.

### Format

The format of the labels.

### Margin

The margin of the labels.

### Padding

The padding of the labels.

### Template

The label template. Template variables: value - the value.

### TemplateId

The id of the script element used for Template

### Visible

The visibility of the labels.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






