---
title: Gantt
---

# Kendo.Mvc.UI.Gantt
Kendo UI Gantt component



## Properties


### AutoBind

If set to false the widget will not bind to the data source during initialization. In this case data binding will occur when the change event of the data source is fired. By default the widget will bind to the data source specified in the configuration.

### ColumnResizeHandleWidth

Defines the width of the column resize handle in pixels. Apply a larger value for easier grasping.

### Columns

The configuration of the Gantt columns. An array of JavaScript objects or strings. A JavaScript objects are interpreted as column configurations. Strings are interpreted as thefield to which the column is bound. The Gantt will create a column for every item of the array.

### CurrentTimeMarker

If set to false the "current time" marker of the Gantt would not be displayed.

### Date

If set to some date and it is between the range start and range end of the selected view, the timeline of the currently selected view is scrolled to start from this date.

### Editable

If set to false the user won't be able to create, modify or delete tasks and dependencies.

### Navigatable

If set to true the user could navigate the widget using the keyboard. By default keyboard navigation is disabled.

### WorkDayStart

Sets the start of the work day.

### WorkDayEnd

Sets the end of the work day.

### WorkWeekStart

The start of working week (index based).

### WorkWeekEnd

The end of working week (index based).

### HourSpan

The span of an hour slot.

### Snap

If set to true the Gantt will snap tasks to the nearest slot during dragging (resizing or moving). Set it to false to allow free moving and resizing of tasks.

### Height

The height of the widget. Numeric values are treated as pixels.

### ListWidth

The width of the task list. Numeric values are treated as pixels.

### Messages

The configuration of the Gantt messages. Use this option to customize or localize the Gantt messages.

### Pdf

Configures the Kendo UI Gantt PDF export settings.

### Range

Configures the Kendo UI Gantt range settings.

### Resizable

If set to true allows users to resize columns by dragging their header borders. By default resizing is disabled.

### Selectable

If set to false the user won't be able to select tasks in the Gantt. By default selection is enabled and triggers the change event.

### ShowWorkDays

If set to false, Gantt views will show all days of the week. By default the views display only business days.

### ShowWorkHours

If set to false, the day view will show all hours of the day. By default the view displays only business hours.

### TaskTemplate

The template used to render the gantt tasks.The fields which can be used in the template are the task fields

### TaskTemplateId

The id of the script element used for TaskTemplate

### Toolbar

If a String value is assigned to the toolbar configuration option, it will be treated as a single string template for the whole Gantt Toolbar, and the string value will be passed as an argument to a kendo.template() function.If a Function value is assigned (it may be a kendo.template() function call or a generic function reference), then the return value of the function will be used to render the Gantt Toolbar contents.If an Array value is assigned, it will be treated as the list of commands displayed in the Gantt Toolbar. Commands can be custom or built-in ("append", "pdf").The "append" command adds a new task to the gantt.The "pdf" command exports the gantt in PDF format.

### Tooltip

The task tooltip configuration options.

### Views

The views displayed by the Gantt and their configuration. The array items can be either objects specifying the view configuration or strings representing the view types (assuming default configuration). By default the Kendo UI Gantt widget displays "day", "week", and "month" views.

### RowHeight

The height of the table rows. Numeric values are treated as pixels.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






