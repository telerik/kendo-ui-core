---
title: DropDownTree
---

# Kendo.Mvc.UI.DropDownTree
Kendo UI DropDownTree component



## Properties


### Items

Gets the items of the dropdowntree.

### DataSource

Gets or sets DataSource.

### DataSourceId

Gets or sets DataSource id.

### ItemAction

Gets or sets the item action.

### ValueArray

Gets or sets the value as enumerable.

### AutoBind

Controls whether to bind the widget to the data source on initialization.

### AutoClose

Controls whether to close the popup when item is selected or checked.

### AutoWidth

If set to true, the widget automatically adjusts the width of the popup element and does not wrap up the item label.

### CheckAll

When this options is set to true and checkboxes are enabled, a tristate checkbox appears above the embedded treeview. Clicking that checkbox will check or uncheck all the loaded enabled items of the treeview.

### CheckAllTemplate

The template used to render the checkAll label. By default, the widget displays only a span element with text "Check all".

### CheckAllTemplateId

The id of the script element used for CheckAllTemplate

### Checkboxes

If true or an object, renders checkboxes beside each node. In this case the widget value should be an array.

### ClearButton

Unless this option is set to false, a button will appear when hovering the widget. Clicking that button will reset the widget's value and will trigger the change event.

### DataImageUrlField

Sets the field of the data item that provides the image URL of the DropDownTree nodes.

### DataSpriteCssClassField

Sets the field of the data item that provides the sprite CSS class of the nodes. If an array, each level uses the field that is at the same index in the array, or the last item in the array.

### DataTextField

Sets the field of the data item that provides the text content of the nodes. If an array, each level uses the field that is at the same index in the array, or the last item in the array.

### DataUrlField

Sets the field of the data item that provides the link URL of the nodes.

### DataValueField

The field of the data item that provides the value of the widget. If an array, each level uses the field that is at the same index in the array, or the last item in the array.

### Delay

Specifies the delay in milliseconds after which the DropDownTree will start filtering dataSource.

### Enable

If set to false the widget will be disabled and will not allow user input. The widget is enabled by default and allows user input.

### EnforceMinLength

If set to true the widget will not show all items when the text of the search input cleared. By default, the widget shows all items when the text of the search input is cleared. Works in conjunction with minLength.

### FooterTemplate

The template used to render the footer template. The footer template receives the widget itself as a part of the data argument. Use the widget fields directly in the template.

### FooterTemplateId

The id of the script element used for FooterTemplate

### Height

Sets max-height of the embedded treeview in pixels. The default value is 200 pixels. If set to "Auto" the height of the popup will depend on the height of the treeview.

### IgnoreCase

If set to false case-sensitive search will be performed to find suggestions. The widget performs case-insensitive searching by default.

### LoadOnDemand

Indicates whether the child DataSources should be fetched lazily when parent groups get expanded. Setting this to true causes loading the child DataSources when expanding the parent node.

### Messages

The text messages displayed in the widget. Use it to customize or localize the messages.

### MinLength

The minimum number of characters the user must type before a search is performed. Set to a higher value if the search could match a lot of items.

### NoDataTemplate

The template used to render the "no data" template, which will be displayed if no results are found or the underlying data source is empty. The noData template receives the widget itself as a part of the data argument. The template will be evaluated on every widget data bound.

### NoDataTemplateId

The id of the script element used for NoDataTemplate

### Placeholder

The hint displayed by the widget when it is empty. Not set by default.

### Popup

The options that will be used for the popup initialization. For more details about the available options refer to Popup documentation.

### HeaderTemplate

Specifies a static HTML content, which will be rendered as a header of the popup element.

### HeaderTemplateId

The id of the script element used for HeaderTemplate

### ValueTemplate

The template used to render the value and the or the selected tags.

### ValueTemplateId

The id of the script element used for ValueTemplate

### TagMode

Represents available tag modes of DropDownTree.

### Template

Template for rendering each node.

### TemplateId

The id of the script element used for Template

### Text

The text of the widget used when the autoBind is set to false.

### Value

Define the value of the widget. It accepts 'String' when it is in single selection mode and 'Array' when multiple selection is enabled via checkboxes property.

### ValuePrimitive

Specifies the value binding behavior for the widget. If set to true, the View-Model field will be updated with the selected item value field. If set to false, the View-Model field will be updated with the selected item.

### Filter

The filtering method used to determine the suggestions for the current value. Filtration is turned off by default.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






