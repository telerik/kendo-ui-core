---
title: ListBoxToolbarPosition
---

# Kendo.Mvc.UI.ListBoxToolbarPosition
Represents the listbox toolbar positions.


## Fields


### Top
#
The listbox's toolbar is positioned on the top

### Bottom
#
The listbox's toolbar is positioned on the bottom

### Left
#
The listbox's toolbar is positioned on the left

### Right
#
The listbox's toolbar is positioned on the right




