---
title: ArcGaugeScaleLabelsPaddingSettings
---

# Kendo.Mvc.UI.ArcGaugeScaleLabelsPaddingSettings
Kendo UI ArcGaugeScaleLabelsPaddingSettings class



## Properties


### Top

The top padding of the labels.

### Bottom

The bottom padding of the labels.

### Left

The left padding of the labels.

### Right

The right padding of the labels.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






