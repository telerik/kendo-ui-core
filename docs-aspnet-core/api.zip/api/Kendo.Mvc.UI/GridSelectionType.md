---
title: GridSelectionType
---

# Kendo.Mvc.UI.GridSelectionType
Represents the selection types supported by Kendo UI Grid for ASP.NET MVC



