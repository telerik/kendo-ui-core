---
title: ChartTextAlignment
---

# Kendo.Mvc.UI.ChartTextAlignment
Specifies the text alignment.


## Fields


### Left
#
The text is aligned to the left.

### Center
#
The text is aligned to the middle

### Right
#
The text is aligned to the right.




