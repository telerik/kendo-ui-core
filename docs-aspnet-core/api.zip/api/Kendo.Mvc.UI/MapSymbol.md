---
title: MapSymbol
---

# Kendo.Mvc.UI.MapSymbol
The bubble layer symbol type. Supported symbols are "circle" and "square".



