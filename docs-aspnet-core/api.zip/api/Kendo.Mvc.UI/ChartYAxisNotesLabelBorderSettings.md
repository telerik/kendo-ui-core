---
title: ChartYAxisNotesLabelBorderSettings
---

# Kendo.Mvc.UI.ChartYAxisNotesLabelBorderSettings
Kendo UI ChartYAxisNotesLabelBorderSettings class



## Properties


### Color

The color of the border. Accepts a valid CSS color string, including hex and rgb.

### DashType

The dash type of the border.The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### Width

The width of the border in pixels. By default the border width is set to zero which means that the border will not appear.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






