---
title: ChartSpacing
---

# Kendo.Mvc.UI.ChartSpacing
Kendo UI ChartSpacing class



## Properties


### Top

Gets or sets the top spacing.

### Right

Gets or sets the right spacing.

### Bottom

Gets or sets the bottom spacing.

### Left

Gets or sets the left spacing.




## Methods


### Serialize
Serializes the spacing settings to a Dictionary.






