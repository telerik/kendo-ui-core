---
title: ColorPickerPalette
---

# Kendo.Mvc.UI.ColorPickerPalette
Defines the palettes that can be used in the color picker.


## Fields


### None
#
Do not use a palette (allow selection of arbitrary colors)

### Basic
#
Use a palette of basic colors

### WebSafe
#
Use a palette of web-safe colors




