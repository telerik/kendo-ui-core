---
title: ChartBarLabelsPosition
---

# Kendo.Mvc.UI.ChartBarLabelsPosition
Specifies the position of the labels.


## Fields


### Center
#
the label is positioned at the center.

### InsideBase
#
The label is positioned inside, near the base of the bar.

### InsideEnd
#
The label is positioned inside, near the end of the point.

### OutsideEnd
#
The label is positioned outside, near the end of the point




