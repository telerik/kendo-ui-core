---
title: ChartLegendPosition
---

# Kendo.Mvc.UI.ChartLegendPosition
Specifies the legend position.


## Fields


### Top
#
The legend is positioned on the top

### Bottom
#
The legend is positioned on the bottom

### Left
#
The legend is positioned on the left

### Right
#
The legend is positioned on the right

### Custom
#
The legend is positioned using OffsetX and OffsetY




