---
title: GanttResourcesSettings
---

# Kendo.Mvc.UI.GanttResourcesSettings
Kendo UI GanttResourcesSettings class



