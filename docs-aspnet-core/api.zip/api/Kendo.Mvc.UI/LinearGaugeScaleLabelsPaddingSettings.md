---
title: LinearGaugeScaleLabelsPaddingSettings
---

# Kendo.Mvc.UI.LinearGaugeScaleLabelsPaddingSettings
Kendo UI LinearGaugeScaleLabelsPaddingSettings class



## Properties


### Top

The top padding of the labels.

### Bottom

The bottom padding of the labels.

### Left

The left padding of the labels.

### Right

The right padding of the labels.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






