---
title: ChartPointLabelsPosition
---

# Kendo.Mvc.UI.ChartPointLabelsPosition
Specifies the position of the labels.


## Fields


### Above
#
The label is positioned at the top of the marker.

### Below
#
the label is positioned at the bottom of the marker.

### Left
#
The label is positioned to the left of the marker.

### Right
#
The label is positioned to the right of the marker.




