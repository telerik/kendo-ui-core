---
title: GridAllowCopySettings
---

# Kendo.Mvc.UI.GridAllowCopySettings
Kendo UI GridAllowCopySettings class



## Properties


### Delimeter

Changes the delimeter between the items on the same row. Use this option if you want to change the default TSV format to CSV - set the delimeter to comma ','.

### Enabled

If set to true and selection of the Grid is enabled the user could copy the selection into the clipboard and paste it into Excel or other similar programs that understand TSV/CSV formats. By default allowCopy is disabled and the default format is TSV. Can be set to a JavaScript object which represents the allowCopy configuration.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






