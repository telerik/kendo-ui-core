---
title: GridActionColumn
---

# Kendo.Mvc.UI.GridActionColumn
Defines the fluent API for configuring GridActionColumn



## Properties


### Commands

Gets the commands for the column



