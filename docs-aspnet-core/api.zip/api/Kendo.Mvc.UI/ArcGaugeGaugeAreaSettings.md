---
title: ArcGaugeGaugeAreaSettings
---

# Kendo.Mvc.UI.ArcGaugeGaugeAreaSettings
Kendo UI ArcGaugeGaugeAreaSettings class



## Properties


### Background

The background of the gauge area. Any valid CSS color string will work here, including hex and rgb.

### Border

The border of the gauge area.

### Height

The height of the gauge area.

### Margin

The margin of the gauge area.

### Width

The width of the gauge area.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






