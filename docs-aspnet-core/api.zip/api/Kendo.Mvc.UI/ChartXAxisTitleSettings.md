---
title: ChartXAxisTitleSettings
---

# Kendo.Mvc.UI.ChartXAxisTitleSettings
Kendo UI ChartXAxisTitleSettings class



## Properties


### Background

The background color of the title. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the title.

### Color

The text color of the title. Accepts a valid CSS color string, including hex and rgb.

### Font

The font style of the title.

### Margin

The margin of the title. A numeric value will set all margins.

### Padding

The padding of the title. A numeric value will set all paddings.

### Rotation

The rotation angle of the title. By default the title is not rotated.

### Text

The text of the title.

### Visible

If set to true the chart will display the scatter chart x axis title. By default the scatter chart x axis title is visible.

### Visual

A function that can be used to create a custom visual for the title. The available argument fields are: text - the label text.; rect - the kendo.geometry.Rect that defines where the visual should be rendered.; sender - the chart instance (may be undefined).; options - the label options. or createVisual - a function that can be used to get the default visual..

### Position

Specifies the title position.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






