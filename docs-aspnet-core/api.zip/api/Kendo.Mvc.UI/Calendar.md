---
title: Calendar
---

# Kendo.Mvc.UI.Calendar
Kendo UI Calendar component



## Properties


### Culture

Specifies the culture info used by the widget.

### Dates

Specifies a list of dates, which will be passed to the month template.

### Footer

The template which renders the footer. If false, the footer will not be rendered.

### Format

Specifies the format, which is used to parse value set with value() method.

### Max

Specifies the maximum date, which the calendar can show.

### Messages

Allows localization of the strings that are used in the widget.

### Min

Specifies the minimum date, which the calendar can show.

### Selectable

By default user is able to select a single date. The property can also be set to "multiple" in order the multiple  date selection to be enabled. More information about multiple selection can be found in the Selection article.

### SelectDates

Specifies which dates to be selected when the calendar is initialized.

### WeekNumber

If set to true a week of the year will be shown on the left side of the calendar.

### Value

Specifies the selected date.

### Start



### Depth

Specifies the navigation depth.

### MonthTemplate






## Methods


### SerializeSettings
Serialize current instance to Dictionary






