---
title: ChartSeriesMarkersBorderSettings
---

# Kendo.Mvc.UI.ChartSeriesMarkersBorderSettings
Kendo UI ChartSeriesMarkersBorderSettings class



## Properties


### Color

The color of the border. Accepts a valid CSS color string, including hex and rgb.

### Width

The width of the border in pixels. By default the border width is set to zero which means that the border will not appear.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






