---
title: ListViewEditingSettings
---

# Kendo.Mvc.UI.ListViewEditingSettings
Kendo UI ListViewEditingSettings class



## Properties


### Enabled

Gets or sets a boolean value that determines if editing is enabled in the ListView.

### TemplateName

Specifies the name of the editor template.

### DefaultDataItem

Defines the default data item for the ListView editor.



