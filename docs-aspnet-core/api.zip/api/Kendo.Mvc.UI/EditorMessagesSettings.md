---
title: EditorMessagesSettings
---

# Kendo.Mvc.UI.EditorMessagesSettings
Kendo UI EditorMessagesSettings class



## Properties


### AccessibilityTab

The title of the Accessibility in the Table Wizard dialog.

### AddColumnLeft

The title of the tool that adds table columns on the left of the selection.

### AddColumnRight

The title of the tool that adds table columns on the right of the selection.

### AddRowAbove

The title of the tool that adds table rows above the selection.

### AddRowBelow

The title of the tool that adds table rows below the selection.

### AlignCenter

The title of the tool that aligns the cell text.

### AlignCenterBottom

The title of the tool that aligns the cell text.

### AlignCenterMiddle

The title of the tool that aligns the cell text.

### AlignCenterTop

The title of the tool that aligns the cell text.

### AlignLeft

The title of the tool that aligns the cell text.

### AlignLeftBottom

The title of the tool that aligns the cell text.

### AlignLeftMiddle

The title of the tool that aligns the cell text.

### AlignLeftTop

The title of the tool that aligns the cell text.

### AlignRemove

The title of the tool that removes the cell text's alignment.

### AlignRight

The title of the tool that aligns the cell text.

### AlignRightBottom

The title of the tool that aligns the cell text.

### AlignRightMiddle

The title of the tool that aligns the cell text.

### AlignRightTop

The title of the tool that aligns the cell text.

### Alignment

The title of the tool that aligns the cell text.

### AssociateCellsWithHeaders

The title of the Associate cells with headers tool.

### BackColor

The title of the tool that changes the text background color.

### Background

The title of the tool that changes the text background of the tables/cells.

### Bold

The title of the tool that makes text bold.

### Border

The title of the tool that changes the border of tables.

### Style

The title of the tool that applies styling to elements. Deprecated.

### Caption

The title of the tool that adds caption to tables.

### CellMargin

The title of the tool that applies margin to table cells.

### CellPadding

The title of the tool that applies padding to table cells.

### CellSpacing

The title of the tool that applies spacing to table cells.

### CellTab

The title of the Cell tab in Table Wizard dialog.

### CleanFormatting

The title of the Clean Formatting tool.

### CollapseBorders

The title of the Collapse borders option in Table Wizard.

### Columns

The title of the Columns tool in Table Wizard.

### CreateLink

The title of the tool that creates hyperlinks.

### CreateTable

The title of the tool that inserts tables.

### CreateTableHint

The status text of the tool that inserts tables, which indicates the dimensions of the inserted table.

### CssClass

The title of the CSS Class dropdown tool.

### DeleteColumn

The title of the tool that deletes selected table columns.

### DeleteRow

The title of the tool that deletes selected table rows.

### DialogCancel

The label of the cancel button in all editor dialogs.

### DialogInsert

The label of the insert button in all editor dialogs.

### DialogOk

The title of the OK buttons in editor's dialogs.

### DialogUpdate

The label of the update button in all editor dialogs.

### EditAreaTitle

The title of the iframe editing area when a sandboxed editor is used. Used as a hint for screen readers.

### FileTitle

The caption for the file title in the insertFile dialog.

### FileWebAddress

The caption for the file URL in the insertFile dialog.

### FontName

The title of the tool that changes the text font.

### FontNameInherit

The text that is shown when the text font will be inherited from the surrounding page.

### FontSize

The title of the tool that changes the text size.

### FontSizeInherit

The text that is shown when the text size will be inherited from the surrounding page.

### ForeColor

The title of the tool that changes the text color.

### FormatBlock

The title of the tool that lets users choose block formats. Deprecated.

### Formatting

The title of the tool that lets users choose block formats.

### Height

The title of the height fields.

### Id

The title of the id fields.

### ImageAltText

The caption for the image alternate text in the insertImage dialog.

### ImageHeight

The caption for the image height in the insertImage dialog.

### ImageWebAddress

The caption for the image URL in the insertImage dialog.

### ImageWidth

The caption for the image width in the insertImage dialog.

### Indent

The title of the tool that indents the content.

### InsertFile

The title of the tool that inserts links to files.

### InsertHtml

The title of the tool that inserts HTML snippets.

### InsertImage

The title of the tool that inserts images.

### InsertOrderedList

The title of the tool that inserts an ordered list.

### InsertUnorderedList

The title of the tool that inserts an unordered list.

### Italic

The title of the tool that makes text italicized.

### OverflowAnchor

The title of the tool that shows the overflow tools.

### JustifyCenter

The title of the tool that aligns text in the center.

### JustifyFull

The title of the tool that justifies text both left and right.

### JustifyLeft

The title of the tool that aligns text on the left.

### JustifyRight

The title of the tool that aligns text on the right.

### LinkOpenInNewWindow

The caption for the checkbox for opening the link in a new window in the createLink dialog.

### LinkText

The caption for the link text in the createLink dialog.

### LinkToolTip

The caption for the link Tooltip in the createLink dialog.

### LinkWebAddress

The caption for the URL in the createLink dialog.

### Outdent

The title of the tool that outdents the content.

### Print

The title of the Print tool.

### Rows

The title of the Rows field in Table Wizard.

### SelectAllCells

The title of the Select All Cells tool.

### Strikethrough

The title of the tool that strikes through text.

### Subscript

The title of the tool that makes text subscript.

### Summary

The title of the Summary field in Table Wizard.

### Superscript

The title of the tool that makes text superscript.

### TableTab

The title of the Table tab in Table Wizard.

### TableWizard

The title of the Table Wizard tool.

### Underline

The title of the tool that underlines text.

### Units

The label of the Units dropdowns in TableWizard dialog.

### Unlink

The title of the tool that removes hyperlinks.

### ViewHtml

The title of the tool that shows the editor value as HTML.

### Width

The title of the Width fields.

### WrapText

The title of the Wrap Text option in Table Wizard.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






