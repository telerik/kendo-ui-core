---
title: ContextMenuOrientation
---

# Kendo.Mvc.UI.ContextMenuOrientation
Specifies the orientation in which the menu items will be ordered


## Fields


### Vertical
#
Items are oredered vertically

### Horizontal
#
Items are oredered horizontally




