---
title: GridNoRecordsSettings
---

# Kendo.Mvc.UI.GridNoRecordsSettings
Kendo UI GridNoRecordsSettings class



## Properties


### Template

The template which is rendered when current view contains no records.

### TemplateId

The id of the script element used for Template

### Enabled

If set to true and current view contains no records, message similar to "No records available" will be displayed. By default this option is disabled.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






