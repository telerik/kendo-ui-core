---
title: MapMarker
---

# Kendo.Mvc.UI.MapMarker
Kendo UI MapMarker class



## Properties


### Location

The marker location on the map. Coordinates are listed as [Latitude, Longitude].

### Title

The marker title. Displayed as browser tooltip.

### Shape

The marker shape. Supported shapes are "pin" and "pinTarget".




## Methods


### SerializeSettings
Serialize current instance to Dictionary






