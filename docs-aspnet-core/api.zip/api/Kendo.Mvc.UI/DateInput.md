---
title: DateInput
---

# Kendo.Mvc.UI.DateInput
Kendo UI DateInput component



## Properties


### Format

Specifies the format, which is used to format the value of the DateInput displayed in the input. The format also will be used to parse the input.

### Max

Specifies the maximum date which can be entered in the input.

### Min

Specifies the minimum date that which be entered in the input.

### Value

Specifies the selected date.

### Messages

The messages that DateInput uses.  Use it to customize or localize the placeholders of each date/time part.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






