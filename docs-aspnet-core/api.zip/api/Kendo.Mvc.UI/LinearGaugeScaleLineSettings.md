---
title: LinearGaugeScaleLineSettings
---

# Kendo.Mvc.UI.LinearGaugeScaleLineSettings
Kendo UI LinearGaugeScaleLineSettings class



## Properties


### Color

The color of the lines. Any valid CSS color string will work here, including hex and rgb.

### DashType

The dash type of the line.

### Visible

The visibility of the lines.

### Width

The width of the line..




## Methods


### SerializeSettings
Serialize current instance to Dictionary






