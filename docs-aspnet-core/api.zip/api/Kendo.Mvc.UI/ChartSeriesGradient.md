---
title: ChartSeriesGradient
---

# Kendo.Mvc.UI.ChartSeriesGradient
Specifies the series gradient.


## Fields


### Glass
#
The series have glass effect overlay.

### None
#
The series do not have grdient.

### RoundedBevel
#
The segments have round bevel effect overlay.

### SharpBevel
#
The segments have sharp bevel effect overlay.




