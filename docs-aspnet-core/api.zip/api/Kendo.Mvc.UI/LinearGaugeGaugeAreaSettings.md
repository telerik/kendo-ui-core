---
title: LinearGaugeGaugeAreaSettings
---

# Kendo.Mvc.UI.LinearGaugeGaugeAreaSettings
Kendo UI LinearGaugeGaugeAreaSettings class



## Properties


### Border

The border of the gauge area.

### Height

The height of the gauge area.  By default, the vertical gauge is 200px and the horizontal one is 60px.

### Margin

The margin of the gauge area.

### Width

The width of the gauge area.  By default the vertical gauge is 60px and horizontal gauge is 200px.

### Background

The background of the gauge area. Any valid CSS color string will work here, including hex and rgb.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






