---
title: GanttColumn
---

# Kendo.Mvc.UI.GanttColumn
Kendo UI GanttColumn class



## Properties


### Field

The field to which the column is bound. The value of this field is displayed by the column during data binding.The field name should be a valid Javascript identifier and should contain only alphanumeric characters (or "$" or "_"), and may not start with a digit.

### Title

The text that is displayed in the column header cell. If not set the field is used.

### Format

The format that is applied to the value before it is displayed. Takes the form "{0:format}" where "format" is a standard number format,custom number format, standard date format or a custom date format.

### Width

The width of the column. Numeric values are treated as pixels.

### Editable

Specifies whether this column can be edited by the user.

### Sortable

If set to true the user could sort this column by clicking its header cells. By default sorting is disabled.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






