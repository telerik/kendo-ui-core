---
title: ChartYAxis
---

# Kendo.Mvc.UI.ChartYAxis
Kendo UI ChartYAxis class



## Properties


### AxisCrossingValue

Value at which the Y axis crosses this axis. (Only for object)Value indices at which the Y axes cross the value axis. (Only for array)Date at which the Y axis crosses this axis. (Only for date)

### Background

The background color of the axis.

### BaseUnit

The base time interval for the axis labels. The default baseUnit is determined automatically from the value range. Available options: milliseconds; seconds; minutes; hours; days; weeks; months or years.

### Color

The color of the axis. Accepts a valid CSS color string, including hex and rgb.

### Crosshair

The crosshair configuration options.

### Labels

The axis labels configuration.

### Line

The configuration of the axis lines. Also affects the major and minor ticks, but not the grid lines.

### MajorGridLines

The configuration of the major grid lines. These are the lines that are an extension of the major ticks through the body of the chart.

### MinorGridLines

The configuration of the minor grid lines. These are the lines that are an extension of the minor ticks through the body of the chart.

### MinorTicks

The configuration of the y axis minor ticks.

### MajorTicks

The configuration of the scatter chart y axis major ticks.

### MajorUnit

The interval between major divisions. If this is a date axis the value represents the number of xAxis.baseUnits between major divisions. If the yAxis.type is set to "log", the majorUnit value will be used for the base of the logarithm.

### Max

The maximum value of the axis.

### Min

The minimum value of the axis.

### MinorUnit

The interval between minor divisions. It defaults to 1/5 of the yAxis.majorUnit. If the yAxis.type is set to "log", the minorUnit value represents the number of divisions between two major units and defaults to the major unit minus one.

### Name

The unique axis name. Used to associate a series with a y axis using the series.yAxis option.

### NarrowRange

If set to true the chart will prevent the automatic axis range from snapping to 0. Setting it to false will force the automatic axis range to snap to 0.

### Pane

The name of the pane that the axis should be rendered in. The axis will be rendered in the first (default) pane if not set.

### PlotBands

The plot bands of the y axis.

### Reverse

If set to true the value axis direction will be reversed. By default values increase from left to right and from bottom to top.

### Title

The title configuration of the scatter chart y axis.

### Type

The axis type.The supported values are: "numeric" - numeric axis.; "date" - specialized axis for displaying chronological data. or "log" - logarithmic axis..

### Visible

If set to true the chart will display the y axis. By default the y axis is visible.

### Notes

The y axis notes configuration.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






