---
title: ListBox
---

# Kendo.Mvc.UI.ListBox
Kendo UI ListBox component



## Properties


### AutoBind

If set to false, the widget will not bind to the data source during initialization. In this case, the data binding will occur when the change event of the data source is fired. By default, the ListBox will bind to the data source that is specified in the configuration.

### ConnectWith

The id of the target ListBox to which items from the source ListBox will be transferred and vice versa. If you have to transfer items from the target ListBox over its toolbar, then you also need to set its connectWith option.

### DataTextField

The field of the data item that provides the text content of the list items. Based on this field, the widget filters the data source.

### DataValueField

The field of the data item that provides the value of the widget.

### Draggable

Indicates whether the ListBox items can be dragged and dropped.

### DropSources

Array of id strings which determines the ListBoxes that can drag and drop their items to the current ListBox. The dropSources option describes a one way relationship. If you want a two-way connection, then set the dropSources option on both widgets.

### Navigatable

Indicates whether the keyboard navigation is enabled or disabled.

### Messages

Defines the localization texts for the ListBox. Used primarily for localization.

### Template

Specifies the item template of the ListBox.

### TemplateId

The id of the script element used for Template

### Toolbar

Defines the settings for displaying the toolbar of the ListBox. The toolbar allows you to execute a set of predefined actions.By default, the toolbar is not displayed. If the tools array is populated, then the toolbar and the corresponding tools are displayed.

### Selectable

Represents the selectable options.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






