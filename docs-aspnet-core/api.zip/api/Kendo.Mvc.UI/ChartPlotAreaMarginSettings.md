---
title: ChartPlotAreaMarginSettings
---

# Kendo.Mvc.UI.ChartPlotAreaMarginSettings
Kendo UI ChartPlotAreaMarginSettings class



## Properties


### Bottom

The bottom margin of the chart plot area.

### Left

The left margin of the chart plot area.

### Right

The right margin of the chart plot area.

### Top

The top margin of the chart plot area.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






