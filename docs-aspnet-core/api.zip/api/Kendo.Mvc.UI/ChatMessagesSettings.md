---
title: ChatMessagesSettings
---

# Kendo.Mvc.UI.ChatMessagesSettings
Kendo UI ChatMessagesSettings class



## Properties


### Placeholder

The hint displayed in the input textbox of the widget.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






