---
title: MapLayerDefaultsTileSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsTileSettings
Kendo UI MapLayerDefaultsTileSettings class



## Properties


### UrlTemplate

The URL template for tile layers. Template variables: x - X coordinate of the tile; y - Y coordinate of the tile; zoom - zoom level or subdomain - Subdomain for this tile. See subdomains.

### UrlTemplateId

The id of the script element used for UrlTemplate

### Attribution

The attribution of all tile layers.

### Subdomains

The subdomain of all tile layers.

### Opacity

The the opacity of all tile layers.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






