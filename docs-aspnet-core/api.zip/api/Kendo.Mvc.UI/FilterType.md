---
title: FilterType
---

# Kendo.Mvc.UI.FilterType
The filtering method used to determine the suggestions for the current value.


## Fields


### StartsWith
#
Matches values starting with the typed string

### EndsWith
#
Matches values ending with the typed string

### Contains
#
Matches values containing the typed string




