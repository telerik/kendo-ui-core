---
title: ChartSeriesTooltipSettings
---

# Kendo.Mvc.UI.ChartSeriesTooltipSettings
Kendo UI ChartSeriesTooltipSettings class



## Properties


### Background

The background color of the tooltip. Accepts a valid CSS color string, including hex and rgb.

### Border

The border configuration options.

### Color

The text color of the tooltip. Accepts a valid CSS color string, including hex and rgb.

### Font

The tooltip font.

### Format

The format of the labels. Uses kendo.format.Format placeholders: Area, bar, column, line, pie, radarArea, radarColumn and radarLine{0} - value; Bubble{0} - x value{1} - y value{2} - size value{3} - category name; Scatter, scatterLine{0} - x value{1} - y value; PolarArea, polarLine and polarScatter{0} - x value (degrees){1} - y value; Candlestick and OHLC{0} - open value{1} - high value{2} - low value{3} - close value{4} - category name or RangeArea, rangeBar, rangeColumn{0} - from value{1} - to value.

### Padding

The padding of the tooltip. A numeric value will set all paddings.

### Template

The template which renders the tooltip.The fields which can be used in the template are: category - the category name; dataItem - the original data item used to construct the point. Will be null if binding to array.; series - the data series; value - the point value (either a number or an object); runningTotal - the sum of point values since the last "runningTotal" summary point. Available for waterfall series. or total - the sum of all previous series values. Available for waterfall series..

### TemplateId

The id of the script element used for Template

### Visible

If set to true the chart will display the series tooltip. By default the series tooltip is not displayed.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






