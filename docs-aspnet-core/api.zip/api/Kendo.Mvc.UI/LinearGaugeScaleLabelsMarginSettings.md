---
title: LinearGaugeScaleLabelsMarginSettings
---

# Kendo.Mvc.UI.LinearGaugeScaleLabelsMarginSettings
Kendo UI LinearGaugeScaleLabelsMarginSettings class



## Properties


### Top

The top margin of the labels.

### Bottom

The bottom margin of the labels.

### Left

The left margin of the labels.

### Right

The right margin of the labels.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






