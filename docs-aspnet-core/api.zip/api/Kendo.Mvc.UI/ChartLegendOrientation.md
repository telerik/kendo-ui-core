---
title: ChartLegendOrientation
---

# Kendo.Mvc.UI.ChartLegendOrientation
Specifies the legend orientation.


## Fields


### Horizontal
#
The orientation is horizontal.

### Vertical
#
The orientation is vertical.




