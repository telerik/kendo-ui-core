---
title: ChartZoomableMousewheelSettings
---

# Kendo.Mvc.UI.ChartZoomableMousewheelSettings
Kendo UI ChartZoomableMousewheelSettings class



## Properties


### Lock

Specifies an axis that should not be zoomed.

### Enabled

Specifies if the chart can be zoomed using the mouse wheel.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






