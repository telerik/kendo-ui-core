---
title: MaskedTextBox
---

# Kendo.Mvc.UI.MaskedTextBox
Kendo UI MaskedTextBox component



## Properties


### ClearPromptChar

Specifies whether the widget will replace the prompt characters with spaces on blur. Prompt chars will be shown again on focus (available since Q2 2014 SP1).

### Culture

Specifies the culture info used by the widget.

### Mask

Specifies the input mask. The following mask rules are supported: 0 - Digit. Accepts any digit between 0 and 9.; 9 - Digit or space. Accepts any digit between 0 and 9, plus space.; # - Digit or space. Like 9 rule, but allows also (+) and (-) signs.; L - Letter. Restricts input to letters a-z and A-Z. This rule is equivalent to [a-zA-Z] in regular expressions.; ? - Letter or space. Restricts input to letters a-z and A-Z. This rule is equivalent to [a-zA-Z] in regular expressions.; & - Character. Accepts any character. The rule is equivalent to \S in regular expressions.; C - Character or space. Accepts any character. The rule is equivalent to . in regular expressions.; A - Alphanumeric. Accepts letters and digits only.; a - Alphanumeric or space. Accepts letters, digits and space only.; . - Decimal placeholder. The decimal separator will be gotten from the current culture used by Kendo.; , - Thousands placeholder. The display character will be gotten from the current culture used by Kendo. or $ - Currency symbol. The display character will be gotten from the current culture used by Kendo..

### PromptChar

Specifies the character used to represent the absence of user input in the widget

### UnmaskOnPost

Specifies whether the widget will unmask the input value on form post (available since Q1 2015).

### Value

Specifies the value of the MaskedTextBox widget.

### Enable

Enables or disables the textbox




## Methods


### SerializeSettings
Serialize current instance to Dictionary






