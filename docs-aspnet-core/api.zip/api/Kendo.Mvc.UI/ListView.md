---
title: ListView
---

# Kendo.Mvc.UI.ListView
Kendo UI ListView component



## Properties


### DataSource

Gets the DataSource settings.

### DataSourceId

Gets or sets the name of the external DataSource used by the ListView.

### ClientTemplateId

Gets or sets the id of the client template used to render ListView items.

### ClientAltTemplateId

Gets or sets the id of the client template used to render alternating ListView items.

### Pageable

Gets the ListView paging settings.

### Editable

Gets the ListView editing settings.

### EditorHtml

Gets or sets the ListView editor HTML.

### AutoBind

If set to false the widget will not bind to the data source during initialization. In this case data binding will occur when the change event of the data source is fired. By default the widget will bind to the data source specified in the configuration.

### Navigatable

Indicates whether keyboard navigation is enabled/disabled.

### TagName

Specifies ListView wrapper element tag name.

### Selectable

Specifies whether item selection is allowed. By default selection is disabled




## Methods


### WriteHtml(System.IO.TextWriter)
Writes the ListView HTML output.


#### Parameters

##### writer `System.IO.TextWriter`
The text writer instance.





### WriteInitializationScript(System.IO.TextWriter)
Writes the ListView initialization script.


#### Parameters

##### writer `System.IO.TextWriter`
The text writer instance.





### VerifySettings
Verifies if all required settings are present in the ListView.





### SerializeSettings
Serialize current instance to Dictionary






