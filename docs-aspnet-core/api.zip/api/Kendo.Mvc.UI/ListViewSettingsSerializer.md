---
title: ListViewSettingsSerializer
---

# Kendo.Mvc.UI.ListViewSettingsSerializer
Kendo UI ListViewSettingsSerializer class




## Methods


### Serialize(System.Collections.Generic.IDictionary\<System.String,System.Object\>)
Serializes the current instance to a Dictionary.


#### Parameters

##### options `System.Collections.Generic.IDictionary<System.String,System.Object>`
The 2 object in which settings will be serialized.






