---
title: ArcGaugeGaugeAreaMarginSettings
---

# Kendo.Mvc.UI.ArcGaugeGaugeAreaMarginSettings
Kendo UI ArcGaugeGaugeAreaMarginSettings class



## Properties


### Top

The top margin of the gauge area.

### Bottom

The bottom margin of the gauge area.

### Left

The left margin of the gauge area.

### Right

The right margin of the gauge area.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






