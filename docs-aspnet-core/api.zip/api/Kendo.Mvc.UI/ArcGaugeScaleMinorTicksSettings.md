---
title: ArcGaugeScaleMinorTicksSettings
---

# Kendo.Mvc.UI.ArcGaugeScaleMinorTicksSettings
Kendo UI ArcGaugeScaleMinorTicksSettings class



## Properties


### Color

The color of the minor ticks. Any valid CSS color string will work here, including hex and rgb.

### Size

The minor tick size. This is the length of the line in pixels that is drawn to indicate the tick on the scale.

### Visible

The visibility of the minor ticks.

### Width

The width of the minor ticks.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






