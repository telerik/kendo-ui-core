---
title: MapControlPosition
---

# Kendo.Mvc.UI.MapControlPosition
The position of the attribution control.


## Fields


### TopLeft
#
Positions the control at the top left corner

### TopRight
#
Positions the control at the top right corner

### BottomRight
#
Positions the control at the bottom right corner

### BottomLeft
#
Positions the control at the bottom left corner




