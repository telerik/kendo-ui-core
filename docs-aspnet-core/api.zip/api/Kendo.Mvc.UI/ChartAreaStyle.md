---
title: ChartAreaStyle
---

# Kendo.Mvc.UI.ChartAreaStyle
Specifies the preferred line rendering style.


## Fields


### Normal
#
Points will be connected with straight line.

### Step
#
Points will be connected with a line at right angles.

### Smooth
#
Points will be connected with smooth line.




