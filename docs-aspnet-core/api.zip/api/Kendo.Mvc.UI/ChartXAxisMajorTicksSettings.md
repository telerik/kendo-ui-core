---
title: ChartXAxisMajorTicksSettings
---

# Kendo.Mvc.UI.ChartXAxisMajorTicksSettings
Kendo UI ChartXAxisMajorTicksSettings class



## Properties


### Color

The color of the scatter chart x axis major ticks lines. Accepts a valid CSS color string, including hex and rgb.

### Size

The length of the tick line in pixels.

### Visible

If set to true the chart will display the scatter chart x axis major ticks. By default the category axis major ticks are visible.

### Width

The width of the major ticks in pixels.

### Step

The step of the x axis major ticks.

### Skip

The skip of the x axis major ticks.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






