---
title: ArcGaugeScaleLabelsBorderSettings
---

# Kendo.Mvc.UI.ArcGaugeScaleLabelsBorderSettings
Kendo UI ArcGaugeScaleLabelsBorderSettings class



## Properties


### Color

The color of the border. Any valid CSS color string will work here, including hex and rgb.

### Opacity

The opacity of the border. By default the border is opaque.

### Width

The width of the border.

### DashType

Specifies the line dash type.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






