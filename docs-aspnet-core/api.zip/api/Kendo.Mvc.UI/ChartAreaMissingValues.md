---
title: ChartAreaMissingValues
---

# Kendo.Mvc.UI.ChartAreaMissingValues
Specifies the behavior for handling missing values in the series.


## Fields


### Gap
#
The line stops before the missing point and continues after it.

### Interpolate
#
The value is interpolated from neighboring points.

### Zero
#
The value is assumed to be zero.




