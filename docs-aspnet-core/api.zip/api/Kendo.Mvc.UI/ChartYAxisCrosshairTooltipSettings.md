---
title: ChartYAxisCrosshairTooltipSettings
---

# Kendo.Mvc.UI.ChartYAxisCrosshairTooltipSettings
Kendo UI ChartYAxisCrosshairTooltipSettings class



## Properties


### Background

The background color of the tooltip. Accepts a valid CSS color string, including hex and rgb.

### Border

The border options.

### Color

The text color of the tooltip. Accepts a valid CSS color string, including hex and rgb.

### Font

The tooltip font.

### Format

The format used to display the tooltip. Uses kendo.format. Contains one placeholder ("{0}") which represents the value value.

### Padding

The padding of the crosshair tooltip. A numeric value will set all paddings.

### Template

The template which renders the tooltip.The fields which can be used in the template are: value - the value value.

### TemplateId

The id of the script element used for Template

### Visible

If set to true the chart will display the scatter chart y axis crosshair tooltip. By default the scatter chart y axis crosshair tooltip is not visible.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






