---
title: EditorFileBrowserSchemaSettings
---

# Kendo.Mvc.UI.EditorFileBrowserSchemaSettings
Kendo UI EditorFileBrowserSchemaSettings class



## Properties


### Model

Set the object which describes the file/directory entry fields. Note that a name, type and size fields should be set.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






