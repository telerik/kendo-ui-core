---
title: MapControlsZoomSettings
---

# Kendo.Mvc.UI.MapControlsZoomSettings
Kendo UI MapControlsZoomSettings class



## Properties


### Position

Specifies the position of the zoom control.

### Enabled

Configures or disables the built-in zoom control (+/- button).




## Methods


### SerializeSettings
Serialize current instance to Dictionary






