---
title: GridPageableSettings
---

# Kendo.Mvc.UI.GridPageableSettings
Defines the fluent API for configuring GridPageableSettings



## Properties


### AlwaysVisible

Gets or sets the AlwaysVisible property



