---
title: ChartChartAreaMarginSettings
---

# Kendo.Mvc.UI.ChartChartAreaMarginSettings
Kendo UI ChartChartAreaMarginSettings class



## Properties


### Bottom

The bottom margin of the chart area.

### Left

The left margin of the chart area.

### Right

The right margin of the chart area.

### Top

The top margin of the chart area.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






