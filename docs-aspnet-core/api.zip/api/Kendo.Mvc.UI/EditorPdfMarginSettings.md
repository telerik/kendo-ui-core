---
title: EditorPdfMarginSettings
---

# Kendo.Mvc.UI.EditorPdfMarginSettings
Kendo UI EditorPdfMarginSettings class



