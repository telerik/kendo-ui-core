---
title: ChartZoomDirection
---

# Kendo.Mvc.UI.ChartZoomDirection
Specifies the mousehweel zoom type.


## Fields


### Both
#
Both ends of the selection are moved.

### Left
#
The left selection edge is moved during zoom.

### Right
#
The right selection edge is moved during zoom.




