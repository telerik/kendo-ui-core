---
title: ChartAxisBaseUnit
---

# Kendo.Mvc.UI.ChartAxisBaseUnit
Specifies the base time interval for the axis.


## Fields


### Seconds
#
The time interval is seconds.

### Minutes
#
The time interval is minutes.

### Hours
#
The time interval is hours.

### Days
#
The time interval is days.

### Weeks
#
The time interval is weeks.

### Months
#
The time interval is months.

### Years
#
The time interval is years.

### Fit
#
Automatic base unit based on limit set from MaxDateGroups. Note that the BaseUnitStep setting will be disregarded.




