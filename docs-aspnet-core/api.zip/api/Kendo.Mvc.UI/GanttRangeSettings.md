---
title: GanttRangeSettings
---

# Kendo.Mvc.UI.GanttRangeSettings
Kendo UI GanttRangeSettings class



## Properties


### Start

If set to some date the timeline of all views will start from this date.

### End

If set to some date the timeline of all views will end to this date.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






