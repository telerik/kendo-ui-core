---
title: MapControlsAttributionSettings
---

# Kendo.Mvc.UI.MapControlsAttributionSettings
Kendo UI MapControlsAttributionSettings class



## Properties


### Position

Specifies the position of the attribtion control.

### Enabled

Configures or disables the built-in attribution control.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






