---
title: LinearGaugePointerTrackBorderSettings
---

# Kendo.Mvc.UI.LinearGaugePointerTrackBorderSettings
Kendo UI LinearGaugePointerTrackBorderSettings class



