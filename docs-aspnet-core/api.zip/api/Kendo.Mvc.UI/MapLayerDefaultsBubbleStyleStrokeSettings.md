---
title: MapLayerDefaultsBubbleStyleStrokeSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsBubbleStyleStrokeSettings
Kendo UI MapLayerDefaultsBubbleStyleStrokeSettings class



## Properties


### Color

The default stroke color for bubble layer symbols. Accepts a valid CSS color string, including hex and rgb.

### DashType

The default dash type for layer symbols. The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### Opacity

The default stroke opacity (0 to 1) for bubble layer symbols.

### Width

The default stroke width for bubble layer symbols.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






