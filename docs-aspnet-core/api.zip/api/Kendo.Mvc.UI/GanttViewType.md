---
title: GanttViewType
---

# Kendo.Mvc.UI.GanttViewType
The view type. Supported types are "day", "week", "month" and "year".



