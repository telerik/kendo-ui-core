---
title: ChartYAxisLabelsDateFormatsSettings
---

# Kendo.Mvc.UI.ChartYAxisLabelsDateFormatsSettings
Kendo UI ChartYAxisLabelsDateFormatsSettings class



## Properties


### Days

The format used when yAxis.baseUnit is set to "days".

### Hours

The format used when yAxis.baseUnit is set to "hours".

### Months

The format used when yAxis.baseUnit is set to "months".

### Weeks

The format used when yAxis.baseUnit is set to "weeks".

### Years

The format used when yAxis.baseUnit is set to "years".




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






