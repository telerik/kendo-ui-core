---
title: ChartSeriesMarkersSettings
---

# Kendo.Mvc.UI.ChartSeriesMarkersSettings
Kendo UI ChartSeriesMarkersSettings class



## Properties


### Background

The background color of the series markers.

### Border

The border of the markers.

### From

The chart series marker configuration for the "from" point. Supported for "rangeArea" and "verticalRangeArea" series.

### Size

The marker size in pixels.

### To

The chart series marker configuration for the "to" point. Supported for "rangeArea" and "verticalRangeArea" series.

### Visible

If set to true the chart will display the series markers. By default chart series markers are displayed.

### Visual

A function that can be used to create a custom visual for the markers. The available argument fields are: rect - the kendo.geometry.Rect that defines where the visual should be rendered.; options - the marker options.; createVisual - a function that can be used to get the default visual.; category - the category of the marker point.; dataItem - the dataItem of the marker point.; value - the value of the marker point.; sender - the chart instance. or series - the series of the marker point..

### Rotation

The rotation angle of the markers.

### Type

Specifies the shape of the marker.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






