---
title: ArcGaugeScaleMajorTicksSettings
---

# Kendo.Mvc.UI.ArcGaugeScaleMajorTicksSettings
Kendo UI ArcGaugeScaleMajorTicksSettings class



## Properties


### Color

The color of the major ticks.

### Size

The major tick size. This is the length of the line in pixels that is drawn to indicate the tick on the scale.

### Visible

The visibility of the major ticks.

### Width

The width of the major ticks.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






