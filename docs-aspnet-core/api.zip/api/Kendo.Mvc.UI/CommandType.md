---
title: CommandType
---

# Kendo.Mvc.UI.CommandType
Specifies the type of the item.



