---
title: DatePicker
---

# Kendo.Mvc.UI.DatePicker
Kendo UI DatePicker component



## Properties


### ARIATemplate

Specifies a template used to populate value of the aria-label attribute.

### ARIATemplateId

The id of the script element used for ARIATemplate

### Culture

Specifies the culture info used by the widget.

### DateInput

Specifies if the DatePicker will use DateInput for editing value

### Dates

Specifies a list of dates, which will be passed to the month template.

### Footer

The template which renders the footer of the calendar. If false, the footer will not be rendered.

### Format

Specifies the format, which is used to format the value of the DatePicker displayed in the input. The format also will be used to parse the input.For more information on date and time formats please refer to Date Formatting.

### Max

Specifies the maximum date, which the calendar can show.

### Min

Specifies the minimum date that the calendar can show.

### WeekNumber

If set to true a week of the year will be shown on the left side of the calendar. It is possible to define a template in order to customize what will be displayed.

### ParseFormats

Specifies a list of date formats used to parse the value set with value() method or by direct user input. If not set the value of the format will be used.  Note that the format option is always used during parsing.

### Value

Specifies the selected date.

### Start



### Depth

Specifies the navigation depth.

### MonthTemplate






## Methods


### SerializeSettings
Serialize current instance to Dictionary






