---
title: FlatColorPickerMessagesSettings
---

# Kendo.Mvc.UI.FlatColorPickerMessagesSettings
Kendo UI FlatColorPickerMessagesSettings class



## Properties


### Apply

Allows customization of "Apply" label.

### Cancel

Allows customization of "Cancel" label.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






