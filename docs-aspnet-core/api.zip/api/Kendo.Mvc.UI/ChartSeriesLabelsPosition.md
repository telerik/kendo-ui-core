---
title: ChartSeriesLabelsPosition
---

# Kendo.Mvc.UI.ChartSeriesLabelsPosition
Specifies the position of the labels.


## Fields


### Above
#
The label is positioned at the top of the marker.

### Below
#
the label is positioned at the bottom of the marker.

### Bottom
#
The label is positioned at the bottom of the segment.

### Center
#
the label is positioned at the center.

### InsideBase
#
The label is positioned inside, near the base of the bar.

### InsideEnd
#
The label is positioned inside, near the end of the point.

### Left
#
The label is positioned to the left of the marker.

### OutsideEnd
#
The label is positioned outside, near the end of the point

### Right
#
The label is positioned to the right of the marker.

### Top
#
The label is positioned at the top of the segment.




