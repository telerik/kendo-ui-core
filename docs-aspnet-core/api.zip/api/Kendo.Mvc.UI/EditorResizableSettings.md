---
title: EditorResizableSettings
---

# Kendo.Mvc.UI.EditorResizableSettings
Kendo UI EditorResizableSettings class



## Properties


### Content

If enabled, the editor renders a resize handle to allow users to resize it.

### Min

The minimum height that the editor can be resized to.

### Max

The maximum height that the editor can be resized to.

### Toolbar

If resizable is set to true the widget will detect changes in the viewport width and will hide the overflowing controls in the tool overflow popup.

### Enabled

If enabled, the editor renders a resize handle to allow users to resize it.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






