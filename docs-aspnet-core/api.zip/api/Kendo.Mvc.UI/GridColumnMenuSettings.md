---
title: GridColumnMenuSettings
---

# Kendo.Mvc.UI.GridColumnMenuSettings
Kendo UI GridColumnMenuSettings class



## Properties


### Columns

If set to true the column menu would allow the user to select (show and hide) grid columns. By default the column menu allows column selection.

### Filterable

If set to true the column menu would allow the user to filter the grid. By default the column menu allows the user to filter if filtering is enabled via the filterable.

### Sortable

If set to true the column menu would allow the user to sort the grid by the column field. By default the column menu allows the user to sort if sorting is enabled via the sortable option.

### Enabled

If set to true the grid will display the column menu when the user clicks the chevron icon in the column headers. The column menu allows the user to show and hide columns, filter and sort (if filtering and sorting are enabled). By default the column menu is not enabled.Can be set to a JavaScript object which represents the column menu configuration.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






