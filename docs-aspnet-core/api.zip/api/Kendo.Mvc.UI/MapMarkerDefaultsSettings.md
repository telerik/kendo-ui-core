---
title: MapMarkerDefaultsSettings
---

# Kendo.Mvc.UI.MapMarkerDefaultsSettings
Kendo UI MapMarkerDefaultsSettings class



## Properties


### Shape

The default marker shape. Supported shapes are "pin" and "pinTarget".




## Methods


### SerializeSettings
Serialize current instance to Dictionary






