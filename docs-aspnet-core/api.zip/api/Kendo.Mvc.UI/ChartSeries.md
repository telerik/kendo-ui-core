---
title: ChartSeries
---

# Kendo.Mvc.UI.ChartSeries
Kendo UI ChartSeries class



## Properties


### Type

Gets or sets the series type.

### Axis

The name of the value axis to use.

### Border

The border of the chart series.

### CategoryAxis

The name of the category axis to use for the series.The first axis will be used if no categoryAxis is specified.

### CategoryField

The data item field which contains the category name or date.

### CloseField

The data field containing the close value.

### Color

The series base color. The supported values are: CSS color string, including hex and rgb or function(point) - user-defined function that will be evaluated for each point. Returning undefined will assume the default series color..

### ColorField

The data item field which contains the series color.

### Connectors

The label connectors options.

### CurrentField

The data item field containing the current value.

### DashType

The dash type of line chart.The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### DownColor

The series color when the open value is greater than the close value.

### DownColorField

The data field containing the color applied when the open value is greater than the close value.

### SegmentSpacing

The space in pixels between the different segments of the funnel chart.

### SummaryField

The data item field which contains the summary type for waterfall series. Summary columns are optional and can be one of two types: "runningTotal" - Displays the sum of all items since the last "runningTotal" point. or "total" - Displays the sum of all previous items..

### NeckRatio

specifies the ratio top-base/bottom-base of the whole chart. neckRatio set to three means the top base is three times smaller than the bottom base.

### DynamicSlope

When set to true the ratio of the bases of each segment is calculated based on the ratio of currentDataItem.value/nextDataItem.value The last element is always created like a rectangle since there is no following element.

### DynamicHeight

When set to false all segments become with the same height, otherwise the height of each segment is based on its value.

### ErrorBars

The error bars of the chart series.

### ErrorLowField

The data item field which contains the series.errorBars low value.

### ErrorHighField

The data item field which contains the series.errorBars high value.

### XErrorLowField

The data item field which contains the series.errorBars xAxis low value.

### XErrorHighField

The data item field which contains the series.errorBars xAxis high value.

### YErrorLowField

The data item field which contains the series.errorBars yAxis low value.

### YErrorHighField

The data item field which contains the series.errorBars yAxis high value.

### ExplodeField

The data item field which contains a boolean value indicating whether the sector is exploded.

### Field

The data item field which contains the series value. The field name should be a valid Javascript identifier and should contain only alphanumeric characters (or "$" or "_"), and may not start with a digit.

### FromField

The data item field which contains the series from value.

### ToField

The data item field which contains the series to value.

### NoteTextField

The data item field which contains the series note text.

### LowerField

The data item field which contains the series lower value.

### Q1Field

The data item field which contains the series q1 value.

### MedianField

The data item field which contains the series median value.

### Q3Field

The data item field which contains the series q3 value.

### UpperField

The data item field which contains the series upper value.

### MeanField

The data item field which contains the series mean value.

### OutliersField

The data item field which contains the series outliers value.

### Gap

The distance between categories expressed as a percentage of the bar width.See the related spacing setting.

### HighField

The data field containing the high value.

### Highlight

The chart series highlighting configuration options.

### HoleSize

The diameter of the donut hole in pixels.

### Labels

The chart series label configuration.

### Line

The chart line configuration options.

### LowField

The data field containing the low value.

### Margin

The margin around each donut series (ring). A numeric value will set all margins.

### Markers

The chart series marker configuration.

### Outliers

The chart series outliers configuration. Applies to mild outliers. Also check series.extremes.

### Extremes

The chart series extremes configuration. Applies to extreme outliers. Also check series.outliers.

### MaxSize

The maximum size of the chart bubble series marker.

### MinSize

The minimum size of the chart bubble series marker.

### Name

The name of the chart series which is visible in the legend.

### NegativeColor

The color to use for bar, column or waterfall series with negative values. Accepts a valid CSS color string, including hex and rgb.

### NegativeValues

The options for displaying the chart negative bubble values.

### Opacity

The series opacity. By default the series are opaque.

### OpenField

The data field containing the open value.

### Overlay

The chart series overlay options.

### Padding

The padding around the chart (equal on all sides).

### Size

The or radius of the chart donut series in pixels. If not set, the available space is split evenly between the series.

### SizeField

The data field containing the bubble size value.

### Spacing

The distance between series points within a category. Expressed as a percentage of the bar width.See the related gap setting.

### Stack

A boolean value indicating if the series should be stacked. A string value is interpreted as series.stack.group.

### StartAngle

The start angle (degrees) of the first donut or pie segment.Angles increase clockwise and zero is to the left. Negative values are acceptable.

### Target

The configuration options of the target

### TargetField

The data item field containing the target value.

### Tooltip

The chart series tooltip configuration options.

### Visible

Sets the visible property of a chart series

### VisibleInLegend

A value indicating whether to show the point category name (for funnel, donut and pie series) or series name (for other available series types) in the legend.

### VisibleInLegendField

The data item field which indicates whether to show the point category name in the legend.

### Visual

A function that can be used to create a custom visual for the points. Applicable for bar, column, pie, donut, funnel, line, scatterLine, rangeBar, rangeColumn and waterfall series. The available argument fields are: rect - the kendo.geometry.Rect that defines where the visual should be rendered.; options - the point options.; createVisual - a function that can be used to get the default visual.; category - the point category.; dataItem - the point dataItem.; value - the point value.; stackValue - the cumulative point value on the stack. Available only for stackable series.; sender - the chart instance.; series - the point series.; percentage - the point value represented as a percentage value. Available only for donut, pie and 100% stacked charts.; runningTotal - the sum of point values since the last "runningTotal" summary point. Available for waterfall series.; total - the sum of all previous series values. Available for waterfall series.; radius - the segment radius. Available for donut and pie series.; innerRadius - the segment inner radius. Available for donut series.; startAngle - the segment start angle. Available for donut and pie series.; endAngle - the segment end angle. Available for donut and pie series.; center - the segment center point. Available for donut and pie series. or points - the segment points. Available for funnel, line and scatterLine series..

### Width

The line width.

### XAxis

The name of the X axis to use.For polar series the xAxis range is expressed in degrees.

### XField

The data item field containing the X value.

### YAxis

The name of the Y axis to use.** Available for bubble, scatter, scatterLine and polar series. **

### YField

The data item field containing the Y value.

### Notes

The series notes configuration.

### ZIndex

An optional Z-index that can be used to change the default stacking order of series.The series with the highest Z-index will be placed on top.Series with no Z-index will use the default stacking order based on series type. For example line series will be on top with bar and area following below.

### Aggregate

Specifies the preferred series aggregate.

### MissingValues

Specifies the behavior for handling missing values in the series.

### Style

Specifies the preferred rendering style.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






