---
title: Dialog
---

# Kendo.Mvc.UI.Dialog
Kendo UI Dialog component



## Properties


### Actions

A collection of objects containing text, action and primary attributes used to specify the dialog buttons. #### Example

### ButtonLayout

Specifies the possible layout of the action buttons in the Dialog.Possible values are: normal or stretched.

### Closable

Specifies whether a close button should be rendered at the top corner of the dialog.

### Height

Specifies height of the dialog.

### MaxHeight

The maximum height (in pixels) that may be achieved by resizing the dialog.

### MaxWidth

The maximum width (in pixels) that may be achieved by resizing the dialog.

### Messages

Defines the text of the labels that are shown within the dialog. Used primarily for localization.

### MinHeight

The minimum height (in pixels) that may be achieved by resizing the dialog.

### MinWidth

The minimum width (in pixels) that may be achieved by resizing the dialog.

### Modal

Specifies whether the dialog should show a modal overlay over the page.

### Visible

Specifies whether the dialog will be initially visible.

### Width

Specifies width of the dialog.

### Content

The content of the dialog




## Methods


### SerializeSettings
Serialize current instance to Dictionary






