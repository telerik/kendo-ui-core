---
title: GanttAssignmentsSettings
---

# Kendo.Mvc.UI.GanttAssignmentsSettings
Kendo UI GanttAssignmentsSettings class



