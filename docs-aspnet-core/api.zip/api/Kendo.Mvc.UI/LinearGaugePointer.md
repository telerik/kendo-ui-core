---
title: LinearGaugePointer
---

# Kendo.Mvc.UI.LinearGaugePointer
Kendo UI LinearGaugePointer class



