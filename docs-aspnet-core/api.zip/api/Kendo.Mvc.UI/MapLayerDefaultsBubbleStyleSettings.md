---
title: MapLayerDefaultsBubbleStyleSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsBubbleStyleSettings
Kendo UI MapLayerDefaultsBubbleStyleSettings class



## Properties


### Fill

The default fill for bubble layer symbols. Accepts a valid CSS color string or object with detailed configuration.

### Stroke

The default stroke for bubble layer symbols. Accepts a valid CSS color string or object with detailed configuration.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






