---
title: ChartSeriesNotesSettings
---

# Kendo.Mvc.UI.ChartSeriesNotesSettings
Kendo UI ChartSeriesNotesSettings class



## Properties


### Icon

The icon of the notes.

### Label

The label of the notes.

### Line

The line of the notes.

### Visual

A function that can be used to create a custom visual for the notes. The available argument fields are: rect - the kendo.geometry.Rect that defines the note target rect.; options - the note options.; createVisual - a function that can be used to get the default visual.; category - the category of the note point.; dataItem - the dataItem of the note point.; value - the value of the note point.; sender - the chart instance.; series - the series of the note point. or text - the note text..

### Position

Specifies the position of the note.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






