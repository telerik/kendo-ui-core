---
title: GanttMessagesViewsSettings
---

# Kendo.Mvc.UI.GanttMessagesViewsSettings
Kendo UI GanttMessagesViewsSettings class



## Properties


### Day

The text similar to "Day" displayed as Gantt "day" view title.

### End

The text similar to "End" displayed in Gantt resize hint.

### Month

The text similar to "Month" displayed as Gantt "month" view title.

### Start

The text similar to "Start" displayed in Gantt resize hint.

### Week

The text similar to "Week" displayed as Gantt "week" view title.

### Year

The text similar to "Year" displayed as Gantt "year" view title.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






