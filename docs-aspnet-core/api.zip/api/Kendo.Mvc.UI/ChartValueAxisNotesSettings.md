---
title: ChartValueAxisNotesSettings
---

# Kendo.Mvc.UI.ChartValueAxisNotesSettings
Kendo UI ChartValueAxisNotesSettings class



## Properties


### Position

The position of the value axis note. "top" - The note is positioned on the top.; "bottom" - The note is positioned on the bottom.; "left" - The note is positioned on the left. or "right" - The note is positioned on the right..

### Icon

The icon of the notes.

### Label

The label of the notes.

### Line

The line of the notes.

### Visual

A function that can be used to create a custom visual for the notes. The available argument fields are: rect - the kendo.geometry.Rect that defines the note target rect.; options - the note options.; createVisual - a function that can be used to get the default visual. or value - the note value..




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






