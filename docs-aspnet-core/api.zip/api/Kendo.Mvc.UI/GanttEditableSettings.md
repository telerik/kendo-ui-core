---
title: GanttEditableSettings
---

# Kendo.Mvc.UI.GanttEditableSettings
Kendo UI GanttEditableSettings class



## Properties


### Confirmation

If set to true the Gantt will display a confirmation dialog when the user deletes a task or a dependency.

### Create

If set to false the user won't be able to create tasks.

### DependencyCreate

If set to false the user won't be able to create dependencies.

### DependencyDestroy

If set to false the user won't be able to delete dependencies.

### DragPercentComplete

If set to false the user won't be able to edit the percentComplete of the tasks.

### Destroy

If set to false the user won't be able to delete tasks.

### Move

If set to false the user won't be able to move tasks.

### Reorder

If set to false the user won't be able to reorder tasks in the task list.

### Resize

If set to false the user won't be able to resize tasks.

### Template

The template which renders the editor.The template should contain elements whose name HTML attributes are set as the editable fields. This is how the Gantt will know which field to update. The other option is to use MVVM bindings in order to bind HTML elements to data item fields.

### TemplateId

The id of the script element used for Template

### Update

If set to false the user won't be able to update tasks.

### Enabled

If set to false the user won't be able to create, modify or delete tasks and dependencies.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






