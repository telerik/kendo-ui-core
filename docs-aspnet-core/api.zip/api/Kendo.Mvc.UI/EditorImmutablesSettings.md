---
title: EditorImmutablesSettings
---

# Kendo.Mvc.UI.EditorImmutablesSettings
Kendo UI EditorImmutablesSettings class



## Properties


### Deserialization

Callback that allows custom deserialization of an immutable element. The callback accepts two arguments. The DOM element representing the immutable element in the html view and the immutable DOM element, which will be restored.

### Serialization

Kendo template or a callback that allows custom serialization of an immutable element. The callback accepts DOM element as only parameter and is expected to return the HTML source of a DOM element.

### Enabled

If enabled, the editor disables the editing and command execution in elements marked with editablecontent="false" attribute.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






