---
title: DateInputMessagesSettings
---

# Kendo.Mvc.UI.DateInputMessagesSettings
Kendo UI DateInputMessagesSettings class



## Properties


### Year

The placeholder for the years part.

### Month

The placeholder for the months part.

### Day

The placeholder for the day of the month part.

### Weekday

The placeholder for the day of the week part.

### Hour

The placeholder for the hours part.

### Minute

The placeholder for the minutes part.

### Second

The placeholder for the seconds part.

### Dayperiod

The placeholder for the AM/PM part.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






