---
title: ChartValueAxisCrosshairSettings
---

# Kendo.Mvc.UI.ChartValueAxisCrosshairSettings
Kendo UI ChartValueAxisCrosshairSettings class



## Properties


### Color

The color of the crosshair. Accepts a valid CSS color string, including hex and rgb.

### DashType

The dash type of the crosshair.The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### Opacity

The opacity of the crosshair. By default the crosshair is opaque.

### Tooltip

The crosshair tooltip options.

### Visible

If set to true the chart will display the value axis crosshair. By default the value axis crosshair is not visible.

### Width

The width of the crosshair in pixels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






