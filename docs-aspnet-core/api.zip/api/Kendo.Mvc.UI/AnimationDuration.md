---
title: AnimationDuration
---

# Kendo.Mvc.UI.AnimationDuration
Specifies the animation duration of item.


## Fields


### Fast
#
Fast animation, duration is set to 200.

### Normal
#
Normal animation, duration is set to 400.

### Slow
#
Slow animation, duration is set to 600.




