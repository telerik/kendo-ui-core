---
title: ChartTooltipPaddingSettings
---

# Kendo.Mvc.UI.ChartTooltipPaddingSettings
Kendo UI ChartTooltipPaddingSettings class



## Properties


### Bottom

The bottom padding of the tooltip.

### Left

The left padding of the tooltip.

### Right

The right padding of the tooltip.

### Top

The top padding of the tooltip.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






