---
title: ChartXAxisTitlePaddingSettings
---

# Kendo.Mvc.UI.ChartXAxisTitlePaddingSettings
Kendo UI ChartXAxisTitlePaddingSettings class



## Properties


### Bottom

The bottom padding of the title.

### Left

The left padding of the title.

### Right

The right padding of the title.

### Top

The top padding of the title.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






