---
title: MenuDirection
---

# Kendo.Mvc.UI.MenuDirection
Represents the menu item opening direction.


## Fields


### Bottom
#
Bottom direction

### Left
#
Left direction

### Right
#
Right direction

### Top
#
Top direction




