---
title: GridSortableSettings
---

# Kendo.Mvc.UI.GridSortableSettings
Kendo UI GridSortableSettings class



## Properties


### AllowUnsort

If set to true the user can get the grid in unsorted state by clicking the sorted column header.

### ShowIndexes

If set to true the user will see sort sequence indicators for sorted columns.

### InitialDirection

Determines the inital (from un-sorted to sorted state) sort direction. The supported values are asc and desc.

### SortMode

Defines the sort modes supported by Kendo UI Grid for ASP.NET MVC

### Enabled

If set to true the user could sort the grid by clicking the column header cells. By default sorting is disabled.Can be set to a JavaScript object which represents the sorting configuration.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






