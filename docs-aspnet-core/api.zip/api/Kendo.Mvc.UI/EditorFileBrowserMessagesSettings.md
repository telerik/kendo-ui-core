---
title: EditorFileBrowserMessagesSettings
---

# Kendo.Mvc.UI.EditorFileBrowserMessagesSettings
Kendo UI EditorFileBrowserMessagesSettings class



## Properties


### UploadFile

Defines text for upload button.

### OrderBy

Defines text for order by label.

### OrderByName

Defines text for Name item of order by drop down list.

### OrderBySize

Defines text for Size item of order by drop down list.

### DirectoryNotFound

Defines text for dialog shown when the directory not found error occurs.

### EmptyFolder

Defines text displayed when folder does not contain items.

### DeleteFile

Defines text for dialog shown when the file or directory is deleted.

### InvalidFileType

Defines text for dialog shown when an invalid file is set for upload.

### OverwriteFile

Defines text for dialog shown when an already existing file is set for upload.

### Search

Defines text for search box placeholder.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






