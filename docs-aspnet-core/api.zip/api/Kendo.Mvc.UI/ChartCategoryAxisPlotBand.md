---
title: ChartCategoryAxisPlotBand
---

# Kendo.Mvc.UI.ChartCategoryAxisPlotBand
Kendo UI ChartCategoryAxisPlotBand class



## Properties


### Color

The color of the plot band.

### From

The start position of the plot band in axis units.

### Opacity

The opacity of the plot band.

### To

The end position of the plot band in axis units.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






