---
title: ListBoxDraggableSettings
---

# Kendo.Mvc.UI.ListBoxDraggableSettings
Kendo UI ListBoxDraggableSettings class



## Properties


### Enabled

Indicates whether dragging is enabled.

### Hint

Provides an option to customize the draggable item hint. If a function is supplied, it receives a single argument - the jQuery object of the draggable element. If a hint is not provided, the ListBox clones the dragged item and uses it as a hint.

### Placeholder

Provides an option to customize the item placeholder of the ListBox. If a function is supplied, it receives a single argument - the jQuery object of the draggable element. If a placeholder is not provided, the ListBox clones the dragged item, removes its id attribute, sets its visibility to hidden, and uses it as a placeholder.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






