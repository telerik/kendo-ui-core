---
title: DropDownTreeCheckboxesSettings
---

# Kendo.Mvc.UI.DropDownTreeCheckboxesSettings
Kendo UI DropDownTreeCheckboxesSettings class



## Properties


### CheckChildren

Indicates whether checkboxes of child items should get checked when the checkbox of a parent item is checked. This also enables tri-state checkboxes with an indeterminate state.

### Name

Sets the name attribute of the checkbox inputs. That name will be posted to the server.

### Template

The template which renders the checkboxes. Can be used to allow posting of additional information along the TreeView checkboxes.The fields which can be used in the template are: item - the data item of the given node or treeview - the TreeView options.

### TemplateId

The id of the script element used for Template

### Enabled

If true or an object, renders checkboxes beside each node. In this case the widget value should be an array.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






