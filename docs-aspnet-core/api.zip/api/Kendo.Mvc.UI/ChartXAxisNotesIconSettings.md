---
title: ChartXAxisNotesIconSettings
---

# Kendo.Mvc.UI.ChartXAxisNotesIconSettings
Kendo UI ChartXAxisNotesIconSettings class



## Properties


### Background

The background color of the notes icon.

### Border

The border of the icon.

### Size

The size of the icon.

### Type

The icon shape.The supported values are: * "circle" - the marker shape is circle. * "square" - the marker shape is square. * "triangle" - the marker shape is triangle. * "cross" - the marker shape is cross.

### Visible

The icon visibility.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






