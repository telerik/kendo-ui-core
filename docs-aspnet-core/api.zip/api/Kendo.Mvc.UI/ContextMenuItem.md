---
title: ContextMenuItem
---

# Kendo.Mvc.UI.ContextMenuItem
Kendo UI ContextMenuItem class



