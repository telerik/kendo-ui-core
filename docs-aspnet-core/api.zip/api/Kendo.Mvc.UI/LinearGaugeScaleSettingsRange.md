---
title: LinearGaugeScaleSettingsRange
---

# Kendo.Mvc.UI.LinearGaugeScaleSettingsRange
Kendo UI LinearGaugeScaleSettingsRange class



## Properties


### From

The start position of the range in scale units.

### To

The end position of the range in scale units.

### Opacity

The opacity of the range.

### Color

The color of the range. Any valid CSS color string will work here, including hex and rgb.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






