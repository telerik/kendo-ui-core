---
title: IGanttDependency
---

# Kendo.Mvc.UI.IGanttDependency
Kendo UI IGanttDependency interface



