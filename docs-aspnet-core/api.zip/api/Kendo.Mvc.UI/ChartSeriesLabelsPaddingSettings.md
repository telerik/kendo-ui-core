---
title: ChartSeriesLabelsPaddingSettings
---

# Kendo.Mvc.UI.ChartSeriesLabelsPaddingSettings
Kendo UI ChartSeriesLabelsPaddingSettings class



## Properties


### Bottom

The bottom padding of the labels.

### Left

The left padding of the labels.

### Right

The right padding of the labels.

### Top

The top padding of the labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






