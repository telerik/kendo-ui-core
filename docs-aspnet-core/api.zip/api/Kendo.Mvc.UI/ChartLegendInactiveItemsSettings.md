---
title: ChartLegendInactiveItemsSettings
---

# Kendo.Mvc.UI.ChartLegendInactiveItemsSettings
Kendo UI ChartLegendInactiveItemsSettings class



## Properties


### Labels

The chart legend label configuration.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






