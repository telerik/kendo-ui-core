---
title: ChartPane
---

# Kendo.Mvc.UI.ChartPane
Kendo UI ChartPane class



## Properties


### Background

The background color of the chart pane. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the chart pane.

### Clip

Specifies whether the charts in the pane should be clipped. By default all charts except radar, polar and 100% stacked charts are clipped.

### Height

The chart pane height in pixels.

### Margin

The margin of the pane. A numeric value will set all margins.

### Name

The unique name of the chart pane.

### Padding

The padding of the pane. A numeric value will set all paddings.

### Title

The title configuration of the chart pane.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






