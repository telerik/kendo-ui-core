---
title: GanttMessagesActionsSettings
---

# Kendo.Mvc.UI.GanttMessagesActionsSettings
Kendo UI GanttMessagesActionsSettings class



## Properties


### AddChild

The text similar to "Add child" displayed as Gantt "add child" buttons.

### Append

The text similar to "Append" displayed as Gantt "append" buttons.

### InsertAfter

The text similar to "Add below" displayed as Gantt "add below" buttons.

### InsertBefore

The text similar to "Add above" displayed as Gantt "add above" buttons.

### Pdf

The text of "Export to PDF" button of the Gantt toolbar.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






