---
title: ChartLegendSettings
---

# Kendo.Mvc.UI.ChartLegendSettings
Kendo UI ChartLegendSettings class



## Properties


### Background

The background color of the legend. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the legend.

### Height

The legend height when the legend.orientation is set to "vertical".

### InactiveItems

The chart inactive legend items configuration.

### Item

The chart legend item configuration.

### Labels

The chart legend label configuration.

### Margin

The margin of the chart legend. A numeric value will set all paddings.

### OffsetX

The X offset of the chart legend. The offset is relative to the default position of the legend. For instance, a value of 20 will move the legend 20 pixels to the right of its initial position. A negative value will move the legend to the left of its current position.

### OffsetY

The Y offset of the chart legend.  The offset is relative to the current position of the legend. For instance, a value of 20 will move the legend 20 pixels down from its initial position. A negative value will move the legend upwards from its current position.

### Padding

The padding of the chart legend. A numeric value will set all paddings.

### Reverse

If set to true the legend items will be reversed.Available in versions 2013.3.1306 and later.

### Spacing

The spacing between the labels in pixels when the legend.orientation is "horizontal".

### Visible

If set to true the chart will display the legend. By default the chart legend is visible.

### Width

The legend width when the legend.orientation is set to "horizontal".

### Align

Specifies the legend align.

### Orientation

Specifies the legend orientation.

### Position

Specifies the legend position.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






