---
title: ChartPieLabelsPosition
---

# Kendo.Mvc.UI.ChartPieLabelsPosition
Specifies the position of pie chart labels.


## Fields


### Center
#
The label is positioned at the center of the pie segment.

### InsideEnd
#
The label is positioned inside, near the end of the pie segment.

### OutsideEnd
#
The label is positioned outside, near the end of the pie segment.




