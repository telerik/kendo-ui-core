---
title: ChartSeriesAggregateSettings
---

# Kendo.Mvc.UI.ChartSeriesAggregateSettings
Kendo UI ChartSeriesAggregateSettings class



## Properties


### Close

Specifies the aggregate function to apply for the Close field.

### CloseHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Close field.

### High

Specifies the aggregate function to apply for the High field.

### HighHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the High field.

### Low

Specifies the aggregate function to apply for the Low field.

### LowHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Low field.

### Open

Specifies the aggregate function to apply for the Open field.

### OpenHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Open field.

### Lower

Specifies the aggregate function to apply for the Lower field.

### LowerHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Lower field.

### Mean

Specifies the aggregate function to apply for the Mean field.

### MeanHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Mean field.

### Median

Specifies the aggregate function to apply for the Median field.

### MedianHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Median field.

### Outliers

Specifies the aggregate function to apply for the Outliers field.

### OutliersHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Outliers field.

### Q1

Specifies the aggregate function to apply for the Q1 field.

### Q1Handler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Q1 field.

### Q3

Specifies the aggregate function to apply for the Q3 field.

### Q3Handler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Q3 field.

### Upper

Specifies the aggregate function to apply for the Upper field.

### UpperHandler

Specifies the name of a user-defined client-side functon that will calculate the aggregate for the Upper field.




## Methods


### SerializeSettings
Serializes the settings to a Dictionary.





### Serialize
Serializes the settings to a Dictionary.






