---
title: CheckBox
---

# Kendo.Mvc.UI.CheckBox
Kendo UI CheckBox component



