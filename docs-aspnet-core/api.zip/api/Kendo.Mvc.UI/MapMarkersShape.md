---
title: MapMarkersShape
---

# Kendo.Mvc.UI.MapMarkersShape
The marker shape. Supported shapes are "pin" and "pinTarget".



