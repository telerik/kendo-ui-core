---
title: EditorPasteCleanupSettings
---

# Kendo.Mvc.UI.EditorPasteCleanupSettings
Kendo UI EditorPasteCleanupSettings class



## Properties


### All

All HTML tags are stripped leaving only the text in the content.

### Css

Remove style and class attributes from the pasting content.

### Custom

Use a callback function to integrate a custom implementation for cleaning up the paste content. Make sure the callback function always returns the result.

### KeepNewLines

Strip all HTML tags but keep new lines in the pasted content.

### MsAllFormatting

Remove all special formatting from MS Word content like font-name, font-size and MS Word specific tags.

### MsConvertLists

Converts MS Word pasted content into HTML lists.

### MsTags

Removes all MS Word specific tags and cleans up the extra metadata.

### None

Prevent any cleaning up of the content.

### Span

Remove all span elements from the content, ensuring much of the inline formatting is removed.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






