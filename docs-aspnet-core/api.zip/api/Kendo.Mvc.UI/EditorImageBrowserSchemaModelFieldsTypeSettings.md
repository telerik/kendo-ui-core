---
title: EditorImageBrowserSchemaModelFieldsTypeSettings
---

# Kendo.Mvc.UI.EditorImageBrowserSchemaModelFieldsTypeSettings
Kendo UI EditorImageBrowserSchemaModelFieldsTypeSettings class



## Properties


### Parse

Specifies the function which will parse the field value. If not set default parsers will be used.

### Field

The name of the field.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






