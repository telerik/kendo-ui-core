---
title: ChartSeriesStyle
---

# Kendo.Mvc.UI.ChartSeriesStyle
Specifies the preferred rendering style.


## Fields


### Normal
#
Points will be connected with a straight line.

### Smooth
#
Points will be connected with a smooth line.

### Step
#
Points will be connected with a line at right angles.




