---
title: ChartPolarAreaStyle
---

# Kendo.Mvc.UI.ChartPolarAreaStyle
Specifies the preferred line rendering style.


## Fields


### Normal
#
Points will be connected with straight line.

### Smooth
#
Points will be connected with smooth line.




