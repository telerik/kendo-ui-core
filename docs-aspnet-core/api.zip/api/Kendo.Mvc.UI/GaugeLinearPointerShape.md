---
title: GaugeLinearPointerShape
---

# Kendo.Mvc.UI.GaugeLinearPointerShape
Defines the shape of the liner gauge pointer.


## Fields


### BarIndicator
#
Specifies a filling bar indicator.

### Arrow
#
Specifies an arrow shape.




