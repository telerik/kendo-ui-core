---
title: ListBoxMessagesToolsSettings
---

# Kendo.Mvc.UI.ListBoxMessagesToolsSettings
Kendo UI ListBoxMessagesToolsSettings class



## Properties


### MoveDown

Defines the text of the Move Down button that is located in the toolbar of the ListBox.

### MoveUp

Defines the text of the Move Up button that is located in the toolbar of the ListBox.

### Remove

Defines the text of the Delete button that is located in the toolbar of the ListBox.

### TransferAllFrom

Defines the text of the Transfer All From button that is located in the toolbar of the ListBox.

### TransferAllTo

Defines the text of the Transfer All To button that is located in the toolbar of the ListBox.

### TransferFrom

Defines the text of the Transfer From button that is located in the toolbar of the ListBox.

### TransferTo

Defines the text of the Transfer To button that is located in the toolbar of the ListBox.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






