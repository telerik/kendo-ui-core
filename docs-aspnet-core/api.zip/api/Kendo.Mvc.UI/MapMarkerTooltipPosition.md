---
title: MapMarkerTooltipPosition
---

# Kendo.Mvc.UI.MapMarkerTooltipPosition
The position relative to the target element, at which tlhe tooltip will be shown. Predefined values are "bottom", "top", "left", "right", "center".



