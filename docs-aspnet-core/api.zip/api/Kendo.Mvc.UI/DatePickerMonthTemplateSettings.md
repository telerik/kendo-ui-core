---
title: DatePickerMonthTemplateSettings
---

# Kendo.Mvc.UI.DatePickerMonthTemplateSettings
Kendo UI DatePickerMonthTemplateSettings class



## Properties


### Empty



### EmptyId



### Content



### ContentId



### WeekNumber



### WeekNumberId






## Methods


### SerializeSettings
Serialize current instance to Dictionary






