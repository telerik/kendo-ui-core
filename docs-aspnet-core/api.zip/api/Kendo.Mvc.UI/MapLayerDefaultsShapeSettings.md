---
title: MapLayerDefaultsShapeSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsShapeSettings
Kendo UI MapLayerDefaultsShapeSettings class



## Properties


### Attribution

The attribution for all shape layers.

### Opacity

The the opacity of all shape layers.

### Style

The default style for shapes.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






