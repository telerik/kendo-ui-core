---
title: ChartCategoryAxis
---

# Kendo.Mvc.UI.ChartCategoryAxis
Kendo UI ChartCategoryAxis class



## Properties


### Categories

The category names. The chart will create a category for every item of the array.

### AutoBaseUnitSteps

The discrete categoryAxis.baseUnitStep values when either categoryAxis.baseUnit is set to "fit" orcategoryAxis.baseUnitStep is set to "auto".The axis will try to divide the active period into successively larger intervals. It will start from x-second intervals, where x is picked from the autoBaseUnitSteps.seconds array. Then it will move to minutes, seconds and so on. This will continue until the number of intervals is less thanmaxDateGroups.

### AxisCrossingValue

Category index at which the first value axis crosses this axis (when set as an object).Category indices at which the value axes cross the category axis (when set as an array).

### Background

The background color of the axis.

### BaseUnitStep

The step (interval) between categories in base units. Setting it to "auto" will set the step to such value that the total number of categories does not exceed categoryAxis.maxDateGroups.This option is ignored if categoryAxis.baseUnit is set to "fit".

### Color

The color to apply to all axis elements. Accepts a valid CSS color string, including hex and rgb. Can be overridden by categoryAxis.labels.color andcategoryAxis.line.color.

### Crosshair

The crosshair configuration options.

### Field

The data item field which contains the category name. Requires the dataSource option to be set. The field name should be a valid Javascript identifier and should contain only alphanumeric characters (or "$" or "_"), and may not start with a digit.

### Justify

If set to true the chart will position categories and series points on major ticks. This removes the empty space before and after the series.The default value is false except for "area", "verticalArea", "rangeArea" and "verticalRangeArea".

### Labels

The axis labels configuration.

### Line

The configuration of the axis lines. Also affects the major and minor ticks, but not the grid lines.

### MajorGridLines

The configuration of the major grid lines. These are the lines that are an extension of the major ticks through the body of the chart.

### MajorTicks

The configuration of the category axis major ticks.

### Max

The last date displayed on the category date axis. By default, the minimum date is the same as the last category. This is often used in combination with the categoryAxis.min and categoryAxis.roundToBaseUnit options to set up a fixed date range.

### MaxDateGroups

The maximum number of groups (categories) to display whencategoryAxis.baseUnit is set to "fit" orcategoryAxis.baseUnitStep is set to "auto".

### MaxDivisions

The maximum number of ticks and labels to display. Applicable for date category axis.

### Min

The first date displayed on the category date axis. By default, the minimum date is the same as the first category. This is often used in combination with the categoryAxis.min and categoryAxis.roundToBaseUnit options to set up a fixed date range.

### MinorGridLines

The configuration of the minor grid lines. These are the lines that are an extension of the minor ticks through the body of the chart.

### MinorTicks

The configuration of the category axis minor ticks.

### Name

The unique axis name. Used to associate a series with a category axis using the series.categoryAxis option.

### Pane

The name of the pane that the category axis should be rendered in. The axis will be rendered in the first (default) pane if not set.

### PlotBands

The plot bands of the category axis.

### Reverse

If set to true the category axis direction will be reversed. By default categories are listed from left to right and from bottom to top.

### RoundToBaseUnit

If set to true the chart will round the first and last date to the nearest base unit.The roundToBaseUnit option will be ignored if series.type is set to "bar", "column", "boxPlot", "ohlc", "candlestick" or "waterfall".

### Select

The selected axis range. If set, axis selection will be enabled.The range is index based, starting from 0. Categories with indexes in the range [select.from, select.to) will be selected. That is, the last category in the range will not be included in the selection.If the categories are dates, the range must also be specified with date values.

### StartAngle

The angle (degrees) of the first category on the axis.Angles increase clockwise and zero is to the left. Negative values are acceptable.

### Title

The title configuration of the category axis.

### Visible

If set to true the chart will display the category axis. By default the category axis is visible.

### WeekStartDay

The week start day when categoryAxis.baseUnit is set to "weeks".The supported values are: kendo.days.Sunday - equal to 0; kendo.days.Monday - equal to 1; kendo.days.Tuesday - equal to 2; kendo.days.Wednesday - equal to 3; kendo.days.Thursday - equal to 4; kendo.days.Friday - equal to 5 or kendo.days.Saturday - equal to 6.

### Notes

The category axis notes configuration.

### BaseUnit

Specifies the base time interval for the axis.

### Type

Specifies the category axis type.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






