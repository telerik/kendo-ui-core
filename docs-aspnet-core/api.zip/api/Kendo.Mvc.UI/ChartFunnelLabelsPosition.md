---
title: ChartFunnelLabelsPosition
---

# Kendo.Mvc.UI.ChartFunnelLabelsPosition
Specifies the position of pie chart labels.


## Fields


### Center
#
The label is positioned at the center of the funnel segment.

### Top
#
The label is positioned at the top of the label area.

### Bottom
#
The label is positioned at the bottom of the label area.




