---
title: ChartZoomableSelectionSettings
---

# Kendo.Mvc.UI.ChartZoomableSelectionSettings
Kendo UI ChartZoomableSelectionSettings class



## Properties


### Key

Specifies a keyboard key that should be pressed to activate the selection.

### Lock

Specifies an axis that should not be zoomed.

### Enabled

Specifies if the chart can be zoomed using selection.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






