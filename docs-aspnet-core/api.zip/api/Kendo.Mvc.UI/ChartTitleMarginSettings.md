---
title: ChartTitleMarginSettings
---

# Kendo.Mvc.UI.ChartTitleMarginSettings
Kendo UI ChartTitleMarginSettings class



## Properties


### Bottom

The bottom margin of the title.

### Left

The left margin of the title.

### Right

The right margin of the title.

### Top

The top margin of the title.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






