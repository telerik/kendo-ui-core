---
title: ChartSeriesErrorBarsSettings
---

# Kendo.Mvc.UI.ChartSeriesErrorBarsSettings
Kendo UI ChartSeriesErrorBarsSettings class



## Properties


### Value

The error bars value.The following value types are supported: "stderr" - the standard error of the series values will be used to calculate the point low and high value; "stddev(n)" - the standard deviation of the series values will be used to calculate the point low and high value. A number can be specified between the parentheses, that will be multiplied by the calculated standard deviation.; "percentage(n)" - a percentage of the point value; A number that will be subtracted/added to the point value; An array that holds the low and high difference from the point value or A function that returns the errorBars point value.

### Visual

A function that can be used to create a custom visual for the error bars. The available argument fields are: rect - the kendo.geometry.Rect that defines where the visual should be rendered.; options - the error bar options.; createVisual - a function that can be used to get the default visual.; low - the error bar low value.; high - the error bar high value. or sender - the chart instance..

### XValue

The xAxis error bars value. See the series.errorBars.value option for a list of the supported value types.

### YValue

The yAxis error bars value. See the series.errorBars.value option for a list of the supported value types.

### EndCaps

If set to false, the error bars caps will not be displayed. By default the caps are visible.

### Color

The color of the error bars. Accepts a valid CSS color string, including hex and rgb.

### Line

The error bars line options.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






