---
title: ChartAxisDefaultsSettings
---

# Kendo.Mvc.UI.ChartAxisDefaultsSettings
Kendo UI ChartAxisDefaultsSettings class



## Properties


### Background

The background color of the axis.

### Color

The color to apply to all axis elements. Accepts a valid CSS color string, including hex and rgb.

### Crosshair

The crosshair configuration options.

### Labels

The axis labels configuration.

### Line

The configuration of the axis lines. Also affects the major and minor ticks, but not the grid lines.

### MajorGridLines

The configuration of the major grid lines. These are the lines that are an extension of the major ticks through the body of the chart.

### MajorTicks

The configuration of the axis major ticks.

### MinorGridLines

The configuration of the minor grid lines. These are the lines that are an extension of the minor ticks through the body of the chart.

### MinorTicks

The configuration of the axis minor ticks.

### NarrowRange

If set to true the chart will prevent the axis range from snapping to 0. Setting it to false will force the axis range to snap to 0.

### Pane

The name of the pane that the axis should be rendered in. The axis will be rendered in the first (default) pane if not set.

### PlotBands

The plot bands of the axis.

### Reverse

If set to true the axis direction will be reversed. By default categories are listed from left to right and from bottom to top.

### StartAngle

The angle (degrees) of the first category on the axis.Angles increase clockwise and zero is to the left. Negative values are acceptable.

### Title

The title configuration of the axis.

### Visible

If set to true the chart will display the axis. By default the axis is visible.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






