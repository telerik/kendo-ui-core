---
title: GridGroupableSortSettings
---

# Kendo.Mvc.UI.GridGroupableSortSettings
Kendo UI GridGroupableSortSettings class



## Properties


### Compare

A JavaScript function which is used to compare the groups (refer to sortable for sorting the items of the groups). It has the same signature as the compare function accepted by Array.sort.

### Dir

The sort order of the groups according to the group field.The supported values are: "asc" (ascending order) or "desc" (descending order).




## Methods


### Serialize
Serialize current instance to Dictionary





### SerializeSettings
Serialize current instance to Dictionary






