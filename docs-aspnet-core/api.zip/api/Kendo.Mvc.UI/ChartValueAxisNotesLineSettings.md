---
title: ChartValueAxisNotesLineSettings
---

# Kendo.Mvc.UI.ChartValueAxisNotesLineSettings
Kendo UI ChartValueAxisNotesLineSettings class



## Properties


### DashType

The dash type of the note line.The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### Width

The line width of the notes.

### Color

The line color of the notes.

### Length

The length of the connecting lines in pixels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






