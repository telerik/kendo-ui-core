---
title: ButtonGroup
---

# Kendo.Mvc.UI.ButtonGroup
Kendo UI ButtonGroup component



## Properties


### Enable

Defines if the widget is initially enabled or disabled. By default, it is enabled.

### Index

Defines the initially selected Button (zero based index).

### Selection

Defines the selection type.

### Items

A JavaScript array that contains the ButtonGroup's items configuration.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






