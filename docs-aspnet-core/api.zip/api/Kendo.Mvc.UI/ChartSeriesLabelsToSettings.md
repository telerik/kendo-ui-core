---
title: ChartSeriesLabelsToSettings
---

# Kendo.Mvc.UI.ChartSeriesLabelsToSettings
Kendo UI ChartSeriesLabelsToSettings class



## Properties


### Background

The background color of the to labels. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the to labels.

### Color

The text color of the to labels. Accepts a valid CSS color string, including hex and rgb.

### Font

The font style of the to labels.

### Format

The format of the to labels. Uses kendo.format.

### Margin

The margin of the to labels. A numeric value will set all margins.

### Padding

The padding of the to labels. A numeric value will set all paddings.

### Template

The template which renders the chart series to label.The fields which can be used in the template are: category - the category name.; dataItem - the original data item used to construct the point. Will be null if binding to array.; series - the data series or value - the point value. An object containing from and to values..

### TemplateId

The id of the script element used for Template

### Visible

If set to true the chart will display the series to labels. By default chart series to labels are not displayed.

### Position

Specifies the position of the "to" labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






