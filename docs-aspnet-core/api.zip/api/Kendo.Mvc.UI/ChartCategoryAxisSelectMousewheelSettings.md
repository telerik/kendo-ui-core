---
title: ChartCategoryAxisSelectMousewheelSettings
---

# Kendo.Mvc.UI.ChartCategoryAxisSelectMousewheelSettings
Kendo UI ChartCategoryAxisSelectMousewheelSettings class



## Properties


### Reverse

If set to true will reverse the mouse wheel direction. The normal direction is down for "zoom out", up for "zoom in".

### Zoom

Specifies the mousehweel zoom type.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






