---
title: MenuScrollableSettings
---

# Kendo.Mvc.UI.MenuScrollableSettings
Kendo UI MenuScrollableSettings class



## Properties


### Distance

Sets the scroll amount (in pixels) that the Menu scrolls when the scroll buttons are hovered. Each such distance is animated and then another animation starts with the same distance. If clicking a scroll button, the Menu scrolls with 2x the distance.

### Enabled

If enabled, the Menu displays buttons that scroll the items when they cannot fit the width or the popups' height of the Menu. By default, scrolling is disabled.The following example demonstrates how to enable the scrolling functionality.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






