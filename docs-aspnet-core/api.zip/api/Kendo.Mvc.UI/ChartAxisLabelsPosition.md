---
title: ChartAxisLabelsPosition
---

# Kendo.Mvc.UI.ChartAxisLabelsPosition
Specifies the position of the labels.


## Fields


### OnAxis
#
The labels are positioned next to the axis.

### End
#
The labels are positioned at the end of the crossing axis.

### Start
#
The labels are positioned at the start of the crossing axis.




