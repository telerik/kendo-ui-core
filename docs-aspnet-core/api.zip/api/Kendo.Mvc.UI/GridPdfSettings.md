---
title: GridPdfSettings
---

# Kendo.Mvc.UI.GridPdfSettings
Kendo UI GridPdfSettings class



## Properties


### AllPages

Exports all grid pages, starting from the first one.

### Author

The author of the PDF document.

### AvoidLinks

A flag indicating whether to produce actual hyperlinks in the exported PDF file.It's also possible to pass a CSS selector as argument. All matching links will be ignored.

### Creator

The creator of the PDF document.

### Date

The date when the PDF document is created. Defaults to new Date().

### FileName

Specifies the file name of the exported PDF file.

### ForceProxy

If set to true, the content will be forwarded to proxyURL even if the browser supports saving files locally.

### Keywords

Specifies the keywords of the exported PDF file.

### Landscape

Set to true to reverse the paper dimensions if needed such that width is the larger edge.

### Template

A piece of HTML to be included in each page.  Can be used to display headers and footers.  See the documentation in drawDOM.Available template variables include: * pageNum * totalPages

### TemplateId

The id of the script element used for Template

### RepeatHeaders

Set this to true to repeat the grid headers on each page.

### Scale

A scale factor.  In many cases, text size on screen will be too big for print, so you can use this option to scale down the output in PDF.  See the documentation in drawDOM.

### ProxyURL

The URL of the server side proxy which will stream the file to the end user.A proxy will be used when the browser is not capable of saving files locally, for example, Internet Explorer 9 and Safari.The developer is responsible for implementing the server-side proxy.The proxy will receive a POST request with the following parameters in the request body: contentType: The MIME type of the file; base64: The base-64 encoded file content or fileName: The file name, as requested by the caller.. The proxy should return the decoded file with the "Content-Disposition" header set toattachment; filename="<fileName.pdf>".

### ProxyTarget

A name or keyword indicating where to display the document returned from the proxy.If you want to display the document in a new window or iframe, the proxy should set the "Content-Disposition" header to inline; filename="<fileName.pdf>".

### Subject

Sets the subject of the PDF file.

### Title

Sets the title of the PDF file.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






