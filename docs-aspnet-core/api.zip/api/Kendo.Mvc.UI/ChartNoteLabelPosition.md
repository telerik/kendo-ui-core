---
title: ChartNoteLabelPosition
---

# Kendo.Mvc.UI.ChartNoteLabelPosition
Specifies the position of the labels.


## Fields


### Inside
#
The label is positioned inside of the icon.

### Outside
#
The label is positioned outside of the icon.




