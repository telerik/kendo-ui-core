---
title: Chat
---

# Kendo.Mvc.UI.Chat
Kendo UI Chat component



## Properties


### Messages

Allows localization of the strings that are used in the widget.

### User

Configures the Kendo UI Chat user information.

### Toolbar

Configures the Kendo UI Chat toolbar.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






