---
title: ChartLegendPaddingSettings
---

# Kendo.Mvc.UI.ChartLegendPaddingSettings
Kendo UI ChartLegendPaddingSettings class



## Properties


### Bottom

The bottom padding of the chart legend.

### Left

The left padding of the chart legend.

### Right

The right padding of the chart legend.

### Top

The top padding of the chart legend.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






