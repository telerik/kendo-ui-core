---
title: DropDownTreePopupSettings
---

# Kendo.Mvc.UI.DropDownTreePopupSettings
Kendo UI DropDownTreePopupSettings class



## Properties


### AppendTo

Defines a jQuery selector that will be used to find a container element, where the popup will be appended to.

### Origin

Specifies how to position the popup element based on anchor point. The value is space separated "y" plus "x" position.The available "y" positions are: - "bottom" - "center" - "top"The available "x" positions are: - "left" - "center" - "right"

### Position

Specifies which point of the popup element to attach to the anchor's origin point. The value is space separated "y" plus "x" position.The available "y" positions are: - "bottom" - "center" - "top"The available "x" positions are: - "left" - "center" - "right"




## Methods


### SerializeSettings
Serialize current instance to Dictionary






