---
title: ContextMenu
---

# Kendo.Mvc.UI.ContextMenu
Kendo UI ContextMenu component



## Properties


### AlignToAnchor

Specifies that ContextMenu should be shown aligned to the target or the filter element if specified.

### AppendTo

The DOM element to which the ContextMenu will be appended. The element needs to be relatively positioned.

### CloseOnClick

Specifies that sub menus should close after item selection (provided they won't navigate).

### CopyAnchorStyles

Copies and uses the styles from the anchor.

### Filter

Specifies ContextMenu filter selector - the ContextMenu will only be shown on items that satisfy the provided selector.

### HoverDelay

Specifies the delay in ms before the sub menus are opened/closed - used to avoid accidental closure on leaving.

### ShowOn

Specifies the event or events on which ContextMenu should open. By default ContextMenu will show on contextmenu event on desktop and hold event on touch devices. Could be any pointer/mouse/touch event, also several, separated by spaces.

### Target

Specifies the element on which ContextMenu should open. The default element is the document body.

### Orientation

Specifies the orientation in which the menu items will be ordered




## Methods


### SerializeSettings
Serialize current instance to Dictionary






