---
title: ChartSeriesConnectorsSettings
---

# Kendo.Mvc.UI.ChartSeriesConnectorsSettings
Kendo UI ChartSeriesConnectorsSettings class



## Properties


### Color

The color of the connector. Accepts a valid CSS color string, including hex and rgb.

### Padding

The padding between the connector line and the label, and connector line and donut chart.

### Width

The width of the connector line.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






