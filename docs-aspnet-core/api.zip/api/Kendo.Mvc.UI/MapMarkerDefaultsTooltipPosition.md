---
title: MapMarkerDefaultsTooltipPosition
---

# Kendo.Mvc.UI.MapMarkerDefaultsTooltipPosition
The position relative to the target element, at which the tooltip will be shown. Predefined values are "bottom", "top", "left", "right", "center".



