---
title: MapLayerStyleSettings
---

# Kendo.Mvc.UI.MapLayerStyleSettings
Kendo UI MapLayerStyleSettings class



## Properties


### Fill

The default fill for layer shapes. Accepts a valid CSS color string or object with detailed configuration.

### Stroke

The default stroke for layer shapes. Accepts a valid CSS color string or object with detailed configuration.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






