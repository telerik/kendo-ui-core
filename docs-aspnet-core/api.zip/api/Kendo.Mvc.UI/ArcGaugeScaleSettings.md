---
title: ArcGaugeScaleSettings
---

# Kendo.Mvc.UI.ArcGaugeScaleSettings
Kendo UI ArcGaugeScaleSettings class



## Properties


### EndAngle

The end angle of the gauge. The gauge is rendered clockwise(0 degrees are the 180 degrees in the polar coordinate system)

### Labels

Configures the scale labels.

### MajorTicks

Configures the scale major ticks.

### MajorUnit

The interval between major divisions.

### Max

The maximum value of the scale.

### Min

The minimum value of the scale.

### MinorTicks

Configures the scale minor ticks.

### MinorUnit

The interval between minor divisions.

### RangeLineCap

The lineCap style of the ranges.The supported values are: "butt"; "round" or "square".

### RangePlaceholderColor

The default color for the ranges.

### RangeSize

The width of the range indicators.

### RangeDistance

The distance from the range indicators to the ticks.

### Reverse

Reverses the scale direction - values are increase anticlockwise.

### StartAngle

The start angle of the gauge. The gauge is rendered clockwise(0 degrees are the 180 degrees in the polar coordinate system)




## Methods


### SerializeSettings
Serialize current instance to Dictionary






