---
title: GridGroupableSettings
---

# Kendo.Mvc.UI.GridGroupableSettings
Kendo UI GridGroupableSettings class



## Properties


### Enabled

When set to false grouping is considered disabled.

### ShowFooter

When enabled the group footer rows will remain visible when the corresponding group is collapsed.

### Sort

Sets the sort configuration when grouping.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






