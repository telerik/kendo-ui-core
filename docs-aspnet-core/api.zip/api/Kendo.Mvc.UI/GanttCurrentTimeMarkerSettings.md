---
title: GanttCurrentTimeMarkerSettings
---

# Kendo.Mvc.UI.GanttCurrentTimeMarkerSettings
Kendo UI GanttCurrentTimeMarkerSettings class



## Properties


### UpdateInterval

The update interval of the "current time" marker, in milliseconds.

### Enabled

If set to false the "current time" marker of the Gantt would not be displayed.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






