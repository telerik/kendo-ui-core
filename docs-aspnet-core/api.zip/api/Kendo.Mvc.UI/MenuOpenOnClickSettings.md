---
title: MenuOpenOnClickSettings
---

# Kendo.Mvc.UI.MenuOpenOnClickSettings
Kendo UI MenuOpenOnClickSettings class



## Properties


### RootMenuItems

Specifies that the root menus will be opened only on item click.

### SubMenuItems

Specifies that the sub menus will be opened only on item click.

### Enabled

Specifies that the root sub menus will be opened on item click.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






