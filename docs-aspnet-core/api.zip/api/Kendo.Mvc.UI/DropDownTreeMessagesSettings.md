---
title: DropDownTreeMessagesSettings
---

# Kendo.Mvc.UI.DropDownTreeMessagesSettings
Kendo UI DropDownTreeMessagesSettings class



## Properties


### Clear

The text message when hovering the clear button.

### DeleteTag

The text message shown when hovering delete icon in a selected tag.

### SingleTag

The text message shown in the single TagMode tag.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






