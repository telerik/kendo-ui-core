---
title: ChartXAxisNotesLabelSettings
---

# Kendo.Mvc.UI.ChartXAxisNotesLabelSettings
Kendo UI ChartXAxisNotesLabelSettings class



## Properties


### Background

The background color of the label. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the label.

### Color

The text color of the label. Accepts a valid CSS color string, including hex and rgb.

### Font

The font style of the label.

### Template

The template which renders the labels.The fields which can be used in the template are: value - the axis value.

### TemplateId

The id of the script element used for Template

### Visible

If set to true the chart will display the x axis notes label. By default the x axis notes label are visible.

### Rotation

The rotation angle of the label. By default the label are not rotated.

### Format

The format used to display the notes label. Uses kendo.format. Contains one placeholder ("{0}") which represents the axis value.

### Position

The position of the labels. "inside" - the label is positioned inside of the icon. or "outside" - the label is positioned outside of the icon..




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






