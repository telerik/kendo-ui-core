---
title: ChartXAxisMinorTicksSettings
---

# Kendo.Mvc.UI.ChartXAxisMinorTicksSettings
Kendo UI ChartXAxisMinorTicksSettings class



## Properties


### Color

The color of the x axis minor ticks lines. Accepts a valid CSS color string, including hex and rgb.

### Size

The length of the tick line in pixels.

### Visible

If set to true the chart will display the x axis minor ticks. By default the x axis minor ticks are not visible.

### Width

The width of the minor ticks in pixels.

### Step

The step of the x axis minor ticks.

### Skip

The skip of the x axis minor ticks.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






