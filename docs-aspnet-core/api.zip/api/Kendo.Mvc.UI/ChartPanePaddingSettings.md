---
title: ChartPanePaddingSettings
---

# Kendo.Mvc.UI.ChartPanePaddingSettings
Kendo UI ChartPanePaddingSettings class



## Properties


### Bottom

The bottom padding of the chart panes.

### Left

The left padding of the chart panes.

### Right

The right padding of the chart panes.

### Top

The top padding of the chart panes.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






