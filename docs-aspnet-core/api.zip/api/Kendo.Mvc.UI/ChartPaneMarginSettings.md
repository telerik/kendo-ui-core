---
title: ChartPaneMarginSettings
---

# Kendo.Mvc.UI.ChartPaneMarginSettings
Kendo UI ChartPaneMarginSettings class



## Properties


### Bottom

The bottom margin of the chart panes.

### Left

The left margin of the chart panes.

### Right

The right margin of the chart panes.

### Top

The top margin of the chart panes.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






