---
title: LinearGaugeScaleMajorTicksSettings
---

# Kendo.Mvc.UI.LinearGaugeScaleMajorTicksSettings
Kendo UI LinearGaugeScaleMajorTicksSettings class



## Properties


### DashType

Gets or sets the ticks dash type.

### Color

The color of the major ticks. Any valid CSS color string will work here, including hex and rgb.

### Size

The major tick size. This is the length of the line in pixels that is drawn to indicate the tick on the scale.

### Visible

The visibility of the major ticks.

### Width

The width of the major ticks.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






