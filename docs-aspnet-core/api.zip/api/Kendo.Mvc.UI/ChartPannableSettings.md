---
title: ChartPannableSettings
---

# Kendo.Mvc.UI.ChartPannableSettings
Kendo UI ChartPannableSettings class



## Properties


### Key

Specifies the key that should be pressed to activate panning or zooming.

### Lock

Specifies an axis that should not be panned or zoomed.

### Enabled

Specifies if the chart can be panned.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






