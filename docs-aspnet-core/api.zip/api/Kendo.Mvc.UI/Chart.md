---
title: Chart
---

# Kendo.Mvc.UI.Chart
Kendo UI Chart component



## Properties


### SeriesDefaults

The common settings for all Chart series.

### DataSource

The Chart data source configuration

### DataSourceId

Gets or sets the id of the external DataSource used by the Chart.

### Data

Gets or sets the data source.

### AutoBind

If set to false the widget will not bind to the data source during initialization. In this case data binding will occur when the change event of the data source is fired. By default the widget will bind to the data source specified in the configuration.

### AxisDefaults

The default options for all chart axes. Accepts the options supported by categoryAxis, valueAxis, xAxis and yAxis.

### CategoryAxis

The category axis configuration options.

### ChartArea

The chart area configuration options. Represents the entire visible area of the chart.

### Legend

The chart legend configuration options.

### Panes

The chart panes configuration.Panes are used to split the chart in two or more parts. The panes are ordered from top to bottom.Each axis can be associated with a pane by setting its pane option to the name of the desired pane. Axis that don't have specified pane are placed in the top (default) pane.Series are moved to the desired pane by associating them with an axis.

### Pannable

Specifies if the chart can be panned.

### Pdf

Configures the export settings for the saveAsPDF method.

### PersistSeriesVisibility

Specifies if the series visible option should be persisted when changing the dataSource data.

### PlotArea

The plot area configuration options. The plot area is the area which displays the series.

### Series

The configuration of the chart series.The series type is determined by the value of the type field. If a type value is missing, the type is assumed to be the one specified in seriesDefaults.

### SeriesColors

The default colors for the chart's series. When all colors are used, new colors are pulled from the start again.

### Theme

The chart theme. This can be either a built-in theme or "sass". When set to "sass" the chart will read the variables from the Sass-based themes.The supported values are: "sass" - special value, see notes; "black"; "blueopal"; "bootstrap"; "default"; "highcontrast"; "metro"; "metroblack"; "moonlight"; "silver" or "uniform".

### Title

The chart title configuration options or text.

### Tooltip

The chart series tooltip configuration options.

### Transitions

If set to true the chart will play animations when displaying the series. By default animations are enabled.

### ValueAxis

The value axis configuration options.

### XAxis

The X-axis configuration options of the scatter chart X-axis. Supports all valueAxis options.

### YAxis

The y axis configuration options of the scatter chart. Supports all valueAxis options.

### Zoomable

Specifies if the chart can be zoomed.

### RenderAs

Specifies the preferred widget rendering mode.




## Methods


### WriteHtml(System.IO.TextWriter)
Writes the Chart HTML output.


#### Parameters

##### writer `System.IO.TextWriter`
The text writer instance.





### GenerateTag(System.IO.TextWriter)
Generates the Chart wrapper DIV element.


#### Parameters

##### writer `System.IO.TextWriter`
The text writer instance.



#### Returns




### WriteInitializationScript(System.IO.TextWriter)
Writes the Chart initialization script.


#### Parameters

##### writer `System.IO.TextWriter`
The text writer instance.





### SerializeCustomSettings(System.Collections.Generic.IDictionary\<System.String,System.Object\>)
Serializes Chart settings.


#### Parameters

##### settings `System.Collections.Generic.IDictionary<System.String,System.Object>`
A dictionary containing the settings.





### SerializeDataSource(System.Collections.Generic.IDictionary\<System.String,System.Object\>)
Serializes the Chart DataSource settings to JSON.


#### Parameters

##### settings `System.Collections.Generic.IDictionary<System.String,System.Object>`






### SerializeSettings
Serialize current instance to Dictionary






