---
title: ChartBarGradient
---

# Kendo.Mvc.UI.ChartBarGradient
Specifies the gradient.


## Fields


### Glass
#
The series have glass effect overlay.

### None
#
The series do not have grdient.




