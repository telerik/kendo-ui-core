---
title: ChartMarkerShape
---

# Kendo.Mvc.UI.ChartMarkerShape
Specifies the shape of the marker.


## Fields


### Circle
#
The marker shape is circle.

### Cross
#
The marker shape is cross.

### Square
#
The marker shape is square.

### Triangle
#
The marker shape is triangle.




