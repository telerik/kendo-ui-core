---
title: ChartCategoryAxisAutoBaseUnitStepsSettings
---

# Kendo.Mvc.UI.ChartCategoryAxisAutoBaseUnitStepsSettings
Kendo UI ChartCategoryAxisAutoBaseUnitStepsSettings class



## Properties


### Milliseconds

The milliseconds unit steps.

### Seconds

The seconds unit steps.

### Minutes

The minutes unit steps.

### Hours

The hours unit steps.

### Days

The days unit steps.

### Weeks

The weeks unit steps.

### Months

The months unit steps.

### Years

The years unit steps.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






