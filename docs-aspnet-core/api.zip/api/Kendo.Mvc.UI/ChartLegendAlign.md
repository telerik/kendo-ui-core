---
title: ChartLegendAlign
---

# Kendo.Mvc.UI.ChartLegendAlign
Specifies the legend align.


## Fields


### Center
#
The legend is aligned to the center.

### End
#
The legend is aligned to the end.

### Start
#
The legend is aligned to the start.




