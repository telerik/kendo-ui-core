---
title: ChatToolbarSettings
---

# Kendo.Mvc.UI.ChatToolbarSettings
Kendo UI ChatToolbarSettings class



## Properties


### Buttons

Defines the collection of buttons to be rendered. When using only an array of strings, the string added will define the name option of the button.

### Scrollable

Enables or disables the scrollable behavior of the toolbar.

### Toggleable

Enables or disables the toggleable behavior of the toolbar.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






