---
title: EditorImageBrowserSchemaSettings
---

# Kendo.Mvc.UI.EditorImageBrowserSchemaSettings
Kendo UI EditorImageBrowserSchemaSettings class



## Properties


### Model

Set the object which describes the image/directory entry fields. Note that a name, type and size fields should be set.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






