---
title: ArcGaugeScaleLabelsPosition
---

# Kendo.Mvc.UI.ArcGaugeScaleLabelsPosition
Sets the labels position


## Fields


### Inside
#
The labels are positioned inside.

### Outside
#
The labels are positioned outside.




