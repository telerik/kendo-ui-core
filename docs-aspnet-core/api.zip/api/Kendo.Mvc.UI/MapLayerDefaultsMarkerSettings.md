---
title: MapLayerDefaultsMarkerSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsMarkerSettings
Kendo UI MapLayerDefaultsMarkerSettings class



## Properties


### Opacity

The the opacity of all marker layers.

### Shape

The marker shape. Supported shapes are "pin" and "pinTarget".




## Methods


### SerializeSettings
Serialize current instance to Dictionary






