---
title: DropDownTreeItem
---

# Kendo.Mvc.UI.DropDownTreeItem
Represents an item from Kendo DropDownTree for ASP.NET MVC



