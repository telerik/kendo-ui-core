---
title: LinearGaugeScaleSettings
---

# Kendo.Mvc.UI.LinearGaugeScaleSettings
Kendo UI LinearGaugeScaleSettings class



## Properties


### Line

Configures the axis line.

### Labels

Configures the scale labels.

### MajorTicks

Configures the scale major ticks.

### MajorUnit

The interval between major divisions.

### Max

The maximum value of the scale.

### Min

The minimum value of the scale.

### MinorTicks

Configures the scale minor ticks.

### MinorUnit

The interval between minor divisions.

### Mirror

Mirrors the scale labels and ticks. If the labels are normally on the left side of the scale, mirroring the scale will render them to the right.

### Ranges

The ranges of the scale.

### RangePlaceholderColor

The default color for the ranges.

### RangeSize

The width of the range indicators.

### Reverse

Reverses the axis direction - values increase from right to left and from top to bottom.

### Vertical

The position of the gauge.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






