---
title: GridSelectionMode
---

# Kendo.Mvc.UI.GridSelectionMode
Represents the selection modes supported by Kendo UI Grid for ASP.NET MVC



