---
title: CalendarView
---

# Kendo.Mvc.UI.CalendarView
Represents available types of calendar views.


## Fields


### Month
#
Shows the days of the current month

### Year
#
Shows the months of the current year

### Decade
#
Shows the years of the current decade

### Century
#
Shows the decades of the current century




