---
title: EditorImageBrowserSchemaModelFieldsSettings
---

# Kendo.Mvc.UI.EditorImageBrowserSchemaModelFieldsSettings
Kendo UI EditorImageBrowserSchemaModelFieldsSettings class



## Properties


### Name

The field which contains the name of the image/directory

### Type

The field which contains the type of the entry. Either f for image or d for directory.

### Size

The field which contains the size of image.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






