---
title: DateTimePicker
---

# Kendo.Mvc.UI.DateTimePicker
Kendo UI DateTimePicker component



## Properties


### ARIATemplate

Specifies a template used to populate value of the aria-label attribute.

### ARIATemplateId

The id of the script element used for ARIATemplate

### Culture

Specifies the culture info used by the widget.

### DateInput

Specifies if the DateTimePicker will use DateInput for editing value

### Dates

Specifies a list of dates, which will be passed to the month template of the DateView. All dates, which match the date portion of the selected date will be used to re-bind the TimeView.

### Footer

The template which renders the footer of the calendar. If false, the footer will not be rendered.

### Format

Specifies the format, which is used to format the value of the DateTimePicker displayed in the input. The format also will be used to parse the input.For more information on date and time formats please refer to Date Formatting.

### Interval

Specifies the interval, between values in the popup list, in minutes.

### Max

Specifies the maximum date, which the calendar can show.

### Min

Specifies the minimum date that the calendar can show.

### WeekNumber

If set to true a week of the year will be shown on the left side of the calendar. It is possible to define a template in order to customize what will be displayed.

### ParseFormats

Specifies the formats, which are used to parse the value set with value() method or by direct input. If not set the value of the options.format and options.timeFormat will be used.  Note that value of the format option is always used. The timeFormat value also will be used if defined.

### TimeFormat

Specifies the format, which is used to format the values in the time drop-down list.

### Value

Specifies the selected value.

### Start

Represents available types of calendar views.

### Depth

Specifies the navigation depth.

### MonthTemplate






## Methods


### SerializeSettings
Serialize current instance to Dictionary






