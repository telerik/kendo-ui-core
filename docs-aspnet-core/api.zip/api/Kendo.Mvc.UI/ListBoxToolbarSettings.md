---
title: ListBoxToolbarSettings
---

# Kendo.Mvc.UI.ListBoxToolbarSettings
Kendo UI ListBoxToolbarSettings class



## Properties


### Position

Represents the listbox toolbar positions.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






