---
title: LinearGauge
---

# Kendo.Mvc.UI.LinearGauge
Kendo UI LinearGauge component



## Properties


### GaugeArea

The gauge area configuration options. This is the entire visible area of the gauge.

### RenderAs

Sets the preferred rendering engine. If it is not supported by the browser, the Gauge will switch to the first available mode.The supported values are: "svg" - renders the widget as inline SVG document, if available or "canvas" - renders the widget as a Canvas element, if available..

### Scale

Configures the scale.

### Theme

The gauge theme. This can be either a built-in theme or "sass". When set to "sass" the chart will read the variables from the Sass-based themes.The supported values are: "sass" - special value, see notes; "black"; "blueopal"; "bootstrap"; "default"; "highcontrast"; "metro"; "metroblack"; "moonlight"; "silver" or "uniform".

### Transitions

A value indicating if transition animations should be played.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






