---
title: ColorPickerMessagesSettings
---

# Kendo.Mvc.UI.ColorPickerMessagesSettings
Kendo UI ColorPickerMessagesSettings class



## Properties


### Apply

Allows customization of the "Apply" button text.

### Cancel

Allows customization of the "Cancel" button text.

### PreviewInput

Allows customization of the "Color Hexadecimal Code" preview input title.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






