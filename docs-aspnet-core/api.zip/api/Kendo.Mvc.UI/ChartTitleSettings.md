---
title: ChartTitleSettings
---

# Kendo.Mvc.UI.ChartTitleSettings
Kendo UI ChartTitleSettings class



## Properties


### Background

The background color of the title. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the title.

### Color

The text color of the title. Accepts a valid CSS color string, including hex and rgb.

### Font

The font of the title.

### Margin

The margin of the title. A numeric value will set all margins.

### Padding

The padding of the title. A numeric value will set all margins.

### Text

The text of the chart title. You can also set the text directly for a title with default options.

### Visible

If set to true the chart will display the title. By default the title will be displayed.

### Align

Specifies the text alignment.

### Position

Specifies the title position.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






