---
title: ColorPaletteTileSizeSettings
---

# Kendo.Mvc.UI.ColorPaletteTileSizeSettings
Kendo UI ColorPaletteTileSizeSettings class



## Properties


### Width

The width of the color cell.

### Height

The height of the color cell.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






