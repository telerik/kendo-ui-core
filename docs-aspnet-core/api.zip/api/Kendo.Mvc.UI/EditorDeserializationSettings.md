---
title: EditorDeserializationSettings
---

# Kendo.Mvc.UI.EditorDeserializationSettings
Kendo UI EditorDeserializationSettings class



## Properties


### Custom

Callback that allows custom deserialization to be plugged in. The method accepts string as the only parameter and is expected to return the modified content as string as well.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






