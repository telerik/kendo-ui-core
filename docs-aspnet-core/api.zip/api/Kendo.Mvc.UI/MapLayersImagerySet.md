---
title: MapLayersImagerySet
---

# Kendo.Mvc.UI.MapLayersImagerySet
The bing map tile types. Possible options.



