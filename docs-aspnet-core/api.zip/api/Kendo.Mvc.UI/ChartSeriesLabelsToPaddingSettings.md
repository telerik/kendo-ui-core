---
title: ChartSeriesLabelsToPaddingSettings
---

# Kendo.Mvc.UI.ChartSeriesLabelsToPaddingSettings
Kendo UI ChartSeriesLabelsToPaddingSettings class



## Properties


### Bottom

The bottom padding of the to labels.

### Left

The left padding of the to labels.

### Right

The right padding of the to labels.

### Top

The top padding of the to labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






