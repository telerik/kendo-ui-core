---
title: MapLayerType
---

# Kendo.Mvc.UI.MapLayerType
The layer type. Supported types are "tile", "bing", "shape", "marker" and "bubble".



