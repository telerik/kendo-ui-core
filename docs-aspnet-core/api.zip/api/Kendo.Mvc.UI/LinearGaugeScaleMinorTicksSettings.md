---
title: LinearGaugeScaleMinorTicksSettings
---

# Kendo.Mvc.UI.LinearGaugeScaleMinorTicksSettings
Kendo UI LinearGaugeScaleMinorTicksSettings class



## Properties


### DashType

Gets or sets the ticks dash type.

### Color

The color of the minor ticks. Any valid CSS color string will work here, including hex and rgb.

### Size

The minor tick size. This is the length of the line in pixels that is drawn to indicate the tick on the scale.

### Visible

The visibility of the minor ticks.

### Width

The width of the minor ticks.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






