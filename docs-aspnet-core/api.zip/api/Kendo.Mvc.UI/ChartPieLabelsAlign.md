---
title: ChartPieLabelsAlign
---

# Kendo.Mvc.UI.ChartPieLabelsAlign
Specifies the position of pie chart labels.


## Fields


### Circle
#
The label is positioned in a circle around the chart.

### Column
#
the label is positioned in a column around the chart.




