---
title: ChartTooltipBorderSettings
---

# Kendo.Mvc.UI.ChartTooltipBorderSettings
Kendo UI ChartTooltipBorderSettings class



## Properties


### Color

The color of the border.

### Width

The width of the border in pixels. By default the border width is set to zero which means that the border will not appear.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






