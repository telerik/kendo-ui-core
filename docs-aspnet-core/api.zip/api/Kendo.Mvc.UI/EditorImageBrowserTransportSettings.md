---
title: EditorImageBrowserTransportSettings
---

# Kendo.Mvc.UI.EditorImageBrowserTransportSettings
Kendo UI EditorImageBrowserTransportSettings class



## Properties


### Read

Options or URL for remote image retrieval.

### ThumbnailUrl

The URL for retrieving the thumbnail version of the image. If not specified a default image icon will be shown. If function is assigned, the current path and image name will be provided.

### UploadUrl

The URL which will handle the upload of the new images. If not specified the Upload button will not be displayed.The requirements for this handler are the same as for the save handler in the Upload widget.

### ImageUrl

The URL responsible for serving the original image. A file name placeholder should be specified. By default the placeholder value is URL encoded. If this is not desired, use a function.

### Destroy

Options or URL which will handle the file and directory deletion. If not specified the delete button will not be present.

### Create

Options or URL which will handle the directory creation. If not specified that create new folder button will not be present.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






