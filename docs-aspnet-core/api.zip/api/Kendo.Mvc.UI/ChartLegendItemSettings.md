---
title: ChartLegendItemSettings
---

# Kendo.Mvc.UI.ChartLegendItemSettings
Kendo UI ChartLegendItemSettings class



## Properties


### Cursor

The cursor style of the legend item.

### Visual

A function that can be used to create a custom visual for the legend items. The available argument fields are: options - the item options.; createVisual - a function that can be used to get the default visual.; series - the item series. or pointIndex - the index of the point in the series. Available for pie, donut and funnel series..




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






