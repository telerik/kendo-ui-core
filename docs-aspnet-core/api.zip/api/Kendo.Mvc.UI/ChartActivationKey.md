---
title: ChartActivationKey
---

# Kendo.Mvc.UI.ChartActivationKey
Specifies the key that should be pressed to activate panning or zooming.


## Fields


### None
#
No key is required.

### Ctrl
#
The "ctrl" key should be pressed.

### Shift
#
The "shift" key should be pressed.

### Alt
#
The "alt" key should be pressed.




