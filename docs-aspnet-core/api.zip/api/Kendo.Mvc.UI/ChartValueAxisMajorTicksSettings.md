---
title: ChartValueAxisMajorTicksSettings
---

# Kendo.Mvc.UI.ChartValueAxisMajorTicksSettings
Kendo UI ChartValueAxisMajorTicksSettings class



## Properties


### Color

The color of the value axis major ticks lines. Accepts a valid CSS color string, including hex and rgb.

### Size

The length of the tick line in pixels.

### Visible

If set to true the chart will display the value axis major ticks. By default the value axis major ticks are visible.

### Step

The step of the value axis major ticks.

### Skip

The skip of the value axis major ticks.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






