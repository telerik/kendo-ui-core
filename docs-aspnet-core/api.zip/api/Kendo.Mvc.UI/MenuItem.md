---
title: MenuItem
---

# Kendo.Mvc.UI.MenuItem
Represents an item from Kendo Menu for UI ASP.NET Core



## Properties


### Items

The 1 of menu items.

### Separator

Indicates whether the item is a separator.



