---
title: EditorTool
---

# Kendo.Mvc.UI.EditorTool
Kendo UI EditorTool class



## Properties


### Name

When specifying a tool as an object, a tool name is required. Please note that "undo" and "redo" are reserved tool names.

### Tooltip

The text which will be displayed when the end-user hovers the tool button with the mouse.

### Exec

The JavaScript function which will be executed when the end-user clicks the tool button.

### Items

For tools that display a list of items (fontName, fontSize, formatting), this option specifies the items in the shown list.

### Columns

Specifies the colors columns for "foreColor" and "backColor" tools when list of colors are defined.

### Template

The kendo template that will be used for rendering the given tool.

### TemplateId

The id of the script element used for Template

### Palette

Specifies the color palette for "foreColor" and "backColor" tools.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






