---
title: ComboBox
---

# Kendo.Mvc.UI.ComboBox
Kendo UI ComboBox component



## Properties


### AutoBind

Controls whether to bind the widget to the data source on initialization.

### AutoWidth

If set to true, the widget automatically adjusts the width of the popup element and does not wrap up the item label.

### CascadeFrom

Use it to set the Id of the parent ComboBox widget.Help topic showing how cascading functionality works

### CascadeFromField

Defines the field to be used to filter the data source. If not defined, it is set to a field with the same name as the parent's dataValueField option.Help topic showing how cascading functionality works

### CascadeFromParentField

Defines the parent field to be used to retain value from. This value will be used further to filter the dataSource. If not defined the value from the parent's dataValueField will be used.

### ClearButton

Unless this options is set to false, a button will appear when hovering the widget. Clicking that button will reset the widget's value and will trigger the change event.

### DataTextField

The field of the data item that provides the text content of the list items. The widget will filter the data source based on this field.

### DataValueField

The field of the data item that provides the value of the widget.

### Delay

The delay in milliseconds between a keystroke and when the widget displays the popup.

### Enable

If set to false the widget will be disabled and will not allow user input. The widget is enabled by default and allows user input.

### EnforceMinLength

If set to true the widget will not show all items when the text of the search input cleared. By default the widget shows all items when the text of the search input is cleared. Works in conjunction with minLength.

### FixedGroupTemplate

The template used to render the fixed header group. By default the widget displays only the value of the current group.

### FixedGroupTemplateId

The id of the script element used for FixedGroupTemplate

### FooterTemplate

The template used to render the footer template. The footer template receives the widget itself as a part of the data argument. Use the widget fields directly in the template.

### FooterTemplateId

The id of the script element used for FooterTemplate

### GroupTemplate

The template used to render the groups. By default the widget displays only the value of the group.

### GroupTemplateId

The id of the script element used for GroupTemplate

### Height

The height of the suggestion popup in pixels. The default value is 200 pixels.

### HighlightFirst

If set to true the first suggestion will be automatically highlighted.

### IgnoreCase

If set to false case-sensitive search will be performed to find suggestions. The widget performs case-insensitive searching by default.

### MinLength

The minimum number of characters the user must type before a search is performed. Set to higher value than 1 if the search could match a lot of items.

### NoDataTemplate

The template used to render the "no data" template, which will be displayed if no results are found or the underlying data source is empty. The noData template receives the widget itself as a part of the data argument. The template will be evaluated on every widget data bound.

### NoDataTemplateId

The id of the script element used for NoDataTemplate

### Placeholder

The hint displayed by the widget when it is empty. Not set by default.

### Popup

The options that will be used for the popup initialization. For more details about the available options refer to Popup documentation.

### Suggest

If set to true the widget will automatically use the first suggestion as its value.

### SyncValueAndText

When set to true the widget will automatically set selected value to the typed custom text. Set the option to false to clear the selected value but keep the custom text.

### HeaderTemplate

Specifies a static HTML content, which will be rendered as a header of the popup element.

### HeaderTemplateId

The id of the script element used for HeaderTemplate

### Template

The template used to render the items. By default the widget displays only the text of the data item (configured via dataTextField).

### TemplateId

The id of the script element used for Template

### Text

The text of the widget used when the autoBind is set to false.

### Value

The value of the widget.

### ValuePrimitive

Specifies the value binding behavior for the widget when the initial model value is null. If set to true, the View-Model field will be updated with the selected item value field. If set to false, the View-Model field will be updated with the selected item.

### Virtual

Enables the virtualization feature of the widget. The configuration can be set on an object, which contains two properties - itemHeight and valueMapper.For detailed information, refer to the article on virtualization.

### Filter

The filtering method used to determine the suggestions for the current value.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






