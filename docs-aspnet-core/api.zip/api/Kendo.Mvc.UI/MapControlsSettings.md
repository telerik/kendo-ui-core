---
title: MapControlsSettings
---

# Kendo.Mvc.UI.MapControlsSettings
Kendo UI MapControlsSettings class



## Properties


### Attribution

Configures or disables the built-in attribution control.

### Navigator

Configures or disables the built-in navigator control (directional pad).

### Zoom

Configures or disables the built-in zoom control (+/- button).




## Methods


### SerializeSettings
Serialize current instance to Dictionary






