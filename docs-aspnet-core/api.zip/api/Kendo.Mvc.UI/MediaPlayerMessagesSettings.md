---
title: MediaPlayerMessagesSettings
---

# Kendo.Mvc.UI.MediaPlayerMessagesSettings
Kendo UI MediaPlayerMessagesSettings class



## Properties


### Pause

Pause button tooltip message.

### Play

Play button tooltip message.

### Mute

Mute button tooltip message.

### Unmute

Unmute button tooltip message.

### Quality

Quality button tooltip message.

### Fullscreen

Fullscreen button tooltip message.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






