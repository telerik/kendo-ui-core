---
title: BarcodeTextMarginSettings
---

# Kendo.Mvc.UI.BarcodeTextMarginSettings
Kendo UI BarcodeTextMarginSettings class



## Properties


### Bottom

The bottom margin of the text.

### Left

The left margin of the text.

### Right

The right margin of the text.

### Top

The top margin of the text.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






