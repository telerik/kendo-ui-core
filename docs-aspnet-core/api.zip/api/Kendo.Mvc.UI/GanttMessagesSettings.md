---
title: GanttMessagesSettings
---

# Kendo.Mvc.UI.GanttMessagesSettings
Kendo UI GanttMessagesSettings class



## Properties


### Actions

The configuration of the Gantt action messages. Use this option to customize or localize the Gantt action messages.

### Cancel

The text similar to "Cancel" displayed in Gantt.

### DeleteDependencyConfirmation

The text similar to "Are you sure you want to delete this dependency?" displayed in Gantt dependency delete dialog.

### DeleteDependencyWindowTitle

The text similar to "Delete dependency" displayed in Gantt dependency delete dialog title.

### DeleteTaskConfirmation

The text similar to "Are you sure you want to delete this task?" displayed in Gantt task delete dialog.

### DeleteTaskWindowTitle

The text similar to "Delete task" displayed in Gantt task delete dialog title.

### Destroy

The text similar to "Delete" displayed in Gantt.

### Editor

The configuration of the Gantt editor messages. Use this option to customize or localize the Gantt editor messages.

### Save

The text similar to "Save" displayed in Gantt.

### Views

The configuration of the Gantt view messages. Use this option to customize or localize the Gantt view messages.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






