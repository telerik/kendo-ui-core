---
title: LinearGaugePointerBorderSettings
---

# Kendo.Mvc.UI.LinearGaugePointerBorderSettings
Kendo UI LinearGaugePointerBorderSettings class



