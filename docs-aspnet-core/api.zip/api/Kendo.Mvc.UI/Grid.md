---
title: Grid
---

# Kendo.Mvc.UI.Grid
Kendo UI Grid component



## Properties


### Selectable

Gets the selection configuration

### Filterable

Gets the filtering configuration.

### Scrollable

Gets the scrolling configuration.

### Pageable

Gets the paging configuration.

### Columns

Gets the columns of the grid.

### EnableCustomBinding

Gets or sets a value indicating whether custom binding is enabled.

### AllowCopy

If set to true and selection of the Grid is enabled the user could copy the selection into the clipboard and paste it into Excel or other similar programs that understand TSV/CSV formats. By default allowCopy is disabled and the default format is TSV. Can be set to a JavaScript object which represents the allowCopy configuration.

### AutoBind

If set to false, the Grid will not bind to the data source during initialization, i.e. it will not call the fetch method of the dataSource instance. In such scenarios data binding will occur when the change event of the dataSource instance is fired. By default, autoBind is set to true and the widget will bind to the data source specified in the configuration.

### ColumnResizeHandleWidth

Defines the width of the column resize handle in pixels. Apply a larger value for easier grasping.

### ColumnMenu

If set to true the grid will display the column menu when the user clicks the chevron icon in the column headers. The column menu allows the user to show and hide columns, filter and sort (if filtering and sorting are enabled). By default the column menu is not enabled.Can be set to a JavaScript object which represents the column menu configuration.

### Excel

Configures the Kendo UI Grid Excel export settings.

### Groupable

If set to true the user could group the grid by dragging the column header cells. By default grouping is disabled.Can be set to a JavaScript object which represents the grouping configuration.

### Navigatable

If set to true the use could navigate the widget using the keyboard navigation. By default keyboard navigation is disabled.

### NoRecords

If set to true and current view contains no records, message similar to "No records available" will be displayed. By default this option is disabled.

### Pdf

Configures the Kendo UI Grid PDF export settings.

### PersistSelection

Sets a value indicating whether the selection will be persisted when sorting, paging, filtering and etc are performed.

### Sortable

If set to true the user could sort the grid by clicking the column header cells. By default sorting is disabled.Can be set to a JavaScript object which represents the sorting configuration.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






