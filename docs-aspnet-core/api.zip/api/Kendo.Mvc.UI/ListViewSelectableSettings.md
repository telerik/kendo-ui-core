---
title: ListViewSelectableSettings
---

# Kendo.Mvc.UI.ListViewSelectableSettings
Kendo UI ListViewSelectableSettings class



## Properties


### Mode

Represents the selection modes supported by Kendo UI ListView for ASP.NET MVC

### Enabled

Specifies whether item selection is allowed. By default selection is disabled




## Methods


### Serialize
Serializes the ListView selection settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






