---
title: FlatColorPicker
---

# Kendo.Mvc.UI.FlatColorPicker
Kendo UI FlatColorPicker component



## Properties


### Opacity

Specifies whether we should display the opacity slider to allow selection of transparency.

### Buttons

Specifies whether the widget should display the Apply / Cancel buttons.

### Value

Specifies the initially selected color.

### Preview

Specifies whether we should display the preview bar which displays the current color and the input field.

### Autoupdate

Specifies whether the UI should be updated while the user is typing in the input field, whenever a valid color can be parsed.  If you passfalse for this, the widget will update only when ENTER is pressed.

### Messages

Allows customization of "Apply" / "Cancel" labels.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






