---
title: ChartPlotAreaSettings
---

# Kendo.Mvc.UI.ChartPlotAreaSettings
Kendo UI ChartPlotAreaSettings class



## Properties


### Background

The background color of the chart plot area. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the chart plot area.

### Margin

The margin of the chart plot area. A numeric value will set all margins.

### Opacity

The background opacity of the chart plot area. By default the background is opaque.

### Padding

The padding of the chart plot area. A numeric value will set all paddings.The default padding for pie, donut, radar and polar charts is proportional of the chart size.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






