---
title: MapLayerDefaultsBubbleSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsBubbleSettings
Kendo UI MapLayerDefaultsBubbleSettings class



## Properties


### Attribution

The attribution for all bubble layers.

### Opacity

The the opacity of all bubble layers.

### MaxSize

The maximum symbol size for bubble layer symbols.

### MinSize

The minimum symbol size for bubble layer symbols.

### Style

The default style for bubble layer symbols.

### Symbol

The bubble layer symbol type. Supported symbols are "circle" and "square".




## Methods


### SerializeSettings
Serialize current instance to Dictionary






