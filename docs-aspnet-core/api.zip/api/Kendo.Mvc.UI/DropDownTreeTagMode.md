---
title: DropDownTreeTagMode
---

# Kendo.Mvc.UI.DropDownTreeTagMode
Represents available tag modes of DropDownTree.


## Fields


### Multiple
#
Renders a tag for each selected value

### Single
#
Renders a single tag




