---
title: ChartPlotAreaPaddingSettings
---

# Kendo.Mvc.UI.ChartPlotAreaPaddingSettings
Kendo UI ChartPlotAreaPaddingSettings class



## Properties


### Bottom

The bottom padding of the chart plot area.

### Left

The left padding of the chart plot area.

### Right

The right padding of the chart plot area.

### Top

The top padding of the chart plot area.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






