---
title: ChartNotePosition
---

# Kendo.Mvc.UI.ChartNotePosition
Specifies the position of the note.


## Fields


### Top
#
The note is positioned on the top.

### Bottom
#
The note is positioned on the bottom.

### Left
#
The note is positioned on the left.

### Right
#
The note is positioned on the right.




