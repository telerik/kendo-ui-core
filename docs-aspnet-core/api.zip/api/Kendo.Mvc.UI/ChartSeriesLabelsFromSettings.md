---
title: ChartSeriesLabelsFromSettings
---

# Kendo.Mvc.UI.ChartSeriesLabelsFromSettings
Kendo UI ChartSeriesLabelsFromSettings class



## Properties


### Background

The background color of the from labels. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the from labels.

### Color

The text color of the from labels. Accepts a valid CSS color string, including hex and rgb.

### Font

The font style of the from labels.

### Format

The format of the from labels. Uses kendo.format.

### Margin

The margin of the from labels. A numeric value will set all margins.

### Padding

The padding of the from labels. A numeric value will set all paddings.

### Template

The template which renders the chart series from label.The fields which can be used in the template are: category - the category name.; dataItem - the original data item used to construct the point. Will be null if binding to array.; series - the data series or value - the point value. An object containing from and to values..

### TemplateId

The id of the script element used for Template

### Visible

If set to true the chart will display the series from labels. By default chart series from labels are not displayed.

### Position

Specifies the position of the "from" labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






