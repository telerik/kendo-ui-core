---
title: CalendarMonthSettings
---

# Kendo.Mvc.UI.CalendarMonthSettings
Kendo UI CalendarMonthSettings class



