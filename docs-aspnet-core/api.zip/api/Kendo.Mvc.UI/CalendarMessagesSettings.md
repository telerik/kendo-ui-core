---
title: CalendarMessagesSettings
---

# Kendo.Mvc.UI.CalendarMessagesSettings
Kendo UI CalendarMessagesSettings class



## Properties


### WeekColumnHeader

Allows customization of the week column header text. Set the value to make the widget compliant with web accessibility standards.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






