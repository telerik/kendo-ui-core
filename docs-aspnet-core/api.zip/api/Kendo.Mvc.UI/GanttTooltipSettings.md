---
title: GanttTooltipSettings
---

# Kendo.Mvc.UI.GanttTooltipSettings
Kendo UI GanttTooltipSettings class



## Properties


### Template

The template which renders the tooltip.The fields which can be used in the template are: task - the gantt task, for which the template is shown.

### TemplateId

The id of the script element used for Template

### Visible

If set to false the gantt will not display the task tooltip. By default the task tooltip is displayed.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






