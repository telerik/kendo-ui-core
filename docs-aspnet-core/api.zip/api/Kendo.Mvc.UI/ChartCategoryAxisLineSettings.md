---
title: ChartCategoryAxisLineSettings
---

# Kendo.Mvc.UI.ChartCategoryAxisLineSettings
Kendo UI ChartCategoryAxisLineSettings class



## Properties


### Color

The color of the lines. Accepts a valid CSS color string, including hex and rgb.

### DashType

The dash type of the line.The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### Visible

If set to true the chart will display the category axis lines. By default the category axis lines are visible.

### Width

The width of the line in pixels. Also affects the major and minor ticks, but not the grid lines.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






