---
title: ChartYAxisLabelsSettings
---

# Kendo.Mvc.UI.ChartYAxisLabelsSettings
Kendo UI ChartYAxisLabelsSettings class



## Properties


### Background

The background color of the labels. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the labels.

### Color

The text color of the labels. Accepts a valid CSS color string, including hex and rgb.

### Culture

The culture to use when formatting date values. See the globalization overview for more information.

### DateFormats

The format used to display the labels when the x values are dates. Uses kendo.format. Contains one placeholder ("{0}") which represents the category value.

### Font

The font style of the labels.

### Format

The format used to display the labels. Uses kendo.format. Contains one placeholder ("{0}") which represents the category value.

### Margin

The margin of the labels. A numeric value will set all margins.

### Mirror

If set to true the chart will mirror the axis labels and ticks. If the labels are normally on the left side of the axis, mirroring the axis will render them to the right.

### Padding

The padding of the labels. A numeric value will set all paddings.

### Rotation

The rotation angle of the labels. By default the labels are not rotated.

### Skip

The number of labels to skip.

### Step

The label rendering step - render every n-th label. By default every label is rendered.

### Template

The template which renders the labels.The fields which can be used in the template are: value - the category value.

### TemplateId

The id of the script element used for Template

### Visible

If set to true the chart will display the y axis labels. By default the y axis labels are visible.

### Visual

A function that can be used to create a custom visual for the labels. The available argument fields are: createVisual - a function that can be used to get the default visual.; culture - the default culture (if set) on the label; format - the default format of the label; options - the label options.; rect - the kendo.geometry.Rect that defines where the visual should be rendered.; sender - the chart instance (may be undefined).; text - the label text. or value - the category value.

### Position

Specifies the position of the labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






