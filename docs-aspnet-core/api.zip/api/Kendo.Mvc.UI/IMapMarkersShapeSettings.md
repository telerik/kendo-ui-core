---
title: IMapMarkersShapeSettings
---

# Kendo.Mvc.UI.IMapMarkersShapeSettings
Kendo UI MapMarkerDefaultsSettings class



