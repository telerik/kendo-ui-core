---
title: IMapMarkersShapeSettingsExtensions
---

# Kendo.Mvc.UI.IMapMarkersShapeSettingsExtensions
Kendo UI MapMarkerDefaultsSettings class



