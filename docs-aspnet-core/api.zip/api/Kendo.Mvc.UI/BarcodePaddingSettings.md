---
title: BarcodePaddingSettings
---

# Kendo.Mvc.UI.BarcodePaddingSettings
Kendo UI BarcodePaddingSettings class



## Properties


### Bottom

The bottom padding of the barcode.

### Left

The left padding of the barcode.

### Right

The right padding of the barcode.

### Top

The top padding of the barcode.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






