---
title: ChartPdfMarginSettings
---

# Kendo.Mvc.UI.ChartPdfMarginSettings
Kendo UI ChartPdfMarginSettings class



## Properties


### Bottom

The bottom margin. Numbers are considered as "pt" units.

### Left

The left margin. Numbers are considered as "pt" units.

### Right

The right margin. Numbers are considered as "pt" units.

### Top

The top margin. Numbers are considered as "pt" units.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






