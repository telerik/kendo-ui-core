---
title: Barcode
---

# Kendo.Mvc.UI.Barcode
Kendo UI Barcode component



## Properties


### RenderAs

Sets the preferred rendering engine. If it is not supported by the browser, the Barcode will switch to the first available mode.The supported values are: "canvas" - renders the widget as a Canvas element, if available. or "svg" - renders the widget as inline SVG document, if available.

### Background

The background of the barcode area. Any valid CSS color string will work here, including hex and rgb.

### Border

The border of the barcode area.

### Checksum

If set to true, the Barcode will display the checksum digit next to the value in the text area.

### Color

The color of the bar elements. Any valid CSS color string will work here, including hex and rgb.

### Height

The height of the barcode in pixels.  By default the height is 100.

### Padding

The padding of the barcode.

### Text

Can be set to a JavaScript object which represents the text configuration.

### Value

The initial value of the Barcode

### Width

The width of the barcode in pixels.  By default the width is 300.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






