---
title: ChartPaneTitleSettings
---

# Kendo.Mvc.UI.ChartPaneTitleSettings
Kendo UI ChartPaneTitleSettings class



## Properties


### Background

The background color of the title. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the title.

### Color

The text color of the title. Accepts a valid CSS color string, including hex and rgb.

### Font

The font style of the title.

### Margin

The margin of the title. A numeric value will set all margins.

### Position

The position of the title.The supported values are: "left" - the axis title is positioned on the left (applicable to horizontal axis); "right" - the axis title is positioned on the right (applicable to horizontal axis) or "center" - the axis title is positioned in the center.

### Text

The text of the title.

### Visible

If set to true the chart will display the pane title. By default the pane title is visible.

### Visual

A function that can be used to create a custom visual for the title. The available argument fields are: text - the label text.; rect - the kendo.geometry.Rect that defines where the visual should be rendered.; sender - the chart instance (may be undefined).; options - the label options. or createVisual - a function that can be used to get the default visual..




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






