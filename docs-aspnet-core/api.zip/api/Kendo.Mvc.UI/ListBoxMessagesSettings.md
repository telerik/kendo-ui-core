---
title: ListBoxMessagesSettings
---

# Kendo.Mvc.UI.ListBoxMessagesSettings
Kendo UI ListBoxMessagesSettings class



## Properties


### Tools

Defines the localization texts for tools in the ListBox. Texts are used when you configure the tooltip and accessibility support.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






