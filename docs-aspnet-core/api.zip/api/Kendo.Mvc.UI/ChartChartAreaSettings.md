---
title: ChartChartAreaSettings
---

# Kendo.Mvc.UI.ChartChartAreaSettings
Kendo UI ChartChartAreaSettings class



## Properties


### Background

The background color of the chart area. Accepts a valid CSS color string, including hex and rgb.

### Border

The border of the chart area.

### Height

The height of the chart area.

### Margin

The margin of the chart area. A numeric value will set all margins.

### Opacity

The background opacity of the chart area. By default the background is opaque.

### Width

The width of the chart area.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






