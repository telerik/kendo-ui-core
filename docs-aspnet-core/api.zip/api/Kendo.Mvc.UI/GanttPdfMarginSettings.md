---
title: GanttPdfMarginSettings
---

# Kendo.Mvc.UI.GanttPdfMarginSettings
Kendo UI GanttPdfMarginSettings class



## Properties


### Bottom

The bottom margin. Numbers are considered as "pt" units.

### Left

The left margin. Numbers are considered as "pt" units.

### Right

The right margin. Numbers are considered as "pt" units.

### Top

The top margin. Numbers are considered as "pt" units.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






