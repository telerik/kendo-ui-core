---
title: DialogAction
---

# Kendo.Mvc.UI.DialogAction
Kendo UI DialogAction class



## Properties


### Text

The text to be shown in the action's button.

### Action

The callback function to be called after pressing the action button.

### Primary

A boolean property indicating whether the action button will be decorated as primary button or not.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






