---
title: DataSourceRequest
---

# Kendo.Mvc.UI.DataSourceRequest
Provides information about paging, sorting, filtering and grouping of data.



## Properties


### Page

The current page.

### PageSize

The page size.

### Sorts

The sorting information for the data.

### Filters

The filtering information for the data.

### Groups

The grouping information for the data.

### Aggregates

The data aggregation.



