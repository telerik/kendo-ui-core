---
title: ChartSeriesLabelsFromMarginSettings
---

# Kendo.Mvc.UI.ChartSeriesLabelsFromMarginSettings
Kendo UI ChartSeriesLabelsFromMarginSettings class



## Properties


### Bottom

The bottom margin of the from labels.

### Left

The left margin of the from labels.

### Right

The right margin of the from labels.

### Top

The top margin of the from labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






