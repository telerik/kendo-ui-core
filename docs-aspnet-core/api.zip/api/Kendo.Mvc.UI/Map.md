---
title: Map
---

# Kendo.Mvc.UI.Map
Kendo UI Map component



## Properties


### Center

The map center. Coordinates are listed as [Latitude, Longitude].

### Controls

The configuration of built-in map controls.

### LayerDefaults

The default configuration for map layers by type.

### Layers

The configuration of the map layers. The layer type is determined by the value of the type field.

### MarkerDefaults

The default options for all markers.

### Markers

Static markers to display on the map.

### MinZoom

The minimum zoom level. Typical web maps use zoom levels from 0 (whole world) to 19 (sub-meter features).

### MaxZoom

The maximum zoom level. Typical web maps use zoom levels from 0 (whole world) to 19 (sub-meter features).

### MinSize

The size of the map in pixels at zoom level 0.

### Pannable

Controls whether the user can pan the map.

### Wraparound

Specifies whether the map should wrap around the east-west edges.

### Zoom

The initial zoom level.Typical web maps use zoom levels from 0 (whole world) to 19 (sub-meter features).The map size is derived from the zoom level and minScale options: size = (2 ^ zoom) * minSize

### Zoomable

Controls whether the map zoom level can be changed by the user.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






