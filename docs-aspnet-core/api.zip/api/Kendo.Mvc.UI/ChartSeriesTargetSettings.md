---
title: ChartSeriesTargetSettings
---

# Kendo.Mvc.UI.ChartSeriesTargetSettings
Kendo UI ChartSeriesTargetSettings class



## Properties


### Border

The border of the target.

### Color

The target color.

### Line

The target line options.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






