---
title: ArcGaugeColor
---

# Kendo.Mvc.UI.ArcGaugeColor
Kendo UI ArcGaugeColor class



## Properties


### Color

The color of the pointer in the specified range.

### From

The lower range value of the applied color.

### To

The upper range value of the applied color.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






