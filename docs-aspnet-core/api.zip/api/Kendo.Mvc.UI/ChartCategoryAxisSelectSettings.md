---
title: ChartCategoryAxisSelectSettings
---

# Kendo.Mvc.UI.ChartCategoryAxisSelectSettings
Kendo UI ChartCategoryAxisSelectSettings class



## Properties


### From

The lower boundary of the selected range.

### Max

The maximum value which the user can select.

### Min

The minimum value which the user can select.

### Mousewheel

The mouse wheel configuration of the selection.

### To

The upper boundary of the selected range.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






