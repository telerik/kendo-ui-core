---
title: LinearGaugeScaleLabelsBorderSettings
---

# Kendo.Mvc.UI.LinearGaugeScaleLabelsBorderSettings
Kendo UI LinearGaugeScaleLabelsBorderSettings class



## Properties


### Opacity

Gets or sets the label opacity.

### Color

The color of the border. Any valid CSS color string will work here, including hex and rgb.

### DashType

The dash type of the border.

### Width

The width of the border.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






