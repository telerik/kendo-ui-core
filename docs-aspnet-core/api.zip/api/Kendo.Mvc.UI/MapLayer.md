---
title: MapLayer
---

# Kendo.Mvc.UI.MapLayer
Kendo UI MapLayer class



## Properties


### Attribution

The attribution for the layer. Accepts valid HTML.

### AutoBind

If set to false the layer will not bind to the data source during initialization. In this case data binding will occur when the change event of the data source is fired. By default the widget will bind to the data source specified in the configuration.

### Extent

Specifies the extent of the region covered by this layer. The layer will be hidden when the specified area is out of view.Accepts a four-element array that specifies the extent covered by this layer: North-West lat, longitude, South-East latitude, longitude.If not specified, the layer is always visible.

### Key

The API key for the layer. Currently supported only for Bing (tm) tile layers.

### Culture

The culture to be used for the bing map tiles.

### LocationField

The data item field which contains the marker (symbol) location. The field should be an array with two numbers - latitude and longitude in decimal degrees.Requires the dataSource option to be set.Only applicable to "marker" and "bubble" layers.

### TileSize

The size of the image tile in pixels.

### TitleField

The data item field which contains the marker title. Requires the dataSource option to be set.

### MaxSize

The maximum symbol size for bubble layer symbols.

### MinSize

The minimum symbol size for bubble layer symbols.

### MaxZoom

The maximum zoom level at which to show this layer.

### MinZoom

The minimum zoom level at which to show this layer.

### Opacity

The the opacity for the layer.

### Subdomains

A list of subdomains to use for loading tiles. Alternating between different subdomains allows more requests to be executed in parallel.

### Style

The default style for shapes.

### UrlTemplate

The URL template for tile layers. Template variables: x - X coordinate of the tile; y - Y coordinate of the tile; zoom - zoom level or subdomain - Subdomain for this tile. See subdomains.

### UrlTemplateId

The id of the script element used for UrlTemplate

### ValueField

The value field for bubble layer symbols. The data item field should be a number.

### ZIndex

The zIndex for this layer.Layers are normally stacked in declaration order (last one is on top).

### Type

The layer type. Supported types are "tile", "bing", "shape", "marker" and "bubble".

### ImagerySet

The bing map tile types. Possible options.

### Shape

The marker shape. Supported shapes are "pin" and "pinTarget".

### Symbol

The bubble layer symbol type. Supported symbols are "circle" and "square".




## Methods


### SerializeSettings
Serialize current instance to Dictionary






