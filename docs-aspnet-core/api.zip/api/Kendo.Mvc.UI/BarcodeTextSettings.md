---
title: BarcodeTextSettings
---

# Kendo.Mvc.UI.BarcodeTextSettings
Kendo UI BarcodeTextSettings class



## Properties


### Color

The color of the text. Any valid CSS color string will work here, including hex and rgb.

### Font

The font of the text.

### Margin

The margin of the text

### Visible

If set to false the barcode will not display the value as a text below the barcode lines.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






