---
title: ChartRadarAreaStyle
---

# Kendo.Mvc.UI.ChartRadarAreaStyle
Specifies the preferred line rendering style.


## Fields


### Normal
#
Points will be connected with straight line.

### Smooth
#
Points will be connected with smooth line.




