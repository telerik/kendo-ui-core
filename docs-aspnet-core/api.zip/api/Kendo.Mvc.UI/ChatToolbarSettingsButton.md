---
title: ChatToolbarSettingsButton
---

# Kendo.Mvc.UI.ChatToolbarSettingsButton
Kendo UI ChatToolbarSettingsButton class



## Properties


### Name

Defines the name of the button.

### Text

Defines the text to be rendered in the button.

### IconClass

Defines the icon classes of the span rendered in the button.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






