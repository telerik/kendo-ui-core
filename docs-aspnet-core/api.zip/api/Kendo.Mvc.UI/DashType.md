---
title: DashType
---

# Kendo.Mvc.UI.DashType
Specifies a line dash type.


## Fields


### Solid
#
A solid line.

### Dot
#
A line consisting of dots.

### Dash
#
A line consisting of dashes.

### LongDash
#
A line consisting of a repeating pattern of long dashes.

### DashDot
#
A line consisting of a repeating pattern of dashes and dots.

### LongDashDot
#
A line consisting of a repeating pattern of long dashes and dots.

### LongDashDotDot
#
A line consisting of a repeating pattern of long dashes and two dots.




