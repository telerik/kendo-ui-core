---
title: ChartSeriesType
---

# Kendo.Mvc.UI.ChartSeriesType
The type of the series.


## Fields


### Area
#
Specifies Area series.

### Bar
#
Specifies Bar series.

### Bubble
#
Specifies Bubble series.

### Bullet
#
Specifies Bullet series.

### Candlestick
#
Specifies Candlestick series.

### Column
#
Specifies Column series.

### Donut
#
Specifies Donut series.

### Funnel
#
Specifies Funnel series.

### HorizontalWaterfall
#
Specifies HorizontalWaterfall series.

### Line
#
Specifies Line series.

### OHLC
#
Specifies Ohlc series.

### Pie
#
Specifies Pie series.

### PolarArea
#
Specifies PolarArea series.

### PolarLine
#
Specifies PolarLine series.

### PolarScatter
#
Specifies PolarScatter series.

### RadarArea
#
Specifies RadarArea series.

### RadarColumn
#
Specifies RadarColumn series.

### RadarLine
#
Specifies RadarLine series.

### RangeArea
#
Specifies RangeArea series.

### RangeBar
#
Specifies RangeBar series.

### RangeColumn
#
Specifies RangeColumn series.

### Scatter
#
Specifies Scatter series.

### ScatterLine
#
Specifies ScatterLine series.

### VerticalArea
#
Specifies VerticalArea series.

### VerticalBoxPlot
#
Specifies VerticalBoxPlot series.

### VerticalBullet
#
Specifies VerticalBullet series.

### VerticalLine
#
Specifies VerticalLine series.

### VerticalRangeArea
#
Specifies VerticalRangeArea series.

### Waterfall
#
Specifies Waterfall series.




