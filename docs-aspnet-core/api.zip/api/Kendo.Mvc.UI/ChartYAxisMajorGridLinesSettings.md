---
title: ChartYAxisMajorGridLinesSettings
---

# Kendo.Mvc.UI.ChartYAxisMajorGridLinesSettings
Kendo UI ChartYAxisMajorGridLinesSettings class



## Properties


### Color

The color of the lines. Accepts a valid CSS color string, including hex and rgb.

### DashType

The dash type of the line.The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### Visible

If set to false the chart will not display the y major grid lines. By default the y major grid lines are visible.

### Width

The width of the line in pixels. Also affects the major and minor ticks, but not the grid lines. #### Example - set the scatter chart x major grid lines width

### Step

The step of the y axis major grid lines.

### Skip

The skip of the y axis major grid lines.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






