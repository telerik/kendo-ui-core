---
title: DraggableAxis
---

# Kendo.Mvc.UI.DraggableAxis
Represents the Draggable widget Axis


## Fields


### X
#
X axis

### Y
#
Y axis

### None
#
Default value




