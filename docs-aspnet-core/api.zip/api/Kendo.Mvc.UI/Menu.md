---
title: Menu
---

# Kendo.Mvc.UI.Menu
Kendo UI Menu component



## Properties


### CloseOnClick

Specifies that sub menus should close after item selection (provided they won't navigate).

### HoverDelay

Specifies the delay in ms before the menu is opened/closed - used to avoid accidental closure on leaving.

### OpenOnClick

Specifies that the root sub menus will be opened on item click.

### Scrollable

If enabled, the Menu displays buttons that scroll the items when they cannot fit the width or the popups' height of the Menu. By default, scrolling is disabled.The following example demonstrates how to enable the scrolling functionality.

### Orientation

Specifies the orientation in which the menu items will be ordered




## Methods


### SerializeSettings
Serialize current instance to Dictionary






