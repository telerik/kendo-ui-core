---
title: ChartCategoryAxisCrosshairTooltipPaddingSettings
---

# Kendo.Mvc.UI.ChartCategoryAxisCrosshairTooltipPaddingSettings
Kendo UI ChartCategoryAxisCrosshairTooltipPaddingSettings class



## Properties


### Bottom

The bottom padding of the crosshair tooltip.

### Left

The left padding of the crosshair tooltip.

### Right

The right padding of the crosshair tooltip.

### Top

The top padding of the crosshair tooltip.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






