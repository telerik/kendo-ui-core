---
title: ChartSeriesLineSettings
---

# Kendo.Mvc.UI.ChartSeriesLineSettings
Kendo UI ChartSeriesLineSettings class



## Properties


### StringWidth

Gets or sets the line width.

### Color

The line color. Accepts a valid CSS color string, including hex and rgb.

### Opacity

The line opacity. By default the line is opaque.

### Width

The line width in pixels.

### Style

Specifies the preferred line rendering style.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






