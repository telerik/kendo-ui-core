---
title: DropDownTreeItemModel
---

# Kendo.Mvc.UI.DropDownTreeItemModel
Used for serializing DropDownTreeItem objects.



## Properties


### Enabled

Indicates whether the item is enabled.

### Expanded

Indicates whether the item is expanded.

### Encoded

Indicates whether the item is encoded.

### Selected

Indicates whether the item is selected.

### Text

Gets or sets the item text.

### Value

Gets or sets the item text.

### SpriteCssClass

Gets or sets the item sprite CSS class.

### Id

Gets or sets the item ID.

### Url

Gets or sets the URL that the item navigates to on click.

### ImageUrl

Gets or sets the item image URL.

### HasChildren

Indicates whether the item has children.

### Checked

Indicates whether the item is checked or not.

### Items

Gets or sets the nested items collection of the item.

### HtmlAttributes

Gets or sets 2 of HTML attributes applied to the item.

### ImageHtmlAttributes

Gets or sets 2 of HTML attributes applied to the image content of the item.

### LinkHtmlAttributes

Gets or sets 2 of HTML attributes applied to the link content of the item.



