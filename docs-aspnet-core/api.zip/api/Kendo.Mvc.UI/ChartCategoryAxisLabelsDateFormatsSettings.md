---
title: ChartCategoryAxisLabelsDateFormatsSettings
---

# Kendo.Mvc.UI.ChartCategoryAxisLabelsDateFormatsSettings
Kendo UI ChartCategoryAxisLabelsDateFormatsSettings class



## Properties


### Days

The format used when categoryAxis.baseUnit is set to "days".

### Hours

The format used when categoryAxis.baseUnit is set to "hours".

### Months

The format used when categoryAxis.baseUnit is set to "months".

### Weeks

The format used when categoryAxis.baseUnit is set to "weeks".

### Years

The format used when categoryAxis.baseUnit is set to "years".




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






