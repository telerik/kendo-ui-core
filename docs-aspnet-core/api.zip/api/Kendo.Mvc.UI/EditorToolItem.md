---
title: EditorToolItem
---

# Kendo.Mvc.UI.EditorToolItem
Kendo UI EditorToolItem class



## Properties


### Text

The string that the popup item will show.

### Value

The value that will be applied by the tool when this item is selected.

### Context

Only applicable for the formatting tool. Specifies the context in which the option will be available.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






