---
title: EditorImageBrowserSettings
---

# Kendo.Mvc.UI.EditorImageBrowserSettings
Kendo UI EditorImageBrowserSettings class



## Properties


### FileTypes

Defines the allowed file extensions.

### Path

Defines the initial folder to display, relative to the root.

### Transport

Specifies the settings for loading and saving data.

### Schema

Set the object responsible for describing the image raw data format.

### Messages

Defines texts shown within the image browser.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






