---
title: ITreeListColumnGroup
---

# Kendo.Mvc.UI.ITreeListColumnGroup
Kendo UI ITreeListColumnGroup interface



## Properties


### Columns

Gets the columns in the group



