---
title: ChartCategoryAxisType
---

# Kendo.Mvc.UI.ChartCategoryAxisType
Specifies the category axis type.


## Fields


### Category
#
Discrete category axis.

### Date
#
Specialized axis for displaying chronological data.




