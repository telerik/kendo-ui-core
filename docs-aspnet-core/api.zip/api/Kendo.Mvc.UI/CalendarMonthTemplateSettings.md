---
title: CalendarMonthTemplateSettings
---

# Kendo.Mvc.UI.CalendarMonthTemplateSettings
Kendo UI CalendarMonthTemplateSettings class



## Properties


### Empty



### EmptyId



### Content



### ContentId



### WeekNumber



### WeekNumberId






## Methods


### SerializeSettings
Serialize current instance to Dictionary






