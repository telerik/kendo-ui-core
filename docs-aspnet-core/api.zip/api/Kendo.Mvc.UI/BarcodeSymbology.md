---
title: BarcodeSymbology
---

# Kendo.Mvc.UI.BarcodeSymbology
Represents the symbologies (encodings) supported by Kendo UI Barcode for ASP.NET MVC



