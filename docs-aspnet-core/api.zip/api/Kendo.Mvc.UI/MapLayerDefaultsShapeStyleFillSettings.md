---
title: MapLayerDefaultsShapeStyleFillSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsShapeStyleFillSettings
Kendo UI MapLayerDefaultsShapeStyleFillSettings class



## Properties


### Color

The default fill color for layer shapes. Accepts a valid CSS color string, including hex and rgb.

### Opacity

The default fill opacity (0 to 1) for layer shapes.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






