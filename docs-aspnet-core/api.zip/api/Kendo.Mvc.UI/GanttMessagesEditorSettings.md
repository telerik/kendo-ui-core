---
title: GanttMessagesEditorSettings
---

# Kendo.Mvc.UI.GanttMessagesEditorSettings
Kendo UI GanttMessagesEditorSettings class



## Properties


### AssignButton

The text similar to "Assign" displayed in Gantt task editor.

### EditorTitle

The text similar to "Task" displayed in Gantt task editor.

### End

The text similar to "End" displayed in Gantt task editor.

### PercentComplete

The text similar to "Complete" displayed in Gantt task editor.

### Resources

The text similar to "Resources" displayed in Gantt task editor.

### ResourcesEditorTitle

The text similar to "Resources" displayed in Gantt task editor.

### ResourcesHeader

The text similar to "Resources" displayed in Gantt task editor.

### Start

The text similar to "Start" displayed in Gantt task editor.

### Title

The text similar to "Title" displayed in Gantt task editor.

### UnitsHeader

The text similar to "Units" displayed in Gantt task editor.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






