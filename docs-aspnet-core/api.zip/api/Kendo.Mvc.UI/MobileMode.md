---
title: MobileMode
---

# Kendo.Mvc.UI.MobileMode
Mode of adaptive rendering


## Fields


### Disabled
#
Disables the mobile adaptive rendering

### Auto
#
Autodetect if rendered by a mobile browser

### Phone
#
Force mobile phone rendering

### Tablet
#
Force mobile tablet rendering




