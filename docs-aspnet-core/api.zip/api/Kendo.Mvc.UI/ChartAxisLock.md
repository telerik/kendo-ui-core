---
title: ChartAxisLock
---

# Kendo.Mvc.UI.ChartAxisLock
Specifies an axis that should not be panned or zoomed.


## Fields


### None
#
No axis locking is applied.

### X
#
Locks the x axis.

### Y
#
Locks the y axis.




