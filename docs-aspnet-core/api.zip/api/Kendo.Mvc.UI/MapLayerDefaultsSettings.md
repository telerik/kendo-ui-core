---
title: MapLayerDefaultsSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsSettings
Kendo UI MapLayerDefaultsSettings class



## Properties


### Marker

The default configuration for marker layers.

### Shape

The default configuration for shape layers.

### Bubble

The default configuration for bubble layers.

### TileSize

The size of the image tile in pixels.

### Tile

The default configuration for tile layers.

### Bing

The default configuration for Bing (tm) tile layers.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






