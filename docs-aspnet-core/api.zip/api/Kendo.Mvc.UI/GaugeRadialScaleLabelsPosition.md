---
title: GaugeRadialScaleLabelsPosition
---

# Kendo.Mvc.UI.GaugeRadialScaleLabelsPosition
Sets the labels position


## Fields


### Inside
#
The labels are positioned inside.

### Outside
#
The labels are positioned outside.




