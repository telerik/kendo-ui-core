---
title: ChartZoomableSettings
---

# Kendo.Mvc.UI.ChartZoomableSettings
Kendo UI ChartZoomableSettings class



## Properties


### Mousewheel

Specifies if the chart can be zoomed using the mouse wheel.

### Selection

Specifies if the chart can be zoomed using selection.

### Enabled

Specifies if the chart can be zoomed.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






