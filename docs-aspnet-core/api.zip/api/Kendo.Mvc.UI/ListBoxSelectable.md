---
title: ListBoxSelectable
---

# Kendo.Mvc.UI.ListBoxSelectable
Represents the selectable options.


## Fields


### Single
#
Single selection

### Multiple
#
Multiple selections




