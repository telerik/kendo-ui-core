---
title: ChartLegendInactiveItemsLabelsSettings
---

# Kendo.Mvc.UI.ChartLegendInactiveItemsLabelsSettings
Kendo UI ChartLegendInactiveItemsLabelsSettings class



## Properties


### Color

The text color of the labels. Accepts a valid CSS color string, including hex and rgb.

### Font

The font style of the labels.

### Template

The template which renders the labels.The fields which can be used in the template are: text - the text the legend item.; series - the data series.; value - the point value. (only for donut and pie charts) or percentage - the point value represented as a percentage value. Available only for donut, pie and 100% stacked charts..

### TemplateId

The id of the script element used for Template




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






