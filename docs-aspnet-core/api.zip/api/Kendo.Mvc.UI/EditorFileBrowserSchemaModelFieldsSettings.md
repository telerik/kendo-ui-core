---
title: EditorFileBrowserSchemaModelFieldsSettings
---

# Kendo.Mvc.UI.EditorFileBrowserSchemaModelFieldsSettings
Kendo UI EditorFileBrowserSchemaModelFieldsSettings class



## Properties


### Name

The field which contains the name of the file/directory

### Type

The field which contains the type of the entry. Either f for file or d for directory.

### Size

The field which contains the size of file.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






