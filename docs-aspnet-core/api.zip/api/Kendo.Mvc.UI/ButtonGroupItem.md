---
title: ButtonGroupItem
---

# Kendo.Mvc.UI.ButtonGroupItem
Kendo UI ButtonGroupItem class



## Properties


### HtmlAttributes

Specifies the HTML attributes of a ButtonGroup item.

### Badge

Specifies the badge of a button.

### Enabled

Specifies if a button is enabled.

### Icon

Defines the name of an existing icon in a Kendo theme.

### IconClass

Allows the usage of custom icons. Defines CSS classes which are to be applied to a span element inside the ButtonGroup item.

### ImageUrl

If set, the ButtonGroup will render an image with the specified URL in the button.

### Selected

Specifies if a button is initially selected.

### Text

Specifies the text of the ButtonGroup item.

### Encoded

Specifies if text field of the ButtonGroup item should be encoded.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






