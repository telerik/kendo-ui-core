---
title: ChartYAxisLabelsRotationSettings
---

# Kendo.Mvc.UI.ChartYAxisLabelsRotationSettings
Kendo UI ChartYAxisLabelsRotationSettings class



## Properties


### Align

The alignment of the rotated labels relative to the slot center. The supported values are "end" and "center". By default the closest end of the label will be aligned to the center. If set to "center", the center of the rotated label will be aligned instead.

### Angle

The rotation angle of the labels. By default the labels are not rotated.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






