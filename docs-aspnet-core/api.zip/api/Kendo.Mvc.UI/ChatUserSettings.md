---
title: ChatUserSettings
---

# Kendo.Mvc.UI.ChatUserSettings
Kendo UI ChatUserSettings class



## Properties


### IconUrl

If set, sets the image url to be used for the user avatar icon.

### Name

Sets the name of the chat user.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






