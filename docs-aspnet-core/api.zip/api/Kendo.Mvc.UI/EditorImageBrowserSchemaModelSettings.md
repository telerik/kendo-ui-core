---
title: EditorImageBrowserSchemaModelSettings
---

# Kendo.Mvc.UI.EditorImageBrowserSchemaModelSettings
Kendo UI EditorImageBrowserSchemaModelSettings class



## Properties


### Id

The name of the field which acts as an identifier.

### Fields






## Methods


### SerializeSettings
Serialize current instance to Dictionary






