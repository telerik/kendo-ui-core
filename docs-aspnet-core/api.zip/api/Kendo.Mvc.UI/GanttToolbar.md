---
title: GanttToolbar
---

# Kendo.Mvc.UI.GanttToolbar
Kendo UI GanttToolbar class



## Properties


### Name

The name of the toolbar command. Either a built-in ("append" and "pdf") or custom. The name is reflected in one of the CSS classes, which is applied to the button - k-gantt-name. This class can be used to obtain reference to the button after Gantt initialization and attach click handlers.

### Template

The template which renders the command. By default renders a button.

### TemplateId

The id of the script element used for Template

### Text

The text displayed by the command button. If not set the name` option would be used as the button text instead.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






