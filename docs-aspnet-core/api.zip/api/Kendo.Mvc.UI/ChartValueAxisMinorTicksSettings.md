---
title: ChartValueAxisMinorTicksSettings
---

# Kendo.Mvc.UI.ChartValueAxisMinorTicksSettings
Kendo UI ChartValueAxisMinorTicksSettings class



## Properties


### Color

The color of the value axis minor ticks lines. Accepts a valid CSS color string, including hex and rgb.

### Size

The length of the tick line in pixels.

### Visible

If set to true the chart will display the value axis minor ticks. By default the value axis minor ticks are not visible.

### Width

The width of the minor ticks in pixels.

### Step

The step of the value axis minor ticks.

### Skip

The skip of the value axis minor ticks.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






