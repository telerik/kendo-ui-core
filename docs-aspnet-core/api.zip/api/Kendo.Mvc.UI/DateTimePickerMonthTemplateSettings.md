---
title: DateTimePickerMonthTemplateSettings
---

# Kendo.Mvc.UI.DateTimePickerMonthTemplateSettings
Kendo UI DateTimePickerMonthTemplateSettings class



## Properties


### Empty



### EmptyId



### Content



### ContentId



### WeekNumber



### WeekNumberId






## Methods


### SerializeSettings
Serialize current instance to Dictionary






