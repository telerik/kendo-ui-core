---
title: IListViewEditingSettings
---

# Kendo.Mvc.UI.IListViewEditingSettings
Kendo UI IListViewEditingSettings interface



## Properties


### Enabled

Specifies whether ListView editing is enabled.



