---
title: EditorSerializationSettings
---

# Kendo.Mvc.UI.EditorSerializationSettings
Kendo UI EditorSerializationSettings class



## Properties


### Custom

Define custom serialization for the editable content. The method accepts a single parameter as a string and is expected to return a string.

### Entities

Indicates whether the characters outside the ASCII range will be encoded as HTML entities. By default, they are encoded.

### Scripts

Indicates whether inline scripts will be serialized and posted to the server.

### Semantic

Indicates whether the font styles will be saved as semantic (strong / em / span) tags, or as presentational (b / i / u / font) tags. Used for outputting content for legacy systems.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






