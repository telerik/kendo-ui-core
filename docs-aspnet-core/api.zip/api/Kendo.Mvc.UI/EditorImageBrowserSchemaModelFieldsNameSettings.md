---
title: EditorImageBrowserSchemaModelFieldsNameSettings
---

# Kendo.Mvc.UI.EditorImageBrowserSchemaModelFieldsNameSettings
Kendo UI EditorImageBrowserSchemaModelFieldsNameSettings class



## Properties


### Field

The name of the field.

### Parse

Specifies the function which will parse the field value. If not set default parsers will be used.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






