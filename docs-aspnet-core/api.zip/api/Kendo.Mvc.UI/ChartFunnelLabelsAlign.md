---
title: ChartFunnelLabelsAlign
---

# Kendo.Mvc.UI.ChartFunnelLabelsAlign
Specifies the position of pie chart labels.


## Fields


### Center
#
The labels are positioned on the top of the funnel chart.

### Right
#
The labels are positioned on the left side of the chart.

### Left
#
The labels are positioned on the right side of the chart.




