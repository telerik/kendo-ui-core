---
title: ChartLineStyle
---

# Kendo.Mvc.UI.ChartLineStyle
Specifies the preferred rendering style.


## Fields


### Normal
#
Points will be connected with straight line.

### Smooth
#
Points will be connected with smooth line.

### Step
#
Points will be connected with a line at right angles.




