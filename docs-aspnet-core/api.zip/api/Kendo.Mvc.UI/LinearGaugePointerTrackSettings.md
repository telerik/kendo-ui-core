---
title: LinearGaugePointerTrackSettings
---

# Kendo.Mvc.UI.LinearGaugePointerTrackSettings
Kendo UI LinearGaugePointerTrackSettings class



