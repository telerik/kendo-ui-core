---
title: EditorFileBrowserTransportDestroySettings
---

# Kendo.Mvc.UI.EditorFileBrowserTransportDestroySettings
Kendo UI EditorFileBrowserTransportDestroySettings class



## Properties


### ContentType

The content-type HTTP header sent to the server. Default is "application/x-www-form-urlencoded". Use "application/json" if the content is JSON. Refer to the jQuery.ajax documentation for further info.

### DataType

The type of data that you're expecting back from the server. Commonly used values are "json" and "jsonp". Refer to the jQuery.ajax documentation for further info.

### Type

The type of request to make ("POST", "GET", "PUT" or "DELETE"), default is "POST". Refer to the jQuery.ajax documentation for further info.

### Url

The remote url to call when creating a new record.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






