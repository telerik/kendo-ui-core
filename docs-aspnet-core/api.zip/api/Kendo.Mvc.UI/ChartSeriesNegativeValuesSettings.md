---
title: ChartSeriesNegativeValuesSettings
---

# Kendo.Mvc.UI.ChartSeriesNegativeValuesSettings
Kendo UI ChartSeriesNegativeValuesSettings class



## Properties


### Color

The color of the chart negative bubble values.

### Visible

If set to true the chart will display the negative bubbles. By default the negative bubbles are not displayed.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






