---
title: ChartAxisLabelRotationAlignment
---

# Kendo.Mvc.UI.ChartAxisLabelRotationAlignment
Specifies the rotation of the labels.


## Fields


### End
#
Labels are aligned to the end.

### Center
#
Labels are aligned to the center.




