---
title: ListViewSelectionMode
---

# Kendo.Mvc.UI.ListViewSelectionMode
Represents the selection modes supported by Kendo UI ListView for ASP.NET MVC


## Fields


### Single
#
Single item selection.

### Multiple
#
Multiple item selection.




