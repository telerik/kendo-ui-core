---
title: MapLayerStyleStrokeSettings
---

# Kendo.Mvc.UI.MapLayerStyleStrokeSettings
Kendo UI MapLayerStyleStrokeSettings class



## Properties


### Color

The default stroke color for layer shapes. Accepts a valid CSS color string, including hex and rgb.

### DashType

The default dash type for layer shapes. The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### Opacity

The default stroke opacity (0 to 1) for layer shapes.

### Width

The default stroke width for layer shapes.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






