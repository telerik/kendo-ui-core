---
title: ChartSeriesHighlightLineSettings
---

# Kendo.Mvc.UI.ChartSeriesHighlightLineSettings
Kendo UI ChartSeriesHighlightLineSettings class



## Properties


### DashType

The dash type of the highlight line.The following dash types are supported: "dash" - a line consisting of dashes; "dashDot" - a line consisting of a repeating pattern of dash-dot; "dot" - a line consisting of dots; "longDash" - a line consisting of a repeating pattern of long-dash; "longDashDot" - a line consisting of a repeating pattern of long-dash-dot; "longDashDotDot" - a line consisting of a repeating pattern of long-dash-dot-dot or "solid" - a solid line.

### Color

The line color. Accepts a valid CSS color string, including hex and rgb.

### Opacity

The opacity of the line. By default the border is opaque.

### Width

The width of the line.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






