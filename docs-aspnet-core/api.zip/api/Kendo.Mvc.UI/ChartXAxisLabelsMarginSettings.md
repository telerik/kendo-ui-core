---
title: ChartXAxisLabelsMarginSettings
---

# Kendo.Mvc.UI.ChartXAxisLabelsMarginSettings
Kendo UI ChartXAxisLabelsMarginSettings class



## Properties


### Bottom

The bottom margin of the labels.

### Left

The left margin of the labels.

### Right

The right margin of the labels.

### Top

The top margin of the labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






