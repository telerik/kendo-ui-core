---
title: GanttViewRangeSettings
---

# Kendo.Mvc.UI.GanttViewRangeSettings
Kendo UI GanttViewRangeSettings class



## Properties


### Start

If set to some date the timeline of the view will start from this date.Overrides the range.start option of the gantt.

### End

If set to some date the timeline of the view will end to this date.Overrides the range.end option of the gantt.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






