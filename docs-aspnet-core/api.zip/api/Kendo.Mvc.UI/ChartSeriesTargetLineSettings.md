---
title: ChartSeriesTargetLineSettings
---

# Kendo.Mvc.UI.ChartSeriesTargetLineSettings
Kendo UI ChartSeriesTargetLineSettings class



## Properties


### Width

The width of the line.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






