---
title: MapLayerDefaultsBingSettings
---

# Kendo.Mvc.UI.MapLayerDefaultsBingSettings
Kendo UI MapLayerDefaultsBingSettings class



## Properties


### Attribution

The attribution of all Bing (tm) layers.

### Opacity

The the opacity of all Bing (tm) tile layers.

### Key

The key of all Bing (tm) tile layers.

### Culture

The culture to be used for the bing map tiles.

### ImagerySet

The bing map tile types. Possible options.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






