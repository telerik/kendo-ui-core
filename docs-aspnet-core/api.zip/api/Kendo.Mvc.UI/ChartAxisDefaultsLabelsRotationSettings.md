---
title: ChartAxisDefaultsLabelsRotationSettings
---

# Kendo.Mvc.UI.ChartAxisDefaultsLabelsRotationSettings
Kendo UI ChartAxisDefaultsLabelsRotationSettings class



## Properties


### Angle

The rotation angle of the labels. By default the labels are not rotated. Can be set to "auto" if the axis is horizontal in which case the labels will be rotated only if the slot size is not sufficient for the entire labels.

### Align

Specifies the rotation of the labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






