---
title: MediaPlayer
---

# Kendo.Mvc.UI.MediaPlayer
Kendo UI MediaPlayer component



## Properties


### AutoPlay

If set to true, the widget will start playing the video or videos after initializing.

### AutoRepeat

If set to true, the widget will start playing the video or videos after initializing.

### ForwardSeek

If set to false, the user will be prevented from seeking the video forward.

### FullScreen

If set to true, the widget will enter fullscreen mode.

### Messages

The object which holds the localization strings.

### Mute

If set to true, the video will be played without sound.

### Navigatable

If set to true, the option enables the keyboard navigation for the widget.

### Volume

A value between 0 and 100 that specifies the volume of the video.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






