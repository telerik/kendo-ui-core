---
title: ChartTitlePosition
---

# Kendo.Mvc.UI.ChartTitlePosition
Specifies the title position.


## Fields


### Top
#
The title is positioned at the top

### Bottom
#
The title is positioned at the bottom




