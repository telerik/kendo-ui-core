---
title: DialogMessagesSettings
---

# Kendo.Mvc.UI.DialogMessagesSettings
Kendo UI DialogMessagesSettings class



## Properties


### Close

The title of the close button.

### PromptInput

The title of the prompt input.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






