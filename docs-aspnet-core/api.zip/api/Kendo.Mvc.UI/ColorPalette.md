---
title: ColorPalette
---

# Kendo.Mvc.UI.ColorPalette
Kendo UI ColorPalette component



## Properties


### Columns

The number of columns to display.  When you use the "websafe" palette, this will automatically default to 18.

### TileSize

The size of a color cell.

### Value

Specifies the initially selected color.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






