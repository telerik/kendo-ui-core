---
title: ChartSeriesLabelsToMarginSettings
---

# Kendo.Mvc.UI.ChartSeriesLabelsToMarginSettings
Kendo UI ChartSeriesLabelsToMarginSettings class



## Properties


### Bottom

The bottom margin of the to labels.

### Left

The left margin of the to labels.

### Right

The right margin of the to labels.

### Top

The top margin of the to labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






