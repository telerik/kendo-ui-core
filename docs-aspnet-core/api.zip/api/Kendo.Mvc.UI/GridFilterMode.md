---
title: GridFilterMode
---

# Kendo.Mvc.UI.GridFilterMode
Represents the filterable modes supported by Kendo UI Grid for ASP.NET MVC



