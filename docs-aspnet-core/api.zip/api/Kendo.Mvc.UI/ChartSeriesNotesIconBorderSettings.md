---
title: ChartSeriesNotesIconBorderSettings
---

# Kendo.Mvc.UI.ChartSeriesNotesIconBorderSettings
Kendo UI ChartSeriesNotesIconBorderSettings class



## Properties


### Color

The border color of the icon.

### Width

The border width of the icon.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






