---
title: ColorPicker
---

# Kendo.Mvc.UI.ColorPicker
Kendo UI ColorPicker component



## Properties


### Buttons

Specifies whether the widget should display the Apply / Cancel buttons.Applicable only for the HSV selector, when a pallete is not specified.

### ClearButton

Specifies whether the widget should display the 'Clear color' button.Applicable only for the HSV selector, when a pallete is not specified.

### Columns

The number of columns to show in the color dropdown when a pallete is specified. This is automatically initialized for the "basic" and "websafe" palettes. If you use a custom palette then you can set this to some value that makes sense for your colors.

### TileSize

The size of a color cell.

### Messages

Allows localization of the strings that are used in the widget.

### Opacity

Only for the HSV selector.  If true, the widget will display the opacity slider. Note that currently in HTML5 the <input type="color"> does not support opacity.

### Preview

Only applicable for the HSV selector.Displays the color preview element, along with an input field where the end user can paste a color in a CSS-supported notation.

### ToolIcon

A CSS class name to display an icon in the color picker button.  If specified, the HTML for the element will look like this:

### Value

The initially selected color. Note that when initializing the widget from an <input> element, the initial color will be decided by the field instead.

### Palette

Defines the palettes that can be used in the color picker.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






