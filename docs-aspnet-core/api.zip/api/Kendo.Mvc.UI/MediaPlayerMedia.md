---
title: MediaPlayerMedia
---

# Kendo.Mvc.UI.MediaPlayerMedia
Specifies the object which holds the information about the media that will be played



## Properties


### Title

Specifies the title of the media that will be played

### Source

String or an array of objects that hold the URL\URLs to the videos



