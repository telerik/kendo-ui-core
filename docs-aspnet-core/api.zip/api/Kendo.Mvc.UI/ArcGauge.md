---
title: ArcGauge
---

# Kendo.Mvc.UI.ArcGauge
Kendo UI ArcGauge component



## Properties


### CenterTemplate

The label template. Template variables: *   value - the value

### CenterTemplateId

The id of the script element used for CenterTemplate

### Color

The color of the value pointer. Accepts a valid CSS color string, including hex and rgb.

### Colors

The color ranges of the value pointer. The pointer color will be set to the color from the range that contains the current value.

### GaugeArea

The gauge area configuration options. This is the entire visible area of the gauge.

### Opacity

The opacity of the value pointer.

### Scale

Configures the scale.

### Theme

The gauge theme. This can be either a built-in theme or "sass". When set to "sass" the gauge will read the variables from the Sass-based themes.The supported values are: "sass" - special value, see notes; "black"; "blueopal"; "bootstrap"; "default"; "highcontrast"; "metro"; "metroblack"; "moonlight"; "silver" or "uniform".

### Transitions

A value indicating if transition animations should be played.

### Value

The gauge value.

### RenderAs

Specifies the preferred widget rendering mode.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






