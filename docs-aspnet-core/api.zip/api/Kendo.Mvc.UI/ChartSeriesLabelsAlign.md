---
title: ChartSeriesLabelsAlign
---

# Kendo.Mvc.UI.ChartSeriesLabelsAlign
Specifies the alignment of the labels.


## Fields


### Center
#
the label is positioned at the center of the segment.

### Circle
#
The label is positioned in a circle around the chart.

### Column
#
the label is positioned in a column around the chart.

### Left
#
The label is positioned to the left of the segment.

### Right
#
The label is positioned to the right of the segment.




