---
title: ChartLegendMarginSettings
---

# Kendo.Mvc.UI.ChartLegendMarginSettings
Kendo UI ChartLegendMarginSettings class



## Properties


### Bottom

The bottom margin of the chart legend.

### Left

The left margin of the chart legend.

### Right

The right margin of the chart legend.

### Top

The top margin of the chart legend.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






