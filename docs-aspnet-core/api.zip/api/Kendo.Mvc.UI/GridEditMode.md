---
title: GridEditMode
---

# Kendo.Mvc.UI.GridEditMode
Represents the editing modes supported by Kendo UI Grid for ASP.NET MVC



