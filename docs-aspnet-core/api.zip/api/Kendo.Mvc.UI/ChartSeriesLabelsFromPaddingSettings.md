---
title: ChartSeriesLabelsFromPaddingSettings
---

# Kendo.Mvc.UI.ChartSeriesLabelsFromPaddingSettings
Kendo UI ChartSeriesLabelsFromPaddingSettings class



## Properties


### Bottom

The bottom padding of the from labels.

### Left

The left padding of the from labels.

### Right

The right padding of the from labels.

### Top

The top padding of the from labels.




## Methods


### Serialize
Serializes the settings to a Dictionary.





### SerializeSettings
Serialize current instance to Dictionary






