---
title: DataSourceWidget
---

# Kendo.Mvc.UI.DataSourceWidget
Kendo UI DataSource component



