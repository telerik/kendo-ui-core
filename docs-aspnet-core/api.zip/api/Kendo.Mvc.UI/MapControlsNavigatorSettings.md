---
title: MapControlsNavigatorSettings
---

# Kendo.Mvc.UI.MapControlsNavigatorSettings
Kendo UI MapControlsNavigatorSettings class



## Properties


### Position

Specifies the position of the navigation control.

### Enabled

Configures or disables the built-in navigator control (directional pad).




## Methods


### SerializeSettings
Serialize current instance to Dictionary






