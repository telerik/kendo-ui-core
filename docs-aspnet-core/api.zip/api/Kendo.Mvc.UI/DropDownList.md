---
title: DropDownList
---

# Kendo.Mvc.UI.DropDownList
Kendo UI DropDownList component



## Properties


### AutoBind

Controls whether to bind the widget to the data source on initialization.

### AutoWidth

If set to true, the widget automatically adjusts the width of the popup element and does not wrap up the item label.

### CascadeFrom

Use it to set the Id of the parent DropDownList widget.Help topic showing how cascading functionality works

### CascadeFromField

Defines the field to be used to filter the data source. If not defined the parent's dataValueField option will be used.Help topic showing how cascading functionality works

### CascadeFromParentField

Defines the parent field to be used to retain value from. This value will be used further to filter the dataSource. If not defined the value from the parent's dataValueField will be used.

### DataTextField

The field of the data item that provides the text content of the list items. The widget will filter the data source based on this field.

### DataValueField

The field of the data item that provides the value of the widget.

### Delay

Specifies the delay in milliseconds before the search-text typed by the end user is cleared.

### Enable

If set to false the widget will be disabled and will not allow user input. The widget is enabled by default and allows user input.

### EnforceMinLength

If set to true the widget will not show all items when the text of the search input cleared. By default the widget shows all items when the text of the search input is cleared. Works in conjunction with minLength.

### FixedGroupTemplate

The template used to render the fixed header group. By default the widget displays only the value of the current group.

### FixedGroupTemplateId

The id of the script element used for FixedGroupTemplate

### FooterTemplate

The template used to render the footer template. The footer template receives the widget itself as a part of the data argument. Use the widget fields directly in the template.

### FooterTemplateId

The id of the script element used for FooterTemplate

### GroupTemplate

The template used to render the groups. By default the widget displays only the value of the group.

### GroupTemplateId

The id of the script element used for GroupTemplate

### Height

The height of the suggestion popup in pixels. The default value is 200 pixels.

### IgnoreCase

If set to false case-sensitive search will be performed to find suggestions. The widget performs case-insensitive searching by default.

### MinLength

The minimum number of characters the user must type before a filter is performed. Set to higher value than 1 if the search could match a lot of items.

### NoDataTemplate

The template used to render the "no data" template, which will be displayed if no results are found or the underlying data source is empty. The noData template receives the widget itself as a part of the data argument. The template will be evaluated on every widget data bound.

### NoDataTemplateId

The id of the script element used for NoDataTemplate

### Popup

The options that will be used for the popup initialization. For more details about the available options refer to Popup documentation.

### OptionLabel

Define the text of the default empty item. If the value is an object, then the widget will use it as a valid data item.  Note that the optionLabel will not be available if the widget is empty.

### OptionLabelTemplate

The template used to render the option label.

### OptionLabelTemplateId

The id of the script element used for OptionLabelTemplate

### HeaderTemplate

Specifies a static HTML content, which will be rendered as a header of the popup element.

### HeaderTemplateId

The id of the script element used for HeaderTemplate

### Template

The template used to render the items. By default the widget displays only the text of the data item (configured via dataTextField).

### TemplateId

The id of the script element used for Template

### ValueTemplate

The valueTemplate used to render the selected value. By default the widget displays only the text of the data item (configured via dataTextField).

### ValueTemplateId

The id of the script element used for ValueTemplate

### Text

The text of the widget used when the autoBind is set to false.

### Value

The value of the widget.

### ValuePrimitive

Specifies the value binding behavior for the widget when the initial model value is null. If set to true, the View-Model field will be updated with the selected item value field. If set to false, the View-Model field will be updated with the selected item.

### Virtual

Enables the virtualization feature of the widget. The configuration can be set on an object, which contains two properties - itemHeight and valueMapper.For detailed information, refer to the article on virtualization.

### Filter

The filtering method used to determine the suggestions for the current value. Filtration is turned off by default.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






