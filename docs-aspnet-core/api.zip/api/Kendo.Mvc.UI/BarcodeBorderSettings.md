---
title: BarcodeBorderSettings
---

# Kendo.Mvc.UI.BarcodeBorderSettings
Kendo UI BarcodeBorderSettings class



## Properties


### Color

The color of the border. Any valid CSS color string will work here, including hex and rgb.

### DashType

The dash type of the border.

### Width

The width of the border.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






