---
title: Editor
---

# Kendo.Mvc.UI.Editor
Kendo UI Editor component



## Properties


### Deserialization

Fine-tune deserialization in the Editor widget. Deserialization is the process of parsing the HTML string input from the value() method or from the viewHtml dialog into editable content.

### Domain

Relaxes the same-origin policy when using the iframe-based editor. This is done automatically for all cases except when the policy is relaxed by document.domain = document.domain. In that case, this property must be used to allow the editor to function properly across browsers. This property has been introduced in internal builds after 2014.1.319.

### Encoded

Indicates whether the Editor should submit encoded HTML tags. By default, the submitted value is encoded.

### Immutables

If enabled, the editor disables the editing and command execution in elements marked with editablecontent="false" attribute.

### Messages

Defines the text of the labels that are shown within the editor. Used primarily for localization.

### PasteCleanup

Options for controlling how the pasting content is modified before it is added in the editor.

### Pdf

Configures the Kendo UI Editor PDF export settings.

### Placeholder

The hint displayed by the widget when it is empty. Not set by default.

### Resizable

If enabled, the editor renders a resize handle to allow users to resize it.

### Serialization

Allows setting of serialization options.

### Tools

A collection of tools that are used to interact with the Editor. Tools may be switched on by specifying their name. Custom tools and tools that require configuration are defined as objects.The available editor commands are: Basic text formatting     - bold, italic, underline, strikethrough, subscript, superscript; Font and color     - fontName, fontSize, foreColor, backColor; Alignment     - justifyLeft, justifyCenter, justifyRight, justifyFull; Lists     - insertUnorderedList, insertOrderedList, indent, outdent; Links, images and files     - createLink, unlink, insertImage, insertFile; Table editing     - tableWizard, createTable, addColumnLeft, addColumnRight, addRowAbove, addRowBelow, deleteRow, deleteColumn; Structural markup and styles     - formatting, cleanFormatting; Snippets     - insertHtml; HTML code view     - viewHtml; Print edited page     - print or Export to PDF     - pdf.

### ImageBrowser

Configuration for image browser dialog.

### FileBrowser

Configuration for file browser dialog.

### Tag

The tag that will be rendered. Defaults to "textarea". Triggers the inline edit mode if different.

### Value

The content of the editor.




## Methods


### SerializeSettings
Serialize current instance to Dictionary






