---
title: FilterCompositionLogicalOperator
---

# Kendo.Mvc.FilterCompositionLogicalOperator
Logical operator used for filter descriptor composition.


## Fields


### And
#
Combines filters with logical AND.

### Or
#
Combines filters with logical OR.




