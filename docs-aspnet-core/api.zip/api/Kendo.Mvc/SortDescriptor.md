---
title: SortDescriptor
---

# Kendo.Mvc.SortDescriptor
Represents declarative sorting.



## Properties


### Member

Gets or sets the member name which will be used for sorting.

### SortDirection

Gets or sets the sort direction for this sort descriptor. If the value is null
            no sorting will be applied.

### SortCompare

Gets or sets the sort compare for this sort descriptor.



