---
title: ListSortDirection
---

# Kendo.Mvc.ListSortDirection
Specifies the direction of a sort operation.


## Fields


### Ascending
#
Sorts in ascending order.

### Descending
#
Sorts in descending order.




